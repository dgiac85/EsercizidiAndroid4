package uk.co.massimocarli.android.ugho.activity.list;

import android.app.ListActivity;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.*;
import uk.co.massimocarli.android.ugho.R;
import uk.co.massimocarli.android.ugho.model.LocalDataModel;
import uk.co.massimocarli.android.ugho.service.LocalVoteService;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * This is the Activity we use to show local data using a the SimpleAdapter
 * <p/>
 * Created by Massimo Carli on 31/05/2013.
 */
public class SimpleAdapterLocalDataListActivity extends ListActivity {

    /**
     * The Tag of the Log for this class
     */
    private static final String TAG_LOG = SimpleAdapterLocalDataListActivity.class.getName();

    /**
     * The DateFormatter for the date of the votes
     */
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("E dd MMMM yyyy");

    /**
     * The array of the columns
     */
    private static final String[] FROM = {"date", "love", "health", "work", "luck"};

    /**
     * The array of the UI items to bind
     */
    private static final int[] TO = {R.id.list_item_date, R.id.list_item_love_vote, R.id.list_item_health_vote,
            R.id.list_item_work_vote, R.id.list_item_luck_vote};

    /**
     * The Adapter to use
     */
    private SimpleAdapter mAdapter;

    /**
     * The local list we use for the adapters
     */
    private List<Map<String, Object>> mModel = new LinkedList<Map<String, Object>>();

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // We create the adapters to assign to the listView
        mAdapter = new SimpleAdapter(this, mModel, R.layout.custom_list_item, FROM, TO);
        // We use the Binder to map the data
        mAdapter.setViewBinder(new SimpleAdapter.ViewBinder() {
            @Override
            public boolean setViewValue(View view, Object o, String s) {
                final TextView outputTextView = (TextView) view;
                // We have to detect which is the item and show it
                switch (view.getId()) {
                    case R.id.list_item_date:
                        Long value = (Long) o;
                        outputTextView.setText(DATE_FORMAT.format(value));
                        break;
                    case R.id.list_item_love_vote:
                        Integer loveVote = (Integer) o;
                        outputTextView.setText(getResources().getString(R.string.love_value_pattern, loveVote));
                        break;
                    case R.id.list_item_health_vote:
                        Integer healthVote = (Integer) o;
                        outputTextView.setText(getResources().getString(R.string.health_value_pattern, healthVote));
                        break;
                    case R.id.list_item_work_vote:
                        Integer workVote = (Integer) o;
                        outputTextView.setText(getResources().getString(R.string.work_value_pattern, workVote));
                        break;
                    case R.id.list_item_luck_vote:
                        Integer luckVote = (Integer) o;
                        outputTextView.setText(getResources().getString(R.string.luck_value_pattern, luckVote));
                        break;
                }
                return true;
            }
        });
        // We assign the adapters to the ListView
        getListView().setAdapter(mAdapter);
    }

    @Override
    protected void onStart() {
        super.onStart();
        // We get the model
        final LocalVoteService.VoteTransferObject result = LocalVoteService.sLocalVoteService.loadVotes(0, 100);
        // We update the adapters
        mModel.clear();
        for (LocalDataModel model : result.mData) {
            final Map<String, Object> item = new HashMap<String, Object>();
            item.put("date", model.entryDate);
            item.put("love", model.loveVote);
            item.put("health", model.healthVote);
            item.put("work", model.workVote);
            item.put("luck", model.luckVote);
            mModel.add(item);
        }
        mAdapter.notifyDataSetChanged();
        // We set the adapters again to update it
        getListView().setAdapter(mAdapter);
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        Toast.makeText(getApplicationContext(), "Selected position: " + position, Toast.LENGTH_SHORT).show();
    }
}