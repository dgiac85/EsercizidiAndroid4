package uk.co.massimocarli.android.ugho.util;

import java.util.Calendar;

/**
 * This is an enum that has all the sign of the Horoscope
 * <p/>
 * Created by Massimo Carli on 28/06/13.
 */
public enum Zodiac {

    ARIES,
    TAURUS,
    GEMINI,
    CANCER,
    LEO,
    VIRGO,
    LIBRA,
    SCORPIO,
    SAGITTARIUS,
    CAPRICORN,
    AQUARIUS,
    PISCES;

    private static final Calendar MARCH_21 = Calendar.getInstance();
    private static final Calendar APRIL_21 = Calendar.getInstance();
    private static final Calendar MAY_22 = Calendar.getInstance();
    private static final Calendar JUNE_22 = Calendar.getInstance();
    private static final Calendar JULY_23 = Calendar.getInstance();
    private static final Calendar AUGUST_23 = Calendar.getInstance();
    private static final Calendar SEPTEMBER_24 = Calendar.getInstance();
    private static final Calendar OCTOBER_24 = Calendar.getInstance();
    private static final Calendar NOVEMBER_23 = Calendar.getInstance();
    private static final Calendar DECEMBER_22 = Calendar.getInstance();
    private static final Calendar JANUARY_21 = Calendar.getInstance();
    private static final Calendar FEBRUARY_20 = Calendar.getInstance();

    static {
        MARCH_21.set(0, Calendar.MARCH, 21);
        APRIL_21.set(0, Calendar.APRIL, 21);
        MAY_22.set(0, Calendar.MAY, 22);
        JUNE_22.set(0, Calendar.JUNE, 22);
        JULY_23.set(0, Calendar.JULY, 23);
        AUGUST_23.set(0, Calendar.AUGUST, 23);
        SEPTEMBER_24.set(0, Calendar.SEPTEMBER, 24);
        OCTOBER_24.set(0, Calendar.OCTOBER, 24);
        NOVEMBER_23.set(0, Calendar.NOVEMBER, 23);
        DECEMBER_22.set(0, Calendar.DECEMBER, 22);
        JANUARY_21.set(0, Calendar.DECEMBER, 21);
        FEBRUARY_20.set(0, Calendar.DECEMBER, 20);
    }

    /**
     * This returns the sign for a given date
     *
     * @return The date for the sign
     */
    public static Zodiac fromDate(final Calendar date) {
        // We create a copy to test month and day
        final Calendar copyDate = Calendar.getInstance();
        copyDate.setTime(date.getTime());
        copyDate.set(Calendar.YEAR, 0);
        if (copyDate.equals(MARCH_21) || (copyDate.after(MARCH_21) && copyDate.before(APRIL_21))) {
            return ARIES;
        } else if ((copyDate.equals(APRIL_21) || (copyDate.after(APRIL_21)) && copyDate.before(MAY_22))) {
            return TAURUS;
        } else if ((copyDate.equals(MAY_22) || (copyDate.after(MAY_22)) && copyDate.before(JUNE_22))) {
            return GEMINI;
        } else if ((copyDate.equals(JUNE_22) || (copyDate.after(JUNE_22)) && copyDate.before(JULY_23))) {
            return CANCER;
        } else if ((copyDate.equals(JULY_23) || (copyDate.after(JULY_23)) && copyDate.before(AUGUST_23))) {
            return LEO;
        } else if ((copyDate.equals(AUGUST_23) || (copyDate.after(AUGUST_23)) && copyDate.before(SEPTEMBER_24))) {
            return VIRGO;
        } else if ((copyDate.equals(SEPTEMBER_24) || (copyDate.after(SEPTEMBER_24)) && copyDate.before(OCTOBER_24))) {
            return LIBRA;
        } else if ((copyDate.equals(OCTOBER_24) || (copyDate.after(OCTOBER_24)) && copyDate.before(NOVEMBER_23))) {
            return SCORPIO;
        } else if ((copyDate.equals(NOVEMBER_23) || (copyDate.after(NOVEMBER_23)) && copyDate.before(DECEMBER_22))) {
            return SAGITTARIUS;
        } else if (copyDate.equals(DECEMBER_22) || (copyDate.after(DECEMBER_22) || copyDate.before(JANUARY_21))) {
            return CAPRICORN;
        } else if ((copyDate.equals(JANUARY_21) || (copyDate.after(JANUARY_21)) && copyDate.before(FEBRUARY_20))) {
            return AQUARIUS;
        } else if ((copyDate.equals(FEBRUARY_20) || (copyDate.after(FEBRUARY_20)) && copyDate.before(MARCH_21))) {
            return PISCES;
        } else {
            throw new IllegalArgumentException("We should never be here! Check the code please!");
        }

    }

}
