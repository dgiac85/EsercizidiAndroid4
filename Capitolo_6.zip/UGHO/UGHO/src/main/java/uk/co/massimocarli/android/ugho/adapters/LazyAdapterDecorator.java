package uk.co.massimocarli.android.ugho.adapters;

import android.content.Context;
import android.database.DataSetObserver;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

/**
 * This is an implementation of the BaseAdapter that decorates another Adapter adding the
 * functionality of request more items in lazy ways.
 *
 * @author Massimo Carli
 */
public class LazyAdapterDecorator<E> extends BaseAdapter {

    /**
     * The interface that our decorator implement to receive notification about the click
     * on the more element
     */
    public interface OnMoreListener {

        /**
         * Invoked when the more View is someway selected
         *
         * @param currentCount The current number of elements
         */
        void moreClicked(int currentCount);

    }

    /**
     * The listener for the more events
     */
    private OnMoreListener mOnMoreListener;

    /**
     * The listener fro the next button
     */
    private MoreViewFactory.OnMoreViewClickListener mNextListener = new MoreViewFactory.OnMoreViewClickListener() {
        @Override
        public void moreClicked() {
            // We have to notify the update of this items
            if (mOnMoreListener != null) {
                // We notify the length of the current Adapter
                mOnMoreListener.moreClicked(mAdaptee.getCount());
            }
        }
    };

    /**
     * The Context
     */
    private Context mContext;

    /**
     * The BaseAdapter to decorate
     */
    private BaseAdapter mAdaptee;

    /**
     * If true the lazy loading is enabled.
     */
    private boolean mIsMoreEnabled = true;

    /**
     * If present the object responsible of the creation of the View for the more.
     */
    private MoreViewFactory mMoreViewFactory;


    /**
     * Creates an Adapter to add lazy loading functionality
     *
     * @param context The Context
     * @param adaptee The BaseAdapter to decorate
     */
    public LazyAdapterDecorator(final Context context, final BaseAdapter adaptee) {
        this.mContext = context;
        if (adaptee == null) {
            throw new IllegalArgumentException("Adaptee cannot be null!");
        }
        this.mAdaptee = adaptee;
    }

    /**
     * Set the object responsible of the creation of the View for the More
     *
     * @param moreViewFactory The MoreViewFactory we use for the More View
     */
    public void setMoreViewFactory(final MoreViewFactory moreViewFactory) {
        if (mMoreViewFactory != null) {
            mMoreViewFactory.setOnMoreViewClickListener(null);
        }
        this.mMoreViewFactory = moreViewFactory;
        if (moreViewFactory != null) {
            moreViewFactory.setOnMoreViewClickListener(mNextListener);
        }
    }

    /**
     * Set the listener of the more button
     *
     * @param onMoreListener
     */
    public void setOnMoreListener(final OnMoreListener onMoreListener) {
        this.mOnMoreListener = onMoreListener;
    }

    /*
     * (non-Javadoc)
     *
     * @see android.widget.ListAdapter#areAllItemsEnabled()
     */
    @Override
    public boolean areAllItemsEnabled() {
        return mAdaptee.areAllItemsEnabled();
    }

    /*
     * (non-Javadoc)
     *
     * @see android.widget.ListAdapter#isEnabled(int)
     */
    @Override
    public boolean isEnabled(int position) {
        if (mIsMoreEnabled) {
            if (position < getCount() - 1) {
                // This elements are enabled if they are in the source Adapter
                return mAdaptee.isEnabled(position);
            } else {
                // The more is enabled
                return true;
            }
        } else {
            // In this case the more is disabled so we use the information from the Adaptee
            return mAdaptee.isEnabled(position);
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see android.widget.Adapter#getCount()
     */
    @Override
    public int getCount() {
        if (mIsMoreEnabled) {
            // The more is an element to add
            return mAdaptee.getCount() + 1;
        } else {
            // There's no more so the number of elements is the number of the original
            // Adapter
            return mAdaptee.getCount();
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see android.widget.Adapter#getItem(int)
     */
    @Override
    public Object getItem(int position) {
        if (mIsMoreEnabled) {
            // In this case the object is the Adaptee one if the position is not the last
            if (position == mAdaptee.getCount() - 1) {
                // In this case the position is the last so we return the value from the Adaptee
                return mAdaptee.getItem(position - 1);
            } else {
                // In this case we return the empty String because it's the value for the
                // next View
                return "";
            }
        } else {
            // When there's no more enabled the item at a given position is the mAdaptee one
            return mAdaptee.getItem(position);
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see android.widget.Adapter#getItemId(int)
     */
    @Override
    public long getItemId(int position) {
        if (mIsMoreEnabled) {
            // In this case the object is the Adaptee one if the position is not the last
            if (position == mAdaptee.getCount() - 1) {
                // In this case the position is the last so we return the value from the Adaptee
                return mAdaptee.getItemId(position - 1);
            } else {
                // In this case we return the empty String because it's the value for the
                // next View
                return -1;
            }
        } else {
            // When there's no more enabled the item id at a given position is the mAdaptee one
            return mAdaptee.getItemId(position);
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see android.widget.Adapter#getItemViewType(int)
     */
    @Override
    public int getItemViewType(int position) {
        if (mIsMoreEnabled) {
            if (position == getCount() - 1) {
                // In this case we return the id for the new type
                return mAdaptee.getViewTypeCount();
            } else {
                // In this case the value is the same of the source Adapter
                return mAdaptee.getItemViewType(position);
            }
        } else {
            // In this case the value is the same from the Adaptee
            return mAdaptee.getItemViewType(position);
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see android.widget.Adapter#getView(int, android.view.View,
     * android.view.ViewGroup)
     */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (mIsMoreEnabled) {
            if (position < getCount() - 1) {
                // In this case we return the View of the original Adapter
                return mAdaptee.getView(position, convertView, parent);
            } else {
                // In this case we return the View for the more
                return getMoreView(position, convertView, parent);
            }
        } else {
            // In this case we return the View of the original Adapter
            return mAdaptee.getView(position, convertView, parent);
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see android.widget.Adapter#getViewTypeCount()
     */
    @Override
    public int getViewTypeCount() {
        // The number of different View is the same of the original Adapter + 1 for the more
        return mAdaptee.getViewTypeCount() + 1;
    }

    /*
     * (non-Javadoc)
     *
     * @see android.widget.Adapter#hasStableIds()
     */
    @Override
    public boolean hasStableIds() {
        // The more button is stable so the value for this is the same of the source Adapter
        return mAdaptee.hasStableIds();
    }

    /*
     * (non-Javadoc)
     *
     * @see android.widget.Adapter#isEmpty()
     */
    @Override
    public boolean isEmpty() {
        // Our Adapter is emoty if the source Adapter is empty
        return mAdaptee.isEmpty();
    }

    /*
     * (non-Javadoc)
     *
     * @seeandroid.widget.Adapter#registerDataSetObserver(android.database.
     * DataSetObserver)
     */
    @Override
    public void registerDataSetObserver(DataSetObserver observer) {
        // We register the observer to the original Adapter
        mAdaptee.registerDataSetObserver(observer);
    }

    /*
     * (non-Javadoc)
     *
     * @seeandroid.widget.Adapter#unregisterDataSetObserver(android.database.
     * DataSetObserver)
     */
    @Override
    public void unregisterDataSetObserver(DataSetObserver observer) {
        // We unregister the observer to the original Adapter
        mAdaptee.unregisterDataSetObserver(observer);
    }

    /**
     * @return The Context
     */
    public Context getContext() {
        return mContext;
    }

    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
        // We notify the change to the Adaptee
        mAdaptee.notifyDataSetChanged();
    }

    @Override
    public void notifyDataSetInvalidated() {
        super.notifyDataSetInvalidated();
        // We notify the change to the Adaptee
        mAdaptee.notifyDataSetInvalidated();
    }

    /**
     * @return If true the more feature is enabled
     */
    public boolean isMoreEnabled() {
        return mIsMoreEnabled;
    }

    /**
     * Enabled or disabled the more feature
     *
     * @param isMoreEnabled If true the more feature is enabled
     */
    public void setMoreEnabled(boolean isMoreEnabled) {
        this.mIsMoreEnabled = isMoreEnabled;
    }

    /**
     * This method tells if the given position is the more button one or not
     *
     * @param position The position to check
     * @return True if the position of the moreElement one
     */
    public boolean isMoreElement(int position) {
        if (mIsMoreEnabled) {
            // It's the more one if the last
            return (position == getCount() - 1);
        } else {
            // In this case the position is never the more one
            return false;
        }
    }

    /**
     * This method is invoked when we need to create the more object
     *
     * @param position    Posizione del more
     * @param convertView Eventuale View da riutilizzare
     * @param parent      Eventuale parent
     * @return La view che dovra' rappresentare il more
     */
    protected View getMoreView(int position, View convertView, ViewGroup parent) {
        if (convertView != null) {
            return convertView;
        }
        // We check if a MoreViewFactory is available.
        if (mMoreViewFactory != null) {
            // We delegate to it the creation of the more button
            return mMoreViewFactory.createMoreView(mContext, position, convertView, parent);
        } else {
            mMoreViewFactory = new ButtonMoreViewFactory();
            mMoreViewFactory.setOnMoreViewClickListener(mNextListener);
            return mMoreViewFactory.createMoreView(mContext, position, convertView, parent);
        }
    }


}
