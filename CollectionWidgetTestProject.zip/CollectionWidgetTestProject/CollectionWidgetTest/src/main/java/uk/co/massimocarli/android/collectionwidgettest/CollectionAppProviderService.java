package uk.co.massimocarli.android.collectionwidgettest;

import android.content.Intent;
import android.util.Log;
import android.widget.RemoteViewsService;

/**
 * This is the class that describes the Service for the RemoteViews updates
 *
 * @author Massimo Carli
 */
public class CollectionAppProviderService extends RemoteViewsService {

    /* (non-Javadoc)
     * @see android.widget.RemoteViewsService#onGetViewFactory(android.content.Intent)
     */
    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        // Here we have to return the reference to the RemoteViewsFactory object that translate the
        // View into RemoteViews.
        HoroRemoteViewsFactory viewsFactory = new HoroRemoteViewsFactory(getApplicationContext(), intent);
        Log.i("APP_WIDGET_COLLECTION", "TeamRemoteViewsFactory created " + viewsFactory);
        return viewsFactory;
    }

}
