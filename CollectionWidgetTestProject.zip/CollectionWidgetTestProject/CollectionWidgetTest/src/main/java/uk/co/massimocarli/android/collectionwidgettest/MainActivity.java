package uk.co.massimocarli.android.collectionwidgettest;

import android.content.ContentValues;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;

import java.util.Random;

public class MainActivity extends Activity {

    /**
     * Millis is a day
     */
    private static final long MILLIS_IN_A_DAY = 24*3600*1000L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Delete and reinsert data
        getContentResolver().delete(UghoDB.HoroVote.CONTENT_URI, null, null);
        final Random random =new Random();
        for (int i = 0; i < 10; i++) {
            ContentValues contentValues = new ContentValues();
            contentValues.put(UghoDB.HoroVote.ENTRY_DATE, System.currentTimeMillis() - i * MILLIS_IN_A_DAY);
            contentValues.put(UghoDB.HoroVote.HORO_SIGN, "Lion");
            contentValues.put(UghoDB.HoroVote.LOVE_VOTE, (int)Math.abs(random.nextInt() % 5));
            contentValues.put(UghoDB.HoroVote.HEALTH_VOTE, (int)Math.abs(random.nextInt() % 5));
            contentValues.put(UghoDB.HoroVote.WORK_VOTE, (int)Math.abs(random.nextInt() % 5));
            contentValues.put(UghoDB.HoroVote.LUCK_VOTE, (int)Math.abs(random.nextInt() % 5));
            getContentResolver().insert(UghoDB.HoroVote.CONTENT_URI, contentValues);
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
}
