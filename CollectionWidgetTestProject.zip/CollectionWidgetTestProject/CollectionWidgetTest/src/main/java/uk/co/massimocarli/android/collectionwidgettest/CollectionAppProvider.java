package uk.co.massimocarli.android.collectionwidgettest;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.widget.RemoteViews;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 * AppWidgetProvider implementation
 * <p/>
 * Created by Massimo Carli on 27/06/13.
 */
public class CollectionAppProvider extends AppWidgetProvider {
    /*
     * Tag for the log
     */
    private final static String TAG_LOG = "CollectionAppProvider";

    /**
     * The DateFormatter for the date of the votes
     */
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("E dd MMMM yyyy");

    /*
     * PendingIntent identifier
     */
    private final static int CLICK_REQUEST_ID = 0;

    /**
     * Action for the Intent we launch for item selection
     */
    public final static String ACTION_LIST_SELECTED = "android.appwidget.AppWidgetManager.action.ACTION_LIST_SELECTED";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        Log.i(TAG_LOG, "Update");
        for (int i = 0; i < appWidgetIds.length; i++) {
            // We get the current widgetId
            int widgetId = appWidgetIds[i];
            // We create the RemoteViews
            RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.widget_list_layout);
            // We create the Intent we use to activate the Service
            Intent srvIntent = new Intent(context, CollectionAppProviderService.class);
            srvIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
            srvIntent.setData(Uri.parse(srvIntent.toUri(Intent.URI_INTENT_SCHEME)));
            remoteViews.setRemoteAdapter(R.id.stack_view, srvIntent);
            Log.i("APP_WIDGET_COLLECTION", "srvIntent " + srvIntent);
            remoteViews.setEmptyView(R.id.stack_view, R.id.empty_view);
            Intent clickIntent = new Intent(context, CollectionAppProvider.class);
            clickIntent.setAction(ACTION_LIST_SELECTED);
            clickIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
            clickIntent.setData(Uri.parse(clickIntent.toUri(Intent.URI_INTENT_SCHEME)));
            PendingIntent clickPendingIntent = PendingIntent.getBroadcast(context, CLICK_REQUEST_ID, clickIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT);
            remoteViews.setPendingIntentTemplate(R.id.stack_view, clickPendingIntent);
            appWidgetManager.updateAppWidget(widgetId, remoteViews);
        }
        super.onUpdate(context, appWidgetManager, appWidgetIds);
    }


    @Override
    public void onReceive(Context context, Intent intent) {
        if (ACTION_LIST_SELECTED.equals(intent.getAction())) {
            long dateSelected = intent.getLongExtra(UghoDB.HoroVote.ENTRY_DATE, 0L);
            String message = null;
            if (dateSelected > 0L) {
                message = "Selected date:" + DATE_FORMAT.format(dateSelected);
            } else {
                message = "Problem selecting date!";
            }
            Toast toast = Toast.makeText(context, message, Toast.LENGTH_SHORT);
            toast.show();
        } else {
            super.onReceive(context, intent);
        }
    }


}
