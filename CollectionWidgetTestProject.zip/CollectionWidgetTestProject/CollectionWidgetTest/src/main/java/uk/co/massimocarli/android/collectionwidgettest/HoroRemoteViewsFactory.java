package uk.co.massimocarli.android.collectionwidgettest;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.util.Log;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService.RemoteViewsFactory;
import android.widget.SimpleCursorAdapter;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 * This is the implementation of RemoteViewsFactory that maps the elements of the
 * ContentProvider into the RemoteViews items.
 *
 * @author Massimo Carli
 */
public class HoroRemoteViewsFactory implements RemoteViewsFactory {

    /**
     * The DateFormatter for the date of the votes
     */
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("E dd MMMM yyyy");

    /**
     * The name of the columns we need
     */
    private String[] FROMS = new String[]{UghoDB.HoroVote.ENTRY_DATE,
            UghoDB.HoroVote.LOVE_VOTE, UghoDB.HoroVote.HEALTH_VOTE,
            UghoDB.HoroVote.WORK_VOTE, UghoDB.HoroVote.LUCK_VOTE};

    private int[] TOS = new int[]{R.id.list_item_date, R.id.list_item_love_vote,
            R.id.list_item_health_vote, R.id.list_item_work_vote, R.id.list_item_luck_vote};

    /**
     * The Context
     */
    private Context mContext;

    /*
     * The id for the Widget
     */
    private int mWidgetId;

    /*
     * The Cursor implementation
     */
    private SimpleCursorAdapter mCursorAdapter;

    /*
     * The Cursor reference
     */
    private Cursor mCursor;

    /**
     * This creates a HoroRemoteViewsFactory from the Context and the Intent
     *
     * @param context The Context
     * @param intent  Intent for the show
     */
    public HoroRemoteViewsFactory(Context context, Intent intent) {
        // We save the Context
        this.mContext = context;
        Log.i("APP_WIDGET_COLLECTION", "TeamRemoteViewsFactory created");
        // We read the widgetId from the inptu Intent
        mWidgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,
                AppWidgetManager.INVALID_APPWIDGET_ID);
    }

    /* (non-Javadoc)
     * @see android.widget.RemoteViewsService.RemoteViewsFactory#onCreate()
     */
    @Override
    public void onCreate() {
        // We create the Cursor from the data
        mCursor = mContext.getContentResolver().query(UghoDB.HoroVote.CONTENT_URI, null, null, null, null);
        // We createthe adapter
        mCursorAdapter = new SimpleCursorAdapter(mContext, R.layout.custom_list_item, mCursor, FROMS, TOS, 0);
        Log.i("APP_WIDGET_COLLECTION", "onCreate()");
    }

    /* (non-Javadoc)
     * @see android.widget.RemoteViewsService.RemoteViewsFactory#onDestroy()
     */
    @Override
    public void onDestroy() {
        Log.i("APP_WIDGET_COLLECTION", "onDestroy");
        // Release the cursor
        mCursorAdapter.swapCursor(null);
        // Close the cursor
        mCursor.close();
    }

    /* (non-Javadoc)
     * @see android.widget.RemoteViewsService.RemoteViewsFactory#getViewAt(int)
     */
    @Override
    public RemoteViews getViewAt(int position) {
        Log.i("APP_WIDGET_COLLECTION", "getViewAt@" + position);
        // We create the RemoteViews for the item into the given position
        final RemoteViews remoteViews = new RemoteViews(mContext.getPackageName(), R.layout.custom_list_item);
        // Get the Cursor
        final Cursor itemCursor = (Cursor) mCursorAdapter.getItem(position);
        // Put value into fields
        showData(remoteViews, itemCursor, mWidgetId);
        return remoteViews;
    }


    /* (non-Javadoc)
     * @see android.widget.RemoteViewsService.RemoteViewsFactory#getCount()
     */
    @Override
    public int getCount() {
        Log.i("APP_WIDGET_COLLECTION", "getCount " + mCursorAdapter.getCount());
        return mCursorAdapter.getCount();
    }

    /* (non-Javadoc)
     * @see android.widget.RemoteViewsService.RemoteViewsFactory#getItemId(int)
     */
    @Override
    public long getItemId(int position) {
        return mCursorAdapter.getItemId(position);
    }

    /* (non-Javadoc)
     * @see android.widget.RemoteViewsService.RemoteViewsFactory#getViewTypeCount()
     */
    @Override
    public int getViewTypeCount() {
        return 1;
    }

    /* (non-Javadoc)
     * @see android.widget.RemoteViewsService.RemoteViewsFactory#hasStableIds()
     */
    @Override
    public boolean hasStableIds() {
        return true;
    }

    /* (non-Javadoc)
     * @see android.widget.RemoteViewsService.RemoteViewsFactory#getLoadingView()
     */
    @Override
    public RemoteViews getLoadingView() {
        return null;
    }

    /* (non-Javadoc)
     * @see android.widget.RemoteViewsService.RemoteViewsFactory#onDataSetChanged()
     */
    @Override
    public void onDataSetChanged() {
    }

    /**
     * Utility to copy data into the RemoteViews
     *
     * @param remoteViews The RemoteViews
     * @param dataCursor  The Cursor with the data
     */
    private void showData(final RemoteViews remoteViews, final Cursor dataCursor, int widgetId) {
        final Resources res = mContext.getResources();
        final LocalDataModel localData = LocalDataModel.fromCursor(dataCursor);
        remoteViews.setTextViewText(R.id.list_item_date, DATE_FORMAT.format(localData.entryDate));
        remoteViews.setTextViewText(R.id.list_item_love_vote,
                res.getString(R.string.love_value_pattern, localData.loveVote));
        remoteViews.setTextViewText(R.id.list_item_health_vote,
                res.getString(R.string.health_value_pattern, localData.healthVote));
        remoteViews.setTextViewText(R.id.list_item_work_vote,
                res.getString(R.string.work_value_pattern, localData.workVote));
        remoteViews.setTextViewText(R.id.list_item_luck_vote,
                res.getString(R.string.luck_value_pattern, localData.luckVote));
        // We manage item selection
        Intent clickFillIntent = new Intent();
        clickFillIntent.putExtra(UghoDB.HoroVote.ENTRY_DATE, localData.entryDate);
        remoteViews.setOnClickFillInIntent(R.id.list_item_date, clickFillIntent);
    }

}
