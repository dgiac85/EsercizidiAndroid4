package uk.co.massimocarli.android.ugho.account;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

/**
 * Created by Massimo Carli on 23/07/13.
 */
public class UghoSyncService extends Service {


    /**
     * A semaphore for adapter creation
     */
    private static final Object mMutex = new Object();

    /**
     * The reference to the UghoSyncAdapter
     */
    private static UghoSyncAdapter mUghoSyncAdapter = null;

    public void onCreate() {
        synchronized (mMutex) {
            if (mUghoSyncAdapter == null) {
                mUghoSyncAdapter = new UghoSyncAdapter(getApplicationContext());
            }
        }
    }

    /**
     * Returns the SyncAdapters Proxy
     *
     * @param intent The Intent
     * @return THe proxy for the SyncAdapters
     */
    public IBinder onBind(Intent intent) {
        return mUghoSyncAdapter.getSyncAdapterBinder();
    }
}
