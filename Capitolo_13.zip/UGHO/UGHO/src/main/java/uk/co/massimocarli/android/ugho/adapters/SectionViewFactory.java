package uk.co.massimocarli.android.ugho.adapters;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

/**
 * This interface describe the ability to create a View for a specific.
 */
public interface SectionViewFactory {

    /**
     * This method returns the View for a given Section.
     *
     * @param ctx         The Context
     * @param position    The position of the Section
     * @param convertView The cell for reuse
     * @param parent      The container of the header
     * @return The view to add to the header
     */
    View createSectionView(Context ctx, int position, View convertView, ViewGroup parent);


    /**
     * This show the value of the model E into the setionView.
     *
     * @param sectionView The View about the Section
     * @param value       The value to represent into the sectionView which is always a String
     */
    void setValue(View sectionView, String value);

}
