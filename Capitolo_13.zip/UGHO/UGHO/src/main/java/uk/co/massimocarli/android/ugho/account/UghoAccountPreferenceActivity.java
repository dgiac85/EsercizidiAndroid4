package uk.co.massimocarli.android.ugho.account;

import android.os.Bundle;
import com.actionbarsherlock.app.SherlockPreferenceActivity;
import uk.co.massimocarli.android.ugho.R;

/**
 * Created by massimocarli on 19/07/13.
 */
public class UghoAccountPreferenceActivity extends SherlockPreferenceActivity {

    @SuppressWarnings("deprecation")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.auth_server_settings);
    }


}
