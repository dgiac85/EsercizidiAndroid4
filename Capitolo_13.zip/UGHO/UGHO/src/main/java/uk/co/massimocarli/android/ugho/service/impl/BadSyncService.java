package uk.co.massimocarli.android.ugho.service.impl;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import uk.co.massimocarli.android.ugho.service.Synchronizer;

/**
 * Created by Massimo Carli on 12/07/13.
 */
public class BadSyncService extends Service {

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Here we execute the operation related to the sync
        Synchronizer.syncLocalData(this);
        // We want to execute the task again if the system kills it
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
