package uk.co.massimocarli.android.ugho.account;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.content.ContentResolver;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.Session;
import com.facebook.SessionState;
import com.facebook.UiLifecycleHelper;
import com.facebook.model.GraphLocation;
import com.facebook.model.GraphUser;
import com.facebook.widget.LoginButton;
import org.json.JSONObject;
import uk.co.massimocarli.android.ugho.R;
import uk.co.massimocarli.android.ugho.conf.Const;
import uk.co.massimocarli.android.ugho.content.UghoDB;
import uk.co.massimocarli.android.ugho.fragment.dialog.ProgressAlertDialog;
import uk.co.massimocarli.android.ugho.model.UserModel;
import uk.co.massimocarli.android.ugho.util.MD5Utility;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * Created by Massimo Carli on 19/07/13.
 */
public class UghoAuthActivity extends AccountAuthenticatorFragmentActivity {

    /**
     * The Tag of the Log for this class
     */
    private static final String TAG_LOG = UghoAuthActivity.class.getName();

    /**
     * The name of the extra we use to pass the account type to this Activity
     */
    public static final String ACCOUNT_TYPE_PARAM = AccountConst.PKG + ".extra.ACCOUNT_TYPE_PARAM";

    /**
     * The name of the extra we use to pass the token type to this Activity
     */
    public static final String TOKEN_TYPE_PARAM = AccountConst.PKG + ".extra.TOKEN_TYPE_PARAM";

    /**
     * The name of the extra we use to pass the username if available
     */
    public static final String USERNAME_PARAM = AccountConst.PKG + ".extra.USERNAME_PARAM";

    /**
     * The name of the extra we use to inform the Activity that this is a confirmation request
     */
    public static final String CONFIRM_CREDENTIAL_PARAM = AccountConst.PKG + ".extra.CONFIRM_CREDENTIAL_PARAM";

    /**
     * The tag for the ProgressDialog
     */
    private static final String PROGRESS_DIALOG_TAG = Const.PKG + ".tag.PROGRESS_DIALOG_TAG";


    /**
     * The reference to the EditText for the username
     */
    private EditText mUsernameEditText;

    /**
     * The reference to the EditText for the password
     */
    private EditText mPasswordEditText;

    /**
     * The reference to the TextView for the error messages
     */
    private TextView mErrorTextView;

    /**
     * ProgressDialog
     */
    private ProgressAlertDialog mProgressAlertDialog;

    /**
     * If true the account is new. Otherwise it's an account already present
     */
    private boolean mIsNewAccount;

    /**
     * The AccountManager reference
     */
    private AccountManager mAccountManager;

    /**
     * The type of the auth token
     */
    private String mAuthTokenType;

    /**
     * If true the activity is called to make a confirmation
     */
    private boolean mIsCredentialConfirm;

    /**
     * Callback implementation for Facebook integration
     */
    private final Session.StatusCallback mFacebookCallback = new Session.StatusCallback() {

        @Override
        public void call(Session session, SessionState state, Exception exception) {
            if (state == SessionState.OPENED) {
                // We fetch the UserData
                fetchUserData(session);
            }
        }
    };

    /**
     * Reference to the Helper for Facebook lifecycle
     */
    private UiLifecycleHelper mLifecycleHelper;

    @Override
    protected void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(R.layout.activity_social_login);
        // We get the mAccountManager
        mAccountManager = AccountManager.get(this);
        // We get the reference of the EditText
        mUsernameEditText = (EditText) findViewById(R.id.username_edittext);
        mPasswordEditText = (EditText) findViewById(R.id.password_edittext);
        // The reference to the TextView for error
        mErrorTextView = (TextView) findViewById(R.id.error_message_label);
        // We check if the username is already present into the Intent so we can put into the
        // related EditText
        Intent requestIntent = getIntent();
        String username = requestIntent.getStringExtra(USERNAME_PARAM);
        mIsNewAccount = TextUtils.isEmpty(username);
        if (!mIsNewAccount) {
            mUsernameEditText.setText(username);
        }
        mAuthTokenType = requestIntent.getStringExtra(TOKEN_TYPE_PARAM);
        mIsCredentialConfirm = requestIntent.getBooleanExtra(CONFIRM_CREDENTIAL_PARAM, false);
        // Facebook integration
        mLifecycleHelper = new UiLifecycleHelper(this, mFacebookCallback);
        mLifecycleHelper.onCreate(icicle);
        List<String> requestedPermission = Arrays.asList("email", "user_location", "user_birthday");
        LoginButton facebookLoginButton = (LoginButton) findViewById(R.id.facebook_login_button);
        facebookLoginButton.setReadPermissions(requestedPermission);
    }

    /**
     * We fetch the user informations from Facebook
     *
     * @param session The authenticated Session
     */
    private void fetchUserData(final Session session) {
        // Make an API call to get user data and define a
        // new callback to handle the response.
        com.facebook.Request request = com.facebook.Request.newMeRequest(session,
                new com.facebook.Request.GraphUserCallback() {
                    @Override
                    public void onCompleted(GraphUser user, com.facebook.Response response) {
                        // If the response is successful
                        if (session == Session.getActiveSession()) {
                            if (user != null) {
                                final String username = user.getUsername();
                                final GraphLocation location = user.getLocation();
                                final String birthDateStr = user.getBirthday();
                                final String email = (String) user.getProperty("email");
                                // Parse the BirthDate
                                final SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
                                Date birthDate = new Date();
                                try {
                                    birthDate = formatter.parse(birthDateStr);
                                } catch (ParseException e) {
                                    e.printStackTrace();
                                }
                                // Create the UserModel
                                final UserModel tmpUser = UserModel.create(birthDate.getTime()).withEmail(email)
                                        .withUsername(username);
                                if (location != null) {
                                    tmpUser.withLocation(location.getCity());
                                }
                                final Bundle initBundle = tmpUser.toBundle();
                                // We create the Account object with the data
                                final Account account = new Account(username, AccountConst.UGHO_ACCOUNT_TYPE);
                                final boolean created = mAccountManager.addAccountExplicitly(account, "password", initBundle);
                                if (created) {
                                    // We register for synchronisation
                                    ContentResolver.setSyncAutomatically(account, UghoDB.AUTHORITY, true);
                                    ContentResolver.addPeriodicSync(account, UghoDB.AUTHORITY, new Bundle(), AccountConst.SYNC_UPDATE);
                                }
                                Log.d(TAG_LOG, "Account created result: " + created);
                                final Intent resultIntent = new Intent();
                                resultIntent.putExtra(AccountManager.KEY_ACCOUNT_NAME, username);
                                resultIntent.putExtra(AccountManager.KEY_ACCOUNT_TYPE, AccountConst.UGHO_ACCOUNT_TYPE);
                                resultIntent.putExtra(AccountManager.KEY_BOOLEAN_RESULT, true);
                                setAccountAuthenticatorResult(resultIntent.getExtras());
                                setResult(RESULT_OK, resultIntent);
                                finish();
                            }
                        }
                        if (response.getError() != null) {
                            // Handle errors, will do so later.
                        }
                    }
                });
        request.executeAsync();
    }

    @Override
    public void onResume() {
        super.onResume();
        mLifecycleHelper.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        mLifecycleHelper.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mLifecycleHelper.onDestroy();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        mLifecycleHelper.onSaveInstanceState(outState);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        mLifecycleHelper.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getSupportMenuInflater();
        inflater.inflate(R.menu.sherlock_login, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_login) {
            doLogin();
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * This is invoked when we press the login button
     */
    public void doLogin() {
        Log.d(TAG_LOG, "doLogin!");
        // We hide the error message
        this.mErrorTextView.setVisibility(View.INVISIBLE);
        // We check if the username and password are present
        final Editable usernameEdit = mUsernameEditText.getText();
        if (TextUtils.isEmpty(usernameEdit)) {
            final String usernameMandatory = getResources().getString(R.string.mandatory_field_error, "username");
            Log.w(TAG_LOG, usernameMandatory);
            this.mErrorTextView.setText(usernameMandatory);
            this.mErrorTextView.setVisibility(View.VISIBLE);
            return;
        }
        final Editable passwordEdit = mPasswordEditText.getText();
        if (TextUtils.isEmpty(passwordEdit)) {
            final String passwordMandatory = getResources().getString(R.string.mandatory_field_error, "password");
            Log.w(TAG_LOG, passwordMandatory);
            this.mErrorTextView.setText(passwordMandatory);
            this.mErrorTextView.setVisibility(View.VISIBLE);
            return;
        }
        // We get the credentials as Strings
        final String username = usernameEdit.toString();
        final String password = passwordEdit.toString();
        // We initialize the VolleyQueue
        final RequestQueue requestQueue = Volley.newRequestQueue(this);
        // We get the Url for the login
        final String loginUrl = getResources().getString(R.string.login_url,
                username, MD5Utility.md5(password));
        // We create the request to send to the server through the queue
        JsonObjectRequest jsObjRequest = new JsonObjectRequest(Request.Method.GET, loginUrl, null, new Response.Listener<JSONObject>() {

            @Override
            public void onResponse(JSONObject response) {
                // This is the method that is invoked into the UI Thread with the
                // content of the response
                // We close the ProgressAlertDialog
                mProgressAlertDialog.dismiss();
                // We get the UserModel from the response
                UserModel userModel = UserModel.fromJson(response);
                // We check if the user is authenticated
                if (userModel != null && !userModel.hasError()) {
                    // We create the Account
                    final Account account = new Account(username, AccountConst.UGHO_ACCOUNT_TYPE);
                    if (mIsNewAccount) {
                        // We create the Bundle for the initial data
                        Bundle initBundle = userModel.toBundle();
                        // We create a new Account using the password and a Bundle with the
                        // settings data
                        final boolean created = mAccountManager.addAccountExplicitly(account, password, initBundle);
                        if (created) {
                            // We register for synchronisation
                            ContentResolver.setSyncAutomatically(account, UghoDB.AUTHORITY, true);
                            ContentResolver.addPeriodicSync(account, UghoDB.AUTHORITY, new Bundle(), AccountConst.SYNC_UPDATE);
                        }
                    } else {
                        // In this case we simple update the password because is valid
                        mAccountManager.setPassword(account, password);
                    }
                    // We now have to send the Intent back to the Authenticator
                    final Intent resultIntent = new Intent();
                    resultIntent.putExtra(AccountManager.KEY_ACCOUNT_NAME, username);
                    resultIntent.putExtra(AccountManager.KEY_ACCOUNT_TYPE, AccountConst.UGHO_ACCOUNT_TYPE);
                    resultIntent.putExtra(AccountManager.KEY_BOOLEAN_RESULT, true);
                    // In the response we also have the token so we can insert that data
                    final String accessToken = response.optString("token");
                    if (!TextUtils.isEmpty(accessToken) && TextUtils.isEmpty(mAuthTokenType) &&
                            mAuthTokenType.equals(AccountConst.UGHO_TOKEN_TYPE)) {
                        // In this case we save the information about the token
                        resultIntent.putExtra(AccountManager.KEY_AUTHTOKEN, accessToken);
                    }
                    // Now we send the result back to the Authenticator through the AccountAuthenticatorResponse
                    // object
                    setAccountAuthenticatorResult(resultIntent.getExtras());
                    setResult(RESULT_OK, resultIntent);
                    finish();
                } else {
                    // in this case the user is not authenticated so we show an error message
                    mErrorTextView.setText(userModel.getErrorMessage());
                    mErrorTextView.setVisibility(View.VISIBLE);
                }
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                mProgressAlertDialog.dismiss();
                // in this case the user is not authenticated so we show an error message
                mErrorTextView.setText(error.toString());
                mErrorTextView.setVisibility(View.VISIBLE);
            }
        }
        );
        mProgressAlertDialog = new ProgressAlertDialog();
        mProgressAlertDialog.show(getSupportFragmentManager(), PROGRESS_DIALOG_TAG);
        // Now we add the request to the queue
        requestQueue.add(jsObjRequest);
    }
}
