package uk.co.massimocarli.android.ugho.activity.list;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import uk.co.massimocarli.android.ugho.R;
import uk.co.massimocarli.android.ugho.model.LocalDataModel;
import uk.co.massimocarli.android.ugho.service.LocalVoteService;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.LinkedList;
import java.util.List;

/**
 * This is the Activity we use to show local data using the Holder pattern
 * <p/>
 * Created by Massimo Carli on 31/05/2013.
 */
public class HolderCustomLocalDataActivity extends FragmentActivity {

    /**
     * The Tag of the Log for this class
     */
    private static final String TAG_LOG = HolderCustomLocalDataActivity.class.getName();

    /**
     * The DateFormatter for the date of the votes
     */
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("E dd MMMM yyyy");

    /**
     * The reference to the ListView for the LocalData
     */
    private ListView mListView;

    /**
     * The Adapter to use
     */
    private ListAdapter mAdapter;

    /**
     * The local list we use for the adapters
     */
    private List<LocalDataModel> mModel = new LinkedList<LocalDataModel>();

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // We assign the layout
        setContentView(R.layout.simple_list_local_data);
        // We get the reference to the
        mListView = (ListView) findViewById(R.id.listView);
        // We create the adapters to assign to the listView
        mAdapter = new BaseAdapter() {

            class Holder {

                TextView dateTextView;
                TextView loveVoteTextView;
                TextView healthVoteTextView;
                TextView workVoteTextView;
                TextView luckVoteTextView;

            }

            @Override
            public int getCount() {
                return mModel.size();
            }

            @Override
            public Object getItem(int position) {
                return mModel.get(position);
            }

            @Override
            public long getItemId(int position) {
                // Get the item at the given position
                LocalDataModel model = (LocalDataModel) getItem(position);
                return model.id;
            }

            @Override
            public View getView(int position, View view, ViewGroup viewGroup) {
                // We create the Holder reference
                Holder holder = null;
                // Here we test if the given View is null. If not we can reuse it otherwise
                // we have to create a new one inflating it
                if (view == null) {
                    // We have to inflate
                    view = getLayoutInflater().inflate(R.layout.custom_list_item, null);
                    // We create the Holder
                    holder = new Holder();
                    // We get the UI elements reference
                    holder.dateTextView = (TextView) view.findViewById(R.id.list_item_date);
                    holder.loveVoteTextView = (TextView) view.findViewById(R.id.list_item_love_vote);
                    holder.healthVoteTextView = (TextView) view.findViewById(R.id.list_item_health_vote);
                    holder.workVoteTextView = (TextView) view.findViewById(R.id.list_item_work_vote);
                    holder.luckVoteTextView = (TextView) view.findViewById(R.id.list_item_luck_vote);
                    // We save the holder as tag
                    view.setTag(holder);
                } else {
                    // We get the Holder from the View
                    holder = (Holder) view.getTag();
                }
                // We get the current value from the Model
                final LocalDataModel itemModel = (LocalDataModel) getItem(position);
                // Set the values to the UI elements
                holder.dateTextView.setText(DATE_FORMAT.format(itemModel.entryDate));
                holder.loveVoteTextView.setText(getResources().getString(R.string.love_value_pattern, itemModel.loveVote));
                holder.healthVoteTextView.setText(getResources().getString(R.string.health_value_pattern, itemModel.healthVote));
                holder.workVoteTextView.setText(getResources().getString(R.string.work_value_pattern, itemModel.workVote));
                holder.luckVoteTextView.setText(getResources().getString(R.string.luck_value_pattern, itemModel.luckVote));
                // We return the View
                return view;
            }
        };
        // We assign the adapters to the ListView
        mListView.setAdapter(mAdapter);
    }

    @Override
    protected void onStart() {
        super.onStart();
        // We get the model
        final LocalVoteService.VoteTransferObject result = LocalVoteService.sLocalVoteService.loadVotes(0, 100);
        // We update the adapters
        mModel.clear();
        mModel.addAll(result.mData);
        // We set the adapters again to update it
        mListView.setAdapter(mAdapter);
    }
}