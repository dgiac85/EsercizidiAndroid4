package uk.co.massimocarli.android.ugho.account;

import android.accounts.*;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONException;
import org.json.JSONObject;
import uk.co.massimocarli.android.ugho.R;
import uk.co.massimocarli.android.ugho.model.UserModel;
import uk.co.massimocarli.android.ugho.util.MD5Utility;

/**
 * Created by massimocarli on 19/07/13.
 */
public class UghoAuthenticator extends AbstractAccountAuthenticator {

    /**
     * The reference to the Context
     */
    private final Context mContext;

    private final RequestQueue mRequestQueue;

    /**
     * Creates a UghoAuthenticator from a reference to the Context
     *
     * @param context The Context
     */
    public UghoAuthenticator(final Context context) {
        super(context);
        this.mContext = context;
        // We initialize the VolleyQueue
        mRequestQueue = Volley.newRequestQueue(context);
    }

    @Override
    public Bundle editProperties(AccountAuthenticatorResponse accountAuthenticatorResponse, String s) {
        Intent editIntent = new Intent(mContext, UghoAccountPreferenceActivity.class);
        Bundle returnBundle = new Bundle();
        returnBundle.putParcelable(AccountManager.KEY_INTENT, editIntent);
        return returnBundle;
    }

    @Override
    public Bundle addAccount(AccountAuthenticatorResponse response, String accountType, String authTokenType,
                             String[] requiredFeatures, Bundle options) throws NetworkErrorException {
        // Here we create the Intent we use to launch the Activity that asks the credentials to the user
        // We already know the name of the Activity
        Intent loginIntent = new Intent(mContext, UghoAuthActivity.class);
        // We pass the reference to the response that is an object tha the Activity will use
        // to return the response back
        loginIntent.putExtra(AccountManager.KEY_ACCOUNT_AUTHENTICATOR_RESPONSE, response);
        // We pass to the Activity some parameters about the account name and token name for our account
        loginIntent.putExtra(UghoAuthActivity.ACCOUNT_TYPE_PARAM, AccountConst.UGHO_ACCOUNT_TYPE);
        loginIntent.putExtra(UghoAuthActivity.TOKEN_TYPE_PARAM, AccountConst.UGHO_TOKEN_TYPE);
        // We put the Intent for the credential Activity into a property of the returning bundle
        Bundle returnBundle = new Bundle();
        returnBundle.putParcelable(AccountManager.KEY_INTENT, loginIntent);
        // We return the Bundle
        return returnBundle;
    }

    @Override
    public Bundle confirmCredentials(final AccountAuthenticatorResponse response, Account account, Bundle options) throws NetworkErrorException {
        if (options != null && options.containsKey(AccountManager.KEY_PASSWORD)) {
            final String password = options.getString(AccountManager.KEY_PASSWORD);
            final String loginUrl = mContext.getResources().getString(R.string.login_url,
                    account.name, MD5Utility.md5(password));
            JsonObjectRequest jsObjRequest = new JsonObjectRequest(Request.Method.GET, loginUrl, null, new Response.Listener<JSONObject>() {

                @Override
                public void onResponse(JSONObject jsonResponse) {
                    // Read the token
                    String accessToken = null;
                    try {
                        accessToken = jsonResponse.getString("token");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    // We get the UserModel from the response
                    UserModel userModel = UserModel.fromJson(jsonResponse);
                    final Bundle result = new Bundle();
                    result.putBoolean(AccountManager.KEY_BOOLEAN_RESULT, !userModel.hasError());
                    result.putString(AccountManager.KEY_AUTHTOKEN, accessToken);
                    response.onResult(result);
                }
            }, new Response.ErrorListener() {

                @Override
                public void onErrorResponse(VolleyError error) {
                    final Bundle result = new Bundle();
                    result.putBoolean(AccountManager.KEY_BOOLEAN_RESULT, false);
                    result.putString(AccountManager.KEY_ERROR_MESSAGE, error.getMessage());
                    response.onResult(result);
                }
            }
            );
            mRequestQueue.add(jsObjRequest);
            return null;
        } else {
            Intent checkIntent = new Intent(mContext, UghoAuthActivity.class);
            checkIntent.putExtra(AccountManager.KEY_ACCOUNT_AUTHENTICATOR_RESPONSE, response);
            checkIntent.putExtra(UghoAuthActivity.ACCOUNT_TYPE_PARAM, AccountConst.UGHO_ACCOUNT_TYPE);
            checkIntent.putExtra(UghoAuthActivity.TOKEN_TYPE_PARAM, AccountConst.UGHO_TOKEN_TYPE);
            checkIntent.putExtra(UghoAuthActivity.USERNAME_PARAM, account.name);
            Bundle returnBundle = new Bundle();
            returnBundle.putParcelable(AccountManager.KEY_INTENT, checkIntent);
            // We return the Bundle
            return returnBundle;
        }
    }

    @Override
    public Bundle getAuthToken(final AccountAuthenticatorResponse response, final Account account, String s, Bundle bundle) throws NetworkErrorException {
        Log.i("GET_TOKEN", "METHOD INVOKED!!");
        final AccountManager accountManager = AccountManager.get(mContext);
        // We check if the token is present in cache
        // In this case we have to get the password
        final String password = accountManager.getPassword(account);
        if (TextUtils.isEmpty(password)) {
            Bundle tokenLocalBundle = new Bundle();
            // In this case the password is not present so we have to launch the Activity for the
            // credentials.
            Intent intent = new Intent(mContext, UghoAuthActivity.class);
            intent.putExtra(AccountManager.KEY_ACCOUNT_NAME, account.name);
            intent.putExtra(AccountManager.KEY_ACCOUNT_TYPE, account.type);
            intent.putExtra(AccountConst.UGHO_TOKEN_TYPE, AccountConst.UGHO_TOKEN_TYPE);
            intent.putExtra(AccountManager.KEY_ACCOUNT_AUTHENTICATOR_RESPONSE, response);
            // We have to return this Intent into the Bundle
            tokenLocalBundle.putParcelable(AccountManager.KEY_INTENT, intent);
            return tokenLocalBundle;
        } else {
            final String loginUrl = mContext.getResources().getString(R.string.login_token_url,
                    account.name, MD5Utility.md5(password));
            JsonObjectRequest jsObjRequest = new JsonObjectRequest(Request.Method.GET, loginUrl, null, new Response.Listener<JSONObject>() {

                @Override
                public void onResponse(JSONObject jsonResponse) {
                    // Read the token
                    String accessToken = null;
                    try {
                        accessToken = jsonResponse.getString("token");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    // We get the UserModel from the response
                    UserModel userModel = UserModel.fromJson(jsonResponse);
                    final Bundle result = new Bundle();
                    result.putString(AccountManager.KEY_ACCOUNT_NAME, account.name);
                    result.putString(AccountManager.KEY_ACCOUNT_TYPE, account.type);
                    result.putBoolean(AccountManager.KEY_BOOLEAN_RESULT, !userModel.hasError());
                    result.putString(AccountManager.KEY_AUTHTOKEN, accessToken);
                    response.onResult(result);
                }
            }, new Response.ErrorListener() {

                @Override
                public void onErrorResponse(VolleyError error) {
                    final Bundle result = new Bundle();
                    result.putBoolean(AccountManager.KEY_BOOLEAN_RESULT, false);
                    result.putString(AccountManager.KEY_ERROR_MESSAGE, error.getMessage());
                    response.onResult(result);
                }
            }
            );
            mRequestQueue.add(jsObjRequest);
        }
        return null;
    }

    @Override
    public String getAuthTokenLabel(String s) {
        return "UghoToken";
    }

    @Override
    public Bundle updateCredentials(AccountAuthenticatorResponse response, Account account, String s, Bundle bundle) throws NetworkErrorException {
        Intent checkIntent = new Intent(mContext, UghoAuthActivity.class);
        checkIntent.putExtra(AccountManager.KEY_ACCOUNT_AUTHENTICATOR_RESPONSE, response);
        checkIntent.putExtra(UghoAuthActivity.USERNAME_PARAM, account.name);
        checkIntent.putExtra(UghoAuthActivity.TOKEN_TYPE_PARAM, AccountConst.UGHO_TOKEN_TYPE);
        checkIntent.putExtra(UghoAuthActivity.CONFIRM_CREDENTIAL_PARAM, false);
        final Bundle resultBundle = new Bundle();
        resultBundle.putParcelable(AccountManager.KEY_INTENT, checkIntent);
        return resultBundle;
    }

    @Override
    public Bundle hasFeatures(AccountAuthenticatorResponse accountAuthenticatorResponse, Account account, String[] strings) throws NetworkErrorException {
        final Bundle featureBundle = new Bundle();
        featureBundle.putBoolean(AccountManager.KEY_BOOLEAN_RESULT, false);
        return featureBundle;
    }

    @Override
    public Bundle getAccountRemovalAllowed(AccountAuthenticatorResponse response, Account account) throws NetworkErrorException {
        return super.getAccountRemovalAllowed(response, account);
    }
}
