package uk.co.massimocarli.android.ugho.account;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.content.Context;

/**
 * Created by Massimo Carli on 21/07/13.
 */
public final class AccountUtility {

    /**
     * The Private constructor
     */
    private AccountUtility() {
        throw new AssertionError("Never instantiate me!!");
    }

    /**
     * Utility method that returns an Account given its name and type
     *
     * @param context     The Context
     * @param accountName The name for the Account
     * @param accountType The type for the Account
     * @return The requested account or null if not present
     */
    public static Account findAccountByNameAndType(final Context context, final String accountName, final String accountType) {
        final AccountManager accountManager = AccountManager.get(context);
        Account[] accounts = accountManager.getAccountsByType(accountType);
        Account returnAccount = null;
        for (Account account : accounts) {
            if (account.name.equals(accountName)) {
                returnAccount = account;
                break;
            }
        }
        return returnAccount;
    }
}
