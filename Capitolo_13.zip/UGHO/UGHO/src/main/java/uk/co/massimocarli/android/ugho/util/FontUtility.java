package uk.co.massimocarli.android.ugho.util;

import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.widget.TextView;

/**
 * This is an utility class that manages the font of the application
 * <p/>
 * Created by Massimo Carli on 25/06/13.
 */
public final class FontUtility {

    /**
     * The path for the font file
     */
    private static final String BUTTON_FONT_PATH = "font/font_example.ttf";

    /**
     * The Typeface for the Buttons
     */
    private static Typeface buttonFont;

    /**
     * We apply the application font to the given TextView
     *
     * @param textView The TextView we need to apply the font to
     */
    public static void applyFont(TextView textView) {
        if (buttonFont == null) {
            // We get the AssetManager from the Context
            final AssetManager assets = textView.getContext().getAssets();
            // We read the ButtonFont
            buttonFont = Typeface.createFromAsset(assets, BUTTON_FONT_PATH);
        }
        // We apply the font
        textView.setTypeface(buttonFont);
    }
}
