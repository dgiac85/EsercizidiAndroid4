package uk.co.massimocarli.android.ugho.account;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

/**
 * Authorization Service implementation
 * <p/>
 * Created by Massimo Carli on 20/07/13.
 */
public class UghoAuthService extends Service {

    /**
     * Our UghoAuthenticator
     */
    private UghoAuthenticator mUghoAuthenticator;

    public void onCreate() {
        // We create the UghoAuthenticator instance
        mUghoAuthenticator = new UghoAuthenticator(this);
    }

    public void onDestroy() {
        // This is never called in production but rarely during the application running
        mUghoAuthenticator = null;
    }

    public IBinder onBind(Intent intent) {
        // Here we return the remote interface of the UghoAuthenticator. At the moment it's not
        // important.
        return mUghoAuthenticator.getIBinder();
    }
}
