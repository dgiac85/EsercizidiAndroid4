package uk.co.massimocarli.android.ugho.account;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.accounts.AuthenticatorException;
import android.accounts.OperationCanceledException;
import android.content.AbstractThreadedSyncAdapter;
import android.content.ContentProviderClient;
import android.content.Context;
import android.content.SyncResult;
import android.os.Bundle;
import uk.co.massimocarli.android.ugho.service.Synchronizer;

import java.io.IOException;

/**
 * Created by Massimo Carli on 23/07/13.
 */
public class UghoSyncAdapter extends AbstractThreadedSyncAdapter {

    /**
     * The Reference to the Context
     */
    private Context mContext;

    /**
     * Create
     * @param context
     */
    public UghoSyncAdapter(final Context context){
        super(context, true);
        this.mContext = context;
    }

    @Override
    public void onPerformSync(Account account, Bundle bundle, String s, ContentProviderClient contentProviderClient, SyncResult syncResult) {
        String authToken = null;
        try {
            authToken = AccountManager.get(mContext).blockingGetAuthToken(account, AccountConst.UGHO_TOKEN_TYPE, true);
            // Using the Token we should synchronized the data
            // NOTE: Our implementation doesn't use account.
            Synchronizer.syncLocalData(mContext);
        } catch (AuthenticatorException e) {
            e.printStackTrace();
            syncResult.stats.numAuthExceptions++;
        } catch (OperationCanceledException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
            syncResult.stats.numIoExceptions++;
        }

    }
}
