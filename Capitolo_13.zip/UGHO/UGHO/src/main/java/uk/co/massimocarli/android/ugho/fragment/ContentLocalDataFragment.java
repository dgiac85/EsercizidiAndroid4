package uk.co.massimocarli.android.ugho.fragment;


import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;
import com.actionbarsherlock.app.SherlockListFragment;
import uk.co.massimocarli.android.ugho.R;
import uk.co.massimocarli.android.ugho.content.UghoDB;
import uk.co.massimocarli.android.ugho.content.dao.DAO;
import uk.co.massimocarli.android.ugho.content.dao.LocalDataCursorFactory;
import uk.co.massimocarli.android.ugho.model.LocalDataModel;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 * Created by Massimo Carli on 15/06/13.
 */
public class ContentLocalDataFragment extends SherlockListFragment {

    /**
     * The tag for the log
     */
    private static final String TAG_LOG = ContentLocalDataFragment.class.getName();

    /**
     * The DateFormatter for the date of the votes
     */
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("E dd MMMM yyyy");

    /**
     * The array of the columns
     */
    private static final String[] FROM = {UghoDB.HoroVote.ENTRY_DATE, UghoDB.HoroVote.LOVE_VOTE,
            UghoDB.HoroVote.HEALTH_VOTE, UghoDB.HoroVote.WORK_VOTE, UghoDB.HoroVote.LUCK_VOTE};

    /**
     * The array of the UI items to bind
     */
    private static final int[] TO = {R.id.list_item_date, R.id.list_item_love_vote, R.id.list_item_health_vote,
            R.id.list_item_work_vote, R.id.list_item_luck_vote};

    /**
     * Adapter implementation for the DB access
     */
    private SimpleCursorAdapter mAdapter;

    /**
     * The Cursor reference
     */
    private Cursor mCursor;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // We inflate our custom layout
        View customLayout = inflater.inflate(R.layout.activity_list_layout, null);
        return customLayout;
    }


    @Override
    public void onStart() {
        super.onStart();
        // We get the Cursor from the contentProvider
        mCursor = getActivity().getContentResolver().query(UghoDB.HoroVote.CONTENT_URI, null, null, null, null);
        // BE CAREFUL TO USE THIS METHOD
        getActivity().startManagingCursor(mCursor);
        // We create the Adapter
        mAdapter = new SimpleCursorAdapter(getActivity(), R.layout.custom_list_item, mCursor, FROM, TO);
        mAdapter.setViewBinder(new SimpleCursorAdapter.ViewBinder() {
            @Override
            public boolean setViewValue(View view, Cursor cursor, int i) {
                final TextView outputTextView = (TextView) view;
                final LocalDataModel model = LocalDataModel.fromCursor(cursor);
                // We have to detect which is the item and show it
                switch (view.getId()) {
                    case R.id.list_item_date:
                        outputTextView.setText(DATE_FORMAT.format(model.entryDate));
                        break;
                    case R.id.list_item_love_vote:
                        outputTextView.setText(getResources().getString(R.string.love_value_pattern,
                                model.loveVote));
                        break;
                    case R.id.list_item_health_vote:
                        outputTextView.setText(getResources().getString(R.string.health_value_pattern,
                                model.healthVote));
                        break;
                    case R.id.list_item_work_vote:
                        outputTextView.setText(getResources().getString(R.string.work_value_pattern,
                                model.workVote));
                        break;
                    case R.id.list_item_luck_vote:
                        outputTextView.setText(getResources().getString(R.string.luck_value_pattern,
                                model.luckVote));
                        break;
                }
                return true;
            }
        });
        setListAdapter(mAdapter);
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        Toast.makeText(getActivity(), "Selected position: " + position, Toast.LENGTH_SHORT).show();
    }

}
