package uk.co.massimocarli.android.ugho.settings;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.preference.DialogPreference;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import uk.co.massimocarli.android.ugho.R;
import uk.co.massimocarli.android.ugho.util.Zodiac;
import uk.co.massimocarli.android.ugho.widget.CalendarChooser;

import java.io.*;
import java.util.Date;

/**
 * Created by Massimo Carli on 04/07/13.
 */
public class ShowPreference extends DialogPreference {

    /**
     * The path for the settings file
     */
    private final static String PREFS_FILE_PATH = "shared_prefs/uk.co.massimocarli.android.ugho_preferences.xml";

    /**
     * The size of the buffer
     */
    private final static int BUFFER_SIZE = 1024;


    /**
     * The CalendarChooser
     */
    private CalendarChooser mCalendarChooser;

    public ShowPreference(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public ShowPreference(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    @Override
    protected View onCreateDialogView() {
        // We inflate the layout for the Dialog
        final LayoutInflater inflater = LayoutInflater.from(getContext());
        final View textContainer = inflater.inflate(R.layout.settings_show_file, null);
        // The reference to the TextView
        final TextView settingsTextView = (TextView) textContainer.findViewById(R.id.settings_show_file);
        // We get the path for the application
        PackageManager packageManager = getContext().getPackageManager();
        String applicationPackage = getContext().getPackageName();
        String applicationPath = null;
        try {
            PackageInfo packageInfo = packageManager.getPackageInfo(applicationPackage, 0);
            applicationPath = packageInfo.applicationInfo.dataDir;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        // We show the file content
        FileInputStream settingsInputStream = null;
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            File prefsFile = new File(applicationPath, PREFS_FILE_PATH);
            settingsInputStream = new FileInputStream(prefsFile);
            byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead = 0;
            while ((bytesRead = settingsInputStream.read(buffer, 0, buffer.length)) > 0) {
                baos.write(buffer, 0, bytesRead);
            }
            final byte[] prefsAsBytes = baos.toByteArray();
            final String textToShow = new String(prefsAsBytes);
            baos.close();
            settingsTextView.setText(textToShow);
        } catch (IOException e) {
            e.printStackTrace();
            settingsTextView.setText("Error:" + e.getCause());
        } finally {
            if (settingsInputStream != null) {
                try {
                    settingsInputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        // We return the Layout for the dialog
        return textContainer;
    }

}
