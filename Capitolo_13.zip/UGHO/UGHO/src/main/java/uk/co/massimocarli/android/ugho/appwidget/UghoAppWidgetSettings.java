package uk.co.massimocarli.android.ugho.appwidget;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;
import com.actionbarsherlock.app.SherlockFragmentActivity;
import uk.co.massimocarli.android.ugho.R;

/**
 * Created by massimocarli on 18/07/13.
 */
public class UghoAppWidgetSettings extends SherlockFragmentActivity {

    /**
     * The Preference name for Widget
     */
    public static final String APP_WIDGET_PREFS = ".prefs.UghoAppWidgetSettings";

    /**
     * The key in the preferences for the current color
     */
    public static final String CURRENT_COLOR_KEY = ".key.CURRENT_COLOR_KEY";

    /**
     * The current preferences
     */
    private SharedPreferences mPrefs;

    /**
     * The widgetId to manage
     */
    private int mWidgetId;

    /**
     * The View for the output color
     */
    private View mOutputView;

    /**
     * The Key for the color for the widget
     */
    private String mColorKey;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.widget_conf_layout);
        setResult(RESULT_CANCELED);
        // We read the preferences
        mPrefs = getSharedPreferences(APP_WIDGET_PREFS, Context.MODE_PRIVATE);
        // We read the widgetId to manage
        mWidgetId = getWidgetId(getIntent());
        // We get the reference to the output
        mOutputView = findViewById(R.id.widget_current_color);
        // We calculate the key
        mColorKey = CURRENT_COLOR_KEY + mWidgetId;
        // We read the current color
        final int currentColor = mPrefs.getInt(mColorKey, Color.BLACK);
        mOutputView.setBackgroundColor(currentColor);
    }

    public void changeColor(final View button) {
        int newColor = 0;
        switch (button.getId()) {
            case R.id.widget_red_button:
                newColor = Color.RED;
                break;
            case R.id.widget_green_button:
                newColor = Color.GREEN;
                break;
            case R.id.widget_blue_button:
                newColor = Color.BLUE;
                break;
        }
        mOutputView.setBackgroundColor(newColor);
        // We pass the new color to the end
        updateRefresh(newColor);
    }

    /**
     * Utility method that extracts the widgetId
     *
     * @param intent The Intent to manage
     * @return The widgetId
     */
    private int getWidgetId(Intent intent) {
        Bundle extras = intent.getExtras();
        int appWidgetId = 0;
        if (extras != null) {
            appWidgetId = extras.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID,
                    AppWidgetManager.INVALID_APPWIDGET_ID);
        }
        return appWidgetId;
    }

    /**
     * Utility method that updates the config information
     *
     * @param newColor The new color to set
     */
    public void updateRefresh(final int newColor) {
        // We update the color info into the Preferences
        SharedPreferences.Editor editor = mPrefs.edit();
        // We get the widgetId
        int instanceId = getWidgetId(getIntent());
        // We update the value
        editor.putInt(mColorKey, newColor);
        editor.commit();
        // We have to notify the update of the widget
        Intent updateIntent = new Intent();
        updateIntent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
        updateIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, new int[]{instanceId});
        Uri updateUri = Uri.withAppendedPath(Uri
                .parse("customappwidget://widget/id/"), String.valueOf(instanceId));
        updateIntent.setData(updateUri);
        sendBroadcast(updateIntent);
        // We return the result
        Intent resultValue = new Intent();
        resultValue.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, instanceId);
        setResult(RESULT_OK, resultValue);
        finish();
    }

}
