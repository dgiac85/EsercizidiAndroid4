package uk.co.massimocarli.android.ugho.service;

import uk.co.massimocarli.android.ugho.model.LocalDataModel;

import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

/**
 * This is the abstract class that abstracts the management of the Votes.
 * <p/>
 * Created by Massimo Carli on 25/06/13.
 */
public abstract class LocalVoteService {

    /**
     * The Tag for the log
     */
    private static final String TAG_LOG = LocalVoteService.class.getName();

    /**
     * The TransfertObject for the votes information
     */
    public static final class VoteTransferObject {

        /**
         * The first index of this set of data
         */
        public final int mFirst;

        /**
         * The number of data in this set
         */
        public final int mLength;

        /**
         * The total number of data
         */
        public final int mTotal;

        /**
         * The set of data in this page
         */
        public final List<LocalDataModel> mData;

        /**
         * Creates a VoteTransferObject that encapsulate information about votes
         *
         * @param data   The set of votes for this page
         * @param first  The index of the first element
         * @param length The length of this page
         * @param total  The total number of objects
         */
        public VoteTransferObject(final List<LocalDataModel> data, final int first, final int length, final int total) {
            this.mData = data;
            this.mFirst = first;
            this.mLength = length;
            this.mTotal = total;
        }

        /**
         * Creates a VoteTransferObject that encapsulate information about votes
         *
         * @param data   The set of votes for this page
         * @param first  The index of the first element
         * @param length The length of this page
         * @param total  The total number of objects
         */
        public static VoteTransferObject create(final List<LocalDataModel> data, final int first, final int length, final int total) {
            return new VoteTransferObject(data, first, length, total);
        }

    }

    /**
     * This method loads the Votes from somewhere in paginated way
     *
     * @param start  The index of the first data
     * @param length The number of data we want
     * @return The list of the entry from the daa source
     */
    public abstract VoteTransferObject loadVotes(final int start, final int length);


    /**
     * The LocalVoteService from local source
     */
    public static final LocalVoteService sLocalVoteService = new LocalLocalVoteService();


    /**
     * Dummy LocalVoteService implementation for local data
     */
    private static class LocalLocalVoteService extends LocalVoteService {

        /**
         * The number of item into the model
         */
        private static final int ITEM_NUMBER = 100;

        /**
         * The max value for the vote
         */
        private static final int MAX_VOTE_NUMBER = 5;


        @Override
        public VoteTransferObject loadVotes(final int first, final int length) {
            // Random object
            final Random rnd = new Random(MAX_VOTE_NUMBER);
            // We simulate the the case of 100 items. We made some check
            // to return the right number of items
            final List<LocalDataModel> data = new LinkedList<LocalDataModel>();
            // Create the starting date
            Calendar startingDate = Calendar.getInstance();
            startingDate.add(Calendar.DATE, -1 * first);
            for (int i = 0; i < length; i++) {
                // Calculate random values
                final int loveValue = Math.abs(rnd.nextInt() % MAX_VOTE_NUMBER) + 1;
                final int healthValue = Math.abs(rnd.nextInt() % MAX_VOTE_NUMBER) + 1;
                final int workValue = Math.abs(rnd.nextInt() % MAX_VOTE_NUMBER) + 1;
                final int luckValue = Math.abs(rnd.nextInt() % MAX_VOTE_NUMBER) + 1;
                // Else we create the item
                final LocalDataModel model = LocalDataModel.create(first + i, startingDate.getTimeInMillis(), loveValue,
                        healthValue, workValue, luckValue);
                data.add(model);
                // Increment date
                startingDate.add(Calendar.DATE, -1);
            }
            // We create the transfer object
            final VoteTransferObject returnObject = VoteTransferObject.create(data, first, length, ITEM_NUMBER);
            return returnObject;
        }
    }

}
