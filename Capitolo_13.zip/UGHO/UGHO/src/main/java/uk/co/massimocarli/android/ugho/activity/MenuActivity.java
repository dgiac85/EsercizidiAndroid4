package uk.co.massimocarli.android.ugho.activity;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.accounts.AccountManagerCallback;
import android.accounts.AccountManagerFuture;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuItem;
import uk.co.massimocarli.android.ugho.R;
import uk.co.massimocarli.android.ugho.account.AccountConst;
import uk.co.massimocarli.android.ugho.account.AccountUtility;
import uk.co.massimocarli.android.ugho.activity.list.*;
import uk.co.massimocarli.android.ugho.conf.Const;
import uk.co.massimocarli.android.ugho.fragment.*;
import uk.co.massimocarli.android.ugho.model.UserModel;

/**
 * This is the Activity we use to show the different options of our application
 * after authentication
 * <p/>
 * Created by Massimo Carli on 31/05/2013.
 */
public class MenuActivity extends SherlockFragmentActivity implements MenuFragment.MenuFragmentListener {

    /**
     * The Tag of the Log for this class
     */
    private static final String TAG_LOG = MenuActivity.class.getName();

    /**
     * The Tag for the MenuFragment
     */
    private static final String MENU_FRAGMENT_TAG = Const.PKG + ".tag.MENU_FRAGMENT_TAG";

    /**
     * The name for the Background Handler
     */
    private static final String BG_HANDLER_NAME = "BG_HANDLER";

    /**
     * The AccountManager reference
     */
    private AccountManager mAccountManager;

    /**
     * The Handler for the bg operations
     */
    private Handler mBgHandler;

    /**
     * The current UserModel
     */
    private UserModel mUserModel;

    /**
     * The last token
     */
    private String mLastToken;


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_fragment);
        // We get the AccountManager
        mAccountManager = AccountManager.get(this);
        // we create the bg Handler
        final HandlerThread mHandlerThread = new HandlerThread(BG_HANDLER_NAME);
        mHandlerThread.start();
        // We get the UserModel
        this.mUserModel = UserModel.load(this);
        if (mUserModel == null) {
            Log.w(TAG_LOG, " You must be logged!");
            final Intent backToLoginIntent = new Intent(this, FirstAccessActivity.class);
            backToLoginIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(backToLoginIntent);
            finish();
        }
        if (savedInstanceState == null) {
            final MenuFragment fragment = new MenuFragment();
            getSupportFragmentManager().beginTransaction().add(R.id.anchor_point, fragment, MENU_FRAGMENT_TAG).commit();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getSupportMenuInflater().inflate(R.menu.main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_logout:
                // We execute logout
                doLogout();
                break;
            case R.id.action_verify:
                // We execute verify
                doVerify();
                break;
            case R.id.action_config:
                // We execute config
                doConfig();
                break;
            case R.id.action_settings:
                // We show the Activity to manage Settings
                final Intent settingsIntent = new Intent(this, SettingsActivity.class);
                startActivity(settingsIntent);
                break;
            case R.id.action_get_token:
                // We get the token and show it
                getToken();
                break;
            case R.id.action_invalidate_token:
                // We invalidate the token
                invalidateToken();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * This is invoked when we press the newDataButton
     */
    @Override
    public void insertNewData() {
        Log.d(TAG_LOG, "We choose to insert new data");
        final Intent newDataIntent = new Intent(this, NewDataActivity.class);
        startActivity(newDataIntent);
    }

    /**
     * This is invoked when we press the oldDataButton
     */
    @Override
    public void viewOldData() {
        Log.d(TAG_LOG, "We choose to view our old data");
        final Intent localDataIntent = new Intent(this, LocalDataActivity.class);
        //final Intent localDataIntent = new Intent(this, SimpleLocalDataActivity.class);
        //final Intent localDataIntent = new Intent(this, SimpleCustomLocalDataActivity.class);
        //final Intent localDataIntent = new Intent(this, CustomLocalDataActivity.class);
        //final Intent localDataIntent = new Intent(this, HolderCustomLocalDataActivity.class);
        //final Intent localDataIntent = new Intent(this, SimpleAdapterLocalDataActivity.class);
        //final Intent localDataIntent = new Intent(this, SimpleAdapterLocalDataListActivity.class);
        //final Intent localDataIntent = new Intent(this, LocalCompleteListActivity.class);
        //final Intent localDataIntent = new Intent(this, AlternateLocalDataActivity.class);
        startActivity(localDataIntent);
    }

    /**
     * This is invoked when we press the remoteDataButton
     */
    @Override
    public void viewRemoteData() {
        Log.d(TAG_LOG, "We choose to view remote data");
        final Intent remoteDataIntent = new Intent(this, RemoteDataActivity.class);
        startActivity(remoteDataIntent);
    }

    /**
     * Utility method to manage logout
     */
    private void doLogout() {
        final String userName = mUserModel.getUsername();
        final Account accountToDelete = AccountUtility.findAccountByNameAndType(this, userName,
                AccountConst.UGHO_ACCOUNT_TYPE);
        mAccountManager.removeAccount(accountToDelete, new AccountManagerCallback<Boolean>() {

            public void run(final AccountManagerFuture<Boolean> amf) {

                Thread waitResult = new Thread() {
                    public void run() {
                        Boolean deleted = null;
                        try {
                            deleted = amf.getResult();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        if (deleted != null) {
                            if (deleted) {
                                // We delete the local information and go back
                                mUserModel.logout(MenuActivity.this);
                                // and go back to the FirstAccessActivity
                                final Intent firstAccessIntent = new Intent(MenuActivity.this, FirstAccessActivity.class);
                                startActivity(firstAccessIntent);
                                finish();
                            }
                        }
                    }
                };
                waitResult.start();
            }

        }, mBgHandler);
    }

    /**
     * Utility method to verify account
     */
    private void doVerify() {
        final String userName = mUserModel.getUsername();
        final Account accountToConfirm = AccountUtility.findAccountByNameAndType(this, userName,
                AccountConst.UGHO_ACCOUNT_TYPE);
        mAccountManager.confirmCredentials(accountToConfirm, null, this, new AccountManagerCallback<Bundle>() {
            @Override
            public void run(AccountManagerFuture<Bundle> amf) {
                Bundle confirmBundle = null;
                try {
                    confirmBundle = amf.getResult();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (confirmBundle != null) {
                    Boolean confirmed = confirmBundle.getBoolean(AccountManager.KEY_BOOLEAN_RESULT);
                    if (confirmed != null && confirmed) {
                        Toast.makeText(MenuActivity.this, "VERIFIED", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MenuActivity.this, "NOT VERIFIED", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(MenuActivity.this, "NOT VERIFIED", Toast.LENGTH_SHORT).show();
                }
            }
        }, mBgHandler);
    }

    /**
     * Utility method to config account
     */
    private void doConfig() {
        mAccountManager.editProperties(AccountConst.UGHO_ACCOUNT_TYPE, this, null, mBgHandler);
    }

    /**
     * utility method that asks for the token and prints it
     */
    private void getToken() {
        final String userName = mUserModel.getUsername();
        final Account accountForToken = AccountUtility.findAccountByNameAndType(this, userName,
                AccountConst.UGHO_ACCOUNT_TYPE);
        mAccountManager.getAuthToken(accountForToken, AccountConst.UGHO_TOKEN_TYPE, null, this, new AccountManagerCallback<Bundle>() {
            @Override
            public void run(AccountManagerFuture<Bundle> amf) {
                Bundle confirmBundle = null;
                try {
                    confirmBundle = amf.getResult();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (confirmBundle != null) {
                    String token = confirmBundle.getString(AccountManager.KEY_AUTHTOKEN);
                    if (!TextUtils.isEmpty(token)) {
                        mLastToken = token;
                        Toast.makeText(MenuActivity.this, "Token is: " + token, Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MenuActivity.this, "Token not available", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(MenuActivity.this, "Token not available", Toast.LENGTH_SHORT).show();
                }
            }
        }, mBgHandler);
    }


    /**
     * Invalidate the token
     */
    private void invalidateToken() {
        mAccountManager.invalidateAuthToken(AccountConst.UGHO_ACCOUNT_TYPE, mLastToken);
    }

}