package uk.co.massimocarli.android.ugho.adapters;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

/**
 * This abstract class describe the ability to create a View for the more items in a list
 */
public abstract class MoreViewFactory {

    /**
     * The interface that our decorator implement to receive notification about the click
     * on the more element
     */
    public interface OnMoreViewClickListener {

        /**
         * Invoked when the more View is someway selected
         */
        void moreClicked();

    }

    /**
     * The listener of the more element
     */
    private OnMoreViewClickListener mOnMoreViewClickListener;


    /**
     * We use this method to register the more listener
     *
     * @param onMoreViewClickListener The listener for the more element click
     */
    public void setOnMoreViewClickListener(final OnMoreViewClickListener onMoreViewClickListener) {
        this.mOnMoreViewClickListener = onMoreViewClickListener;
    }

    /**
     * This is a method used by this class implementations to notify the selection of the Next element
     */
    protected void loadNext() {
        if (mOnMoreViewClickListener != null) {
            // If present a Listener we send the notification.
            mOnMoreViewClickListener.moreClicked();
        }
    }

    /**
     * This method returns the View for a given Section.
     *
     * @param ctx         The Context
     * @param position    The position of the Section
     * @param convertView The cell for reuse
     * @param parent      The container of the header
     * @return The view to add to the header
     */
    public abstract View createMoreView(Context ctx, int position, View convertView, ViewGroup parent);

}
