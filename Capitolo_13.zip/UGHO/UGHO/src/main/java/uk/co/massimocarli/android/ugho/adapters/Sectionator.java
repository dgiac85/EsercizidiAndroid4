package uk.co.massimocarli.android.ugho.adapters;

/**
 * This interface describes the property of some object to detect the Section of another
 *
 * @param <E> The parameter type this object is Sectionator of
 */
public interface Sectionator<E> {

    /**
     * This method will return the Section for the given object
     *
     * @param obj The object to "section"
     * @return The Section for the given object or Sectionable.NOT_SECTIONABLE_ITEM if not sectionable
     */
     String getSection(E obj);


}
