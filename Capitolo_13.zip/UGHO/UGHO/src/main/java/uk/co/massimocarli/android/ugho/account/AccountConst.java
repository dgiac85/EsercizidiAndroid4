package uk.co.massimocarli.android.ugho.account;

import uk.co.massimocarli.android.ugho.conf.Const;

/**
 * Created by Massimo Carli on 19/07/13.
 */
public final class AccountConst {

    /**
     * We use this constant for adding the package name to extras
     */
    public static final String PKG = "uk.co.massimocarli.android.ugho.account";

    /**
     * The type of the account for UGHO
     */
    public static final String UGHO_ACCOUNT_TYPE = "uk.co.massimocarli.android.ugho.account";

    /**
     * The type of the token for UGHO
     */
    public static final String UGHO_TOKEN_TYPE = "uk.co.massimocarli.android.ugho.token";

    /**
     * The value for error result
     */
    public static final String KO_RESULT = "KO";

    /**
     * Update frequency every hour
     */
    public static final long SYNC_UPDATE = 3600L;

    /**
     * Private constructor
     */
    private AccountConst() {
        throw new AssertionError("Never instantiate me!");
    }

}
