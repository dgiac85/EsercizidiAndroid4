package uk.co.massimocarli.android.ugho.service.impl;

import android.app.Service;
import android.content.Intent;
import android.os.*;
import android.os.Process;
import uk.co.massimocarli.android.ugho.service.Synchronizer;

/**
 * Created by Massimo Carli on 12/07/13.
 */
public class ComplexSyncService extends Service {

    /**
     * The Looper we need to create the Consumer Thread
     */
    private Looper mConsumerLooper;

    /**
     * The Handler for the Consumer
     */
    private ConsumerHandler mConsumerHandler;

    /**
     * This is a class that describes the Thread which is a cosumer for the
     * messages from the clients
     */
    private final class ConsumerHandler extends Handler {

        /**
         * Creates a ConsumerHandler from the looper of a given Thread
         *
         * @param looper The Looper for this Handler
         */
        public ConsumerHandler(Looper looper) {
            super(looper);
        }

        @Override
        public void handleMessage(Message msg) {
            // Here we execute the operation related to the sync
            Synchronizer.syncLocalData(ComplexSyncService.this);
            // Here it's important we stop the service if there are not other
            // requests. To do this we use the information about the startId
            // that we passed through the arg1 of the Message
            stopSelf(msg.arg1);
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        // We create a specialisation of a Thread that has a Looper. We give
        // it the priority related to background process
        HandlerThread handlerThread = new HandlerThread("ComplexSyncService",
                Process.THREAD_PRIORITY_BACKGROUND);
        // We start the Thread creating the Looper
        handlerThread.start();

        // Get the HandlerThread's Looper and use it for our Handler
        mConsumerLooper = handlerThread.getLooper();
        // We use the Looper to create the related Handler
        mConsumerHandler = new ConsumerHandler(mConsumerLooper);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // This method is called when the receive an Intent send with the startService method. We create
        // a Message for the ConsumerHandler
        Message msg = mConsumerHandler.obtainMessage();
        // We save the startId into the Message arg1
        msg.arg1 = startId;
        // We send the message to the ConsumerHandler fr processing
        mConsumerHandler.sendMessage(msg);
        // We want to restart if killed. No matter if Intent is null. We don't use it
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
