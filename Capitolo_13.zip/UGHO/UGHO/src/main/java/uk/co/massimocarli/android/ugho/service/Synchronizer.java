package uk.co.massimocarli.android.ugho.service;

import android.content.ContentProviderOperation;
import android.content.ContentResolver;
import android.content.Context;
import android.content.OperationApplicationException;
import android.database.Cursor;
import android.os.RemoteException;
import android.util.Log;
import uk.co.massimocarli.android.ugho.content.UghoDB;
import uk.co.massimocarli.android.ugho.model.LocalDataModel;
import uk.co.massimocarli.android.ugho.net.RestManager;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Massimo Carli on 12/07/13.
 */
public final class Synchronizer {

    /**
     * The tag for the log
     */
    public static final String TAG_LOG = Synchronizer.class.getName();

    /**
     * This is the value of the sync column for synched records
     */
    public static final String SYNC_VALUE = "YES";

    /**
     * The private constructor
     */
    private Synchronizer() {
        throw new AssertionError("Never instantiate me! I'm an utility class!!");
    }

    /**
     * This method synchronize the local information with a server
     *
     * @param context The context
     */
    public static void syncLocalData(final Context context) {
        // We create the ContentResolver
        final ContentResolver contentResolver = context.getContentResolver();
        // We read the information from the DB that are not synchronized
        final String where = new StringBuilder(UghoDB.HoroVote.SYNC).append(" IS NULL ").toString();
        final Cursor toUpdateCursor = contentResolver.query(UghoDB.HoroVote.CONTENT_URI, null, where, null, null);
        // The list of the Command we have to execute
        ArrayList<ContentProviderOperation> operations = new ArrayList<ContentProviderOperation>(toUpdateCursor.getCount());
        final String idSelector = new StringBuilder(UghoDB.HoroVote._ID).append(" = ? ").toString();
        while (toUpdateCursor.moveToNext()) {
            // We get the information from the DB
            final LocalDataModel localData = LocalDataModel.fromCursor(toUpdateCursor);
            // We send the data
            try {
                RestManager.sendLocalData(localData);
                // We build the where clause
                final String[] idSelectorArgs = new String[]{String.valueOf(localData.id)};
                // If everything is ok we update the sync status of the given value
                operations.add(ContentProviderOperation.newUpdate(UghoDB.HoroVote.CONTENT_URI)
                        .withValue(UghoDB.HoroVote.SYNC, SYNC_VALUE)
                        .withSelection(idSelector, idSelectorArgs)
                        .withYieldAllowed(true).build());
                Log.d(TAG_LOG, "Added update operation for id " + localData.id);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        toUpdateCursor.close();
        // Here we execute the update in batch
        try {
            contentResolver.applyBatch(UghoDB.AUTHORITY, operations);
        } catch (RemoteException e) {
            e.printStackTrace();
            Log.e(TAG_LOG, "Error applying batch for sync update!", e);
        } catch (OperationApplicationException e) {
            e.printStackTrace();
            Log.e(TAG_LOG, "Error applying batch for sync update!", e);
        }
    }
}
