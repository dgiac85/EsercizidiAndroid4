package uk.co.massimocarli.android.ugho.activity;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.accounts.AccountManagerCallback;
import android.accounts.AccountManagerFuture;
import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import com.actionbarsherlock.app.SherlockFragmentActivity;
import uk.co.massimocarli.android.ugho.R;
import uk.co.massimocarli.android.ugho.account.AccountConst;
import uk.co.massimocarli.android.ugho.account.AccountUtility;
import uk.co.massimocarli.android.ugho.fragment.FirstAccessFragment;
import uk.co.massimocarli.android.ugho.model.UserModel;
import uk.co.massimocarli.android.ugho.widget.CalendarGraphChooserDialogFragment;

import java.util.Date;

/**
 * This is the Activity we use for the main menu at the first execution of the app
 */
public class FirstAccessActivity extends SherlockFragmentActivity implements FirstAccessFragment.FirstAccessListener,
        CalendarGraphChooserDialogFragment.OnGraphCalendarChooserListener {

    /**
     * The Tag for the Log
     */
    private static final String TAG_LOG = FirstAccessActivity.class.getName();

    /**
     * The tag we use for the Calendar Fragment
     */
    private static final String CALENDAR_FRAGMENT_TAG = "DATE SELECTION TAG";

    /**
     * The name for the Background Handler
     */
    private static final String BG_HANDLER_NAME = "BG_HANDLER";

    /**
     * Id for the registration request
     */
    private static final int REGISTRATION_REQUEST_ID = 2;

    /**
     * The AccountManager reference
     */
    private AccountManager mAccountManager;

    /**
     * The Handler for the bg operations
     */
    private Handler mBgHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_fragment);
        // We get the AccountManager
        mAccountManager = AccountManager.get(this);
        // we create the bg Handler
        final HandlerThread mHandlerThread = new HandlerThread(BG_HANDLER_NAME);
        mHandlerThread.start();
        mBgHandler = new Handler(mHandlerThread.getLooper());
        // If the user ise already logged we finish. This is useful when we come back
        // from a successful registration or login
        final UserModel userModel = UserModel.load(this);
        if (userModel != null) {
            finish();
        }
        // We insert the Fragment only if it's the first time and the
        // bundle is null
        if (savedInstanceState == null) {
            final FirstAccessFragment fragment = new FirstAccessFragment();
            getSupportFragmentManager().beginTransaction().add(R.id.anchor_point, fragment).commit();
        }
    }

    /**
     * In this case we simply enter into our application with an implicit Intent
     * as done before
     */
    public void enterAsAnonymous() {
        CalendarGraphChooserDialogFragment dateDialog = CalendarGraphChooserDialogFragment.
                getCalendarChooserDialog(new Date());
        dateDialog.show(getSupportFragmentManager(), CALENDAR_FRAGMENT_TAG);
    }

    /**
     * Invoked to start the registration process
     */
    public void doRegistration() {
        // We create the Intent for the Registration
        final Intent registrationIntent = new Intent(RegisterActivity.REGISTRATION_ACTION);
        startActivityForResult(registrationIntent, REGISTRATION_REQUEST_ID);
    }

    /**
     * This method is invoked when we press the Login button.
     */
    public void doLogin() {
        mAccountManager.addAccount(AccountConst.UGHO_ACCOUNT_TYPE, AccountConst.UGHO_TOKEN_TYPE, null, null,
                this, new AccountManagerCallback<Bundle>() {

            public void run(final AccountManagerFuture<Bundle> amf) {
                Bundle result = null;
                try {
                    result = amf.getResult();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (result != null) {
                    final String accountName = result.getString(AccountManager.KEY_ACCOUNT_NAME);
                    if (accountName != null) {
                        final String accountType = result.getString(AccountManager.KEY_ACCOUNT_TYPE);
                        // In this case everything is ok so we have to create the UserModel
                        // from the data into the Account
                        final Account newAccount = AccountUtility.findAccountByNameAndType(FirstAccessActivity.this,
                                accountName, accountType);
                        final UserModel userModel = UserModel.fromAccount(FirstAccessActivity.this, newAccount);
                        // We save the UserModel
                        userModel.save(FirstAccessActivity.this);
                        // we go to the main
                        final Intent mainIntent = new Intent(FirstAccessActivity.this, MenuActivity.class);
                        startActivity(mainIntent);
                        finish();
                    }
                }
            }
        }, mBgHandler);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REGISTRATION_REQUEST_ID) {
            // We check the result
            switch (resultCode) {
                case RESULT_OK:
                    // The registration is successful. We close this activity and go to the
                    // Main after getting the result
                    final UserModel userModel = (UserModel) data.getParcelableExtra(RegisterActivity.USER_DATA_EXTRA);
                    // We save the UserModel
                    userModel.save(this);
                    // We go to the main
                    final Intent detailIntent = new Intent(ShowUserDataActivity.SHOW_USER_ACTION);
                    startActivity(detailIntent);
                    break;
                case RESULT_CANCELED:
                    // Login cancelled so we do nothing
                    break;
            }
        }
    }

    @Override
    public void dateSelected(CalendarGraphChooserDialogFragment source, Date selectedDate) {
        // We create the UserModel with the given date
        UserModel userData = UserModel.create(selectedDate.getTime());
        // We save the UserData
        userData.save(this);
        // We go ahead to the MainActivity
        final Intent anonymousIntent = new Intent(this, MenuActivity.class);
        startActivity(anonymousIntent);
        finish();
    }

    @Override
    public void selectionCanceled(CalendarGraphChooserDialogFragment source) {
        // We do nothing
    }
}
