package uk.co.massimocarli.android.animationtest;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.widget.*;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Created by Massimo Carli on 16/07/13.
 */
public class CameraAnimationFragment extends Fragment {

    /**
     * Number of elements into the gridView
     */
    private static final int ELEMENT_DIM = 100;

    /**
     * The GridView to animate
     */
    private GridView mGridView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_camera_animation, null);
        // Get the data from the GridView
        String[] data = new String[ELEMENT_DIM];
        for (int i = 0; i < data.length; i++) {
            data[i] = "LABEL #" + i;
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_list_item_1, data);
        final GridView gridView = (GridView) view.findViewById(R.id.animatedView);
        gridView.setAdapter(adapter);
        // We create the animation
        final Animation cameraAnimation = new CameraAnimation();
        // The Button reference
        final Button startButton = (Button) view.findViewById(R.id.startButton);
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gridView.startAnimation(cameraAnimation);
            }
        });
        // we return the View
        return view;
    }


}
