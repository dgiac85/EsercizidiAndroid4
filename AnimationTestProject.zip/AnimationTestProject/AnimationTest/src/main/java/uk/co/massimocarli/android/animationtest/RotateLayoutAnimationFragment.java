package uk.co.massimocarli.android.animationtest;

/**
 * Created by Massimo Carli on 16/07/13.
 */
public class RotateLayoutAnimationFragment extends AbstractLayoutAnimationFragment {


    @Override
    public int getLayoutId() {
        return R.layout.fragment_rotate_layout_animation;
    }
}
