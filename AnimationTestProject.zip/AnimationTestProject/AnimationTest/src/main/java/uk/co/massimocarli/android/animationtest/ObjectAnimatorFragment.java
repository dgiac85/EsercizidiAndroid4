package uk.co.massimocarli.android.animationtest;

import uk.co.massimocarli.android.animationtest.R;
import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

/**
 * Created by Massimo Carli on 16/07/13.
 */
public class ObjectAnimatorFragment extends Fragment {

    /**
     * The set to animate
     */
    private AnimatorSet mAnimatorSet;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_object_animator, null);
        // We get the ImageView reference
        ImageView heartView = (ImageView) view.findViewById(R.id.heart_image);
        // We create the adapter to wrap the ImageView
        ImageViewSizeAdapter adapter = new ImageViewSizeAdapter(heartView);
        // We inflate the AnimatorSet
        mAnimatorSet = (AnimatorSet) AnimatorInflater.loadAnimator(getActivity(), R.animator.beating);
        // We set the adapter as Target
        mAnimatorSet.setTarget(adapter);
        // Return the View
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        mAnimatorSet.start();
    }

}
