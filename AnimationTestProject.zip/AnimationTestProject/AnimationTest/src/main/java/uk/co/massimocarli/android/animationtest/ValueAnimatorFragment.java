package uk.co.massimocarli.android.animationtest;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Created by Massimo Carli on 16/07/13.
 */
public class ValueAnimatorFragment extends Fragment {

    /**
     * Tells if the animation is running or not;
     */
    private AtomicBoolean mRunning = new AtomicBoolean();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_value_animator, null);
        // Reference to SeekBar
        final SeekBar endBar = (SeekBar) view.findViewById(R.id.endSeekBar);
        final SeekBar durationBar = (SeekBar) view.findViewById(R.id.durationSeekBar);
        // Reference to the output
        final TextView output = (TextView) view.findViewById(R.id.output_value);
        // We register the button
        final Button startButton = (Button) view.findViewById(R.id.startButton);

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // We get the value for the end value and duration
                final int maxValue = endBar.getProgress();
                final int duration = durationBar.getProgress();
                // We show the current startValue
                output.setText(String.valueOf(0));
                // We manage the animation
                startAnimation(output, maxValue, duration);
            }
        });
        return view;
    }


    /**
     * Here we put the code to manage the ValueAnimation
     *
     * @param output   The TextView to show the value to
     * @param endValue The last value to show for the animation
     * @param duration The duration of the animation
     */
    private void startAnimation(final TextView output, final int endValue, final long duration) {
        if (mRunning.get()) {
            // We skip if the animation is running
            return;
        }
        // We create the ValueAnimator that manges integers
        ValueAnimator valueAnimator = ValueAnimator.ofInt(0, endValue);
        // We set the duration of the animation
        valueAnimator.setDuration(duration);
        // We want to be notified of the changes in value
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {

            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                // The animator gives us the current value
                String value = animation.getAnimatedValue().toString();
                output.setText(value);
            }
        });
        valueAnimator.addListener(new Animator.AnimatorListener() {

            @Override
            public void onAnimationCancel(Animator animator) {
                Toast.makeText(getActivity(), "onAnimationCancel", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAnimationEnd(Animator animator) {
                mRunning.set(false);
                Toast.makeText(getActivity(), "onAnimationEnd", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAnimationRepeat(Animator animator) {
                Toast.makeText(getActivity(), "onAnimationRepeat", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAnimationStart(Animator animator) {
                Toast.makeText(getActivity(), "onAnimationStart", Toast.LENGTH_SHORT).show();
            }

        });
        mRunning.set(true);
        // We start the animator
        valueAnimator.start();

    }
}
