package uk.co.massimocarli.android.animationtest;

import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout.LayoutParams;

/**
 * Created by Massimo Carli on 16/07/13.
 */
public class ImageViewSizeAdapter {

    /*
     * The adaptee View
     */
    private View mAdaptee;

    /**
     * We create a ImageViewSizeAdapter from the source View
     *
     * @param adaptee The View to adapt
     */
    public ImageViewSizeAdapter(View adaptee) {
        this.mAdaptee = adaptee;
    }

    /**
     * This method is useful for changing size
     *
     * @param size The new size of the adaptee View
     */
    public void setSize(int size) {
        // We get the size of the item
        LayoutParams layoutParams = new LayoutParams(size, size);
        layoutParams.gravity = Gravity.CENTER;
        mAdaptee.setLayoutParams(layoutParams);
    }

}
