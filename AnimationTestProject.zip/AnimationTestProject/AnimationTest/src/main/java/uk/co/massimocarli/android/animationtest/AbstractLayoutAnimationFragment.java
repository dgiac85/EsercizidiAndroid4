package uk.co.massimocarli.android.animationtest;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.GridView;

/**
 * Created by Massimo Carli on 16/07/13.
 */
public abstract class AbstractLayoutAnimationFragment extends Fragment {

    /**
     * Number of elements into the gridView
     */
    private static final int ELEMENT_DIM = 100;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View view = inflater.inflate(getLayoutId(), null);
        // Get the data from the GridView
        String[] data = new String[ELEMENT_DIM];
        for (int i = 0; i < data.length; i++) {
            data[i] = "LABEL #" + i;
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_list_item_1, data);
        GridView gridView = (GridView) view.findViewById(R.id.animatedView);
        gridView.setAdapter(adapter);
        return view;
    }

    public abstract int getLayoutId();

}
