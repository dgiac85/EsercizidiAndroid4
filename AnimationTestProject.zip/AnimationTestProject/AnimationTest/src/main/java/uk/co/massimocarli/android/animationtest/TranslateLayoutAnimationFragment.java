package uk.co.massimocarli.android.animationtest;

/**
 * Created by Massimo Carli on 16/07/13.
 */
public class TranslateLayoutAnimationFragment extends AbstractLayoutAnimationFragment {


    @Override
    public int getLayoutId() {
        return R.layout.fragment_translate_layout_animation;
    }
}
