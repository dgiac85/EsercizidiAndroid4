package uk.co.massimocarli.android.animationtest;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.GridView;

/**
 * Created by Massimo Carli on 16/07/13.
 */
public class CustomAnimationFragment extends Fragment {


    /**
     * Number of elements into the gridView
     */
    private static final int ELEMENT_DIM = 100;

    /**
     * The reference to the Animation
     */
    private InvertAnimation mInvertAnimation;

    /**
     * The GridView to animate
     */
    private GridView mGridView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_custom_animation, null);
        // Get the data from the GridView
        String[] data = new String[ELEMENT_DIM];
        for (int i = 0; i < data.length; i++) {
            data[i] = "LABEL #" + i;
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_list_item_1, data);
        mGridView = (GridView) view.findViewById(R.id.animatedView);
        mGridView.setAdapter(adapter);
        // We initialize the animation
        mInvertAnimation = new InvertAnimation();
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        mGridView.startAnimation(mInvertAnimation);
    }
}
