package uk.co.massimocarli.android.animationtest;

import android.graphics.Matrix;
import android.view.animation.Animation;
import android.view.animation.Transformation;

/**
 * Created by Massimo Carli on 16/07/13.
 */
public class InvertAnimation extends Animation {

    /**
     * The default rate for the rotation
     */
    private final static float DEFAULT_ROTATION_RATE = 1.0f;

    /**
     * The current rate of the rotation
     */
    private float rate = DEFAULT_ROTATION_RATE;

    /**
     * X for the Pivot
     */
    private float pivotX;

    /**
     * Y for the Pivot
     */
    private float pivotY;

    @Override
    public void initialize(int width, int height, int parentWidth,
                           int parentHeight) {
        super.initialize(width, height, parentWidth, parentHeight);
        // We center the  pivot
        pivotX = width / 2;
        pivotY = height / 2;
        // Se the duration into 1 second
        setDuration(1000L);
        // We set the animation as peristence
        setFillAfter(true);
    }

    public float getRate() {
        return rate;
    }

    public void setRate(float rate) {
        this.rate = rate;
    }

    @Override
    protected void applyTransformation(float interpolatedTime, Transformation t) {
        // We get the reference to the current transformation Matrix
        Matrix matrix = t.getMatrix();
        // We apply our transformation
        float rotateValue = interpolatedTime * 180f * rate;
        rotateValue = (rotateValue < 180f) ? rotateValue : 180f;
        matrix.setRotate(rotateValue, pivotX, pivotY);
    }

}
