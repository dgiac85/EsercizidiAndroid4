package uk.co.massimocarli.android.animationtest;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.ListFragment;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Massimo Carli on 16/07/13.
 */
public class ExampleListFragment extends ListFragment {

    /**
     * Interface to implement to be notify of the selection
     */
    public interface OnExampleSelected {

        /**
         * Invoked to notify a selection in the Example list
         *
         * @param name     The name of the selected item
         * @param position The position in the list of the selected item
         */
        void onItemSelected(final String name, final int position);

    }

    /**
     * The reference to the Activity listener of this ListFragment
     */
    private OnExampleSelected onExampleSelected;

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        if (activity instanceof OnExampleSelected) {
            onExampleSelected = (OnExampleSelected) activity;
        }
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        // We get the Array of examples from the resources
        final String[] exampleArray = getResources().getStringArray(R.array.example_list);
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_list_item_1, exampleArray);
        setListAdapter(adapter);
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
        if (onExampleSelected != null) {
            final String exampleName = (String) (l.getAdapter().getItem(position));
            onExampleSelected.onItemSelected(exampleName, position);
        }
    }
}
