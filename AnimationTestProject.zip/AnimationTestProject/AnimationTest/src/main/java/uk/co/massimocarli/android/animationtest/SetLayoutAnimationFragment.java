package uk.co.massimocarli.android.animationtest;

/**
 * Created by Massimo Carli on 16/07/13.
 */
public class SetLayoutAnimationFragment extends AbstractLayoutAnimationFragment {


    @Override
    public int getLayoutId() {
        return R.layout.fragment_set_layout_animation;
    }
}
