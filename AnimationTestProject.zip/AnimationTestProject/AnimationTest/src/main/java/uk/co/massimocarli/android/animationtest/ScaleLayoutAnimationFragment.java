package uk.co.massimocarli.android.animationtest;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by Massimo Carli on 16/07/13.
 */
public class ScaleLayoutAnimationFragment extends AbstractLayoutAnimationFragment {


    @Override
    public int getLayoutId() {
        return R.layout.fragment_scale_layout_animation;
    }
}
