package uk.co.massimocarli.android.animationtest;

import android.os.Bundle;
import android.app.Activity;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.Menu;

public class MainActivity extends FragmentActivity implements ExampleListFragment.OnExampleSelected {

    /**
     * The Tag for the log
     */
    private static final String TAG_LOG = MainActivity.class.getName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (savedInstanceState == null) {
            final ExampleListFragment fragment = new ExampleListFragment();
            getSupportFragmentManager().beginTransaction().add(R.id.anchor_point, fragment).commit();
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public void onItemSelected(String name, int position) {
        Log.d(TAG_LOG, "Selected: " + name);
        Fragment nextFragment = null;
        switch (position) {
            case 0:
                nextFragment = new ValueAnimatorFragment();
                break;
            case 1:
                nextFragment = new ObjectAnimatorFragment();
                break;
            case 2:
                nextFragment = new FrameAnimationFragment();
                break;
            case 3:
                nextFragment = new ScaleLayoutAnimationFragment();
                break;
            case 4:
                nextFragment = new RotateLayoutAnimationFragment();
                break;
            case 5:
                nextFragment = new TranslateLayoutAnimationFragment();
                break;
            case 6:
                nextFragment = new AlphaLayoutAnimationFragment();
                break;
            case 7:
                nextFragment = new SetLayoutAnimationFragment();
                break;
            case 8:
                nextFragment = new CustomAnimationFragment();
                break;
            case 9:
                nextFragment = new CameraAnimationFragment();
                break;
        }
        getSupportFragmentManager().beginTransaction().addToBackStack(name)
                .replace(R.id.anchor_point, nextFragment)
                .commit();
    }
}
