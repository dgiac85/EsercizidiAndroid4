package uk.co.massimocarli.android.animationtest;

import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by Massimo Carli on 16/07/13.
 */
public class FrameAnimationFragment extends Fragment {

    /**
     * The AnimationDrawable
     */
    private AnimationDrawable mAnimationDrawable;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_frame_animation, null);
        // We get the TextView reference
        TextView animatedTextView = (TextView) view.findViewById(R.id.animated_textview);
        // we get the mAnimationDrawable
        mAnimationDrawable = (AnimationDrawable) animatedTextView.getBackground();
        // Return the View
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        mAnimationDrawable.start();
    }


    @Override
    public void onStop() {
        super.onStop();
        mAnimationDrawable.stop();
    }
}
