/**
 *
 */
package uk.co.massimocarli.android.animationtest;

import android.graphics.Camera;
import android.graphics.Matrix;
import android.view.animation.Animation;
import android.view.animation.Transformation;

/**
 * Created by Massimo Carli on 16/07/13.
 */
public class CameraAnimation extends Animation {

    /**
     * The rate to use as a default
     */
    private final static float DEFAULT_ROTATION_RATE = 1.0f;

    /*
     * The current rate of the animation
     */
    private float rate = DEFAULT_ROTATION_RATE;

    /**
     * The X for the pivot
     */
    private float pivotX;

    /**
     * The Y for the pivot
     */
    private float pivotY;

    @Override
    public void initialize(int width, int height, int parentWidth,
                           int parentHeight) {
        super.initialize(width, height, parentWidth, parentHeight);
        // We calculate the pivot position in the center
        pivotX = width / 2;
        pivotY = height / 2;
        // Duration of 1 second
        setDuration(1000L);
        // We make the animation persistent
        setFillAfter(true);
    }

    public float getRate() {
        return rate;
    }

    public void setRate(float rate) {
        this.rate = rate;
    }

    @Override
    protected void applyTransformation(float interpolatedTime, Transformation t) {
        // We get the starting Matrix
        Matrix matrix = t.getMatrix();
        // We create the Camera object
        Camera camera = new Camera();
        // We save the current image
        camera.save();
        // We rotate the camera
        camera.rotateX(interpolatedTime * 60);
        // We apply the transformation to the coordinates
        camera.getMatrix(matrix);
        matrix.preTranslate(-pivotX, -pivotY);
        matrix.postTranslate(pivotX, pivotY);
        // We restore the camera position
        camera.restore();
    }

}
