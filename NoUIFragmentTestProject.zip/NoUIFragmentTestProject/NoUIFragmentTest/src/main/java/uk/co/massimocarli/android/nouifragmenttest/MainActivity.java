package uk.co.massimocarli.android.nouifragmenttest;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.widget.TextView;

public class MainActivity extends FragmentActivity implements CounterFragment.CounterListener {

    /*
     * The output for the counter
     */
    private TextView mOutput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Get the reference to the TextView
        mOutput = (TextView) findViewById(R.id.output);
        // We create the Fragment and put it into the layout
        if (savedInstanceState == null) {
            Fragment fragment = new CounterFragment();
            fragment.setRetainInstance(true);
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.container, fragment).commit();
        }
        Log.i("BUNDLE", "" + savedInstanceState);
    }

    @Override
    public void count(final int countValue) {
        runOnUiThread(new Runnable() {

            @Override
            public void run() {
                mOutput.setText("Counter: " + countValue);
            }
        });
    }

}
