package uk.co.massimocarli.android.ugho.service;

import android.content.Context;
import android.location.Location;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.UserDataHandler;
import uk.co.massimocarli.android.ugho.R;
import uk.co.massimocarli.android.ugho.UghoApplication;
import uk.co.massimocarli.android.ugho.model.UserModel;
import uk.co.massimocarli.android.ugho.util.MD5Utility;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * This is a class that implements the logic related to the LoginManagement
 * <p/>
 * Created by Massimo Carli on 05/06/13.
 */
public final class LoginService {

    /**
     * The Tag for the log
     */
    private static final String TAG_LOG = LoginService.class.getName();

    /**
     * The value for error result
     */
    private static final String KO_RESULT = "KO";

    /**
     * The Singleton instance
     */
    private static LoginService instance;

    /**
     * This is the ResponseHandler which knows how to read a UserModel from the HTTP response
     */
    private ResponseHandler<UserModel> mUserModelResponseHandler = new ResponseHandler<UserModel>() {
        @Override
        public UserModel handleResponse(HttpResponse httpResponse) throws ClientProtocolException, IOException {
            // The UserModel to return
            UserModel userModel = null;
            // Here we have to read the UserModel from the httpResponse
            InputStream content = httpResponse.getEntity().getContent();
            byte[] buffer = new byte[1024];
            int numRead = 0;
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            while ((numRead = content.read(buffer)) != -1) {
                baos.write(buffer, 0, numRead);
            }
            content.close();
            // We create the JSONObject
            try {
                JSONObject resultAsJson = new JSONObject(new String(baos.toByteArray()));
                // We check if the result is ok or not
                final String result = resultAsJson.optString("result", KO_RESULT);
                if (KO_RESULT.equals(result)) {
                    // In this case we had an error
                    userModel = UserModel.fromError(resultAsJson.optString("message"));
                } else {
                    // Here the user is logged so we create the UserModel in the right way
                    final long birthDate = resultAsJson.optLong("birthDate", 0);
                    if (birthDate > 0) {
                        userModel = UserModel.create(birthDate)
                                .withEmail(resultAsJson.optString("email"))
                                .withUsername(resultAsJson.optString("username"))
                                .withLocation(resultAsJson.optString("location"));
                    } else {
                        userModel = UserModel.fromError("Error in birthDate data!");
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
                userModel = UserModel.fromError("JSON error: " + e.getMessage());
            }
            return userModel;
        }
    };

    /**
     * @return The singleton instance of the LoginService
     */
    public synchronized static LoginService get() {
        if (instance == null) {
            instance = new LoginService();
        }
        return instance;
    }

    /**
     * This login implementation just check if the username and values are valid and
     * return a UserModel implementation with some data.
     *
     * @param username The username
     * @param password The password
     * @return The UserModel with user data if logged and null if not
     */
    public UserModel login(final Context context, final String username, final String password) {
        // The return value
        UserModel userModel = null;
        // We calculate the url
        final String loginUrl = context.getResources().getString(R.string.login_url,
                username, MD5Utility.md5(password));
        // We create the HttpClient as a Command executor
        //HttpClient httpClient = new DefaultHttpClient();
        HttpClient httpClient = UghoApplication.getThreadSafeHttpClient();
        // We create the GET request
        HttpGet request = new HttpGet(loginUrl);
        // We execute the command passing an handler
        try {
            userModel = httpClient.execute(request, mUserModelResponseHandler);
        } catch (IOException e) {
            e.printStackTrace();
        }
        // We return the model if any
        return userModel;
    }

}
