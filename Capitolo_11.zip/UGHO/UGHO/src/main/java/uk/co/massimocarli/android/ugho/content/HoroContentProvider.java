package uk.co.massimocarli.android.ugho.content;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;

/**
 * Created by massimocarli on 07/07/13.
 */
public class HoroContentProvider extends ContentProvider {

    /**
     * The SQLiteOpenHelper to access DB
     */
    private SQLiteOpenHelper dbHelper;

    /**
     * The UriMatcher for the Uri recognition
     */
    private final static UriMatcher URI_MATCHER = new UriMatcher(UriMatcher.NO_MATCH);
    private final static int HORO_DIR_INDICATOR = 1;
    private final static int HORO_ITEM_INDICATOR = 2;

    static {
        URI_MATCHER.addURI(UghoDB.AUTHORITY, UghoDB.HoroVote.PATH, HORO_DIR_INDICATOR);
        URI_MATCHER.addURI(UghoDB.AUTHORITY, UghoDB.HoroVote.PATH + "/#", HORO_ITEM_INDICATOR);
    }

    @Override
    public boolean onCreate() {
        dbHelper = new HoroOpenHelper(getContext());
        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        // We get the code from the URI_MATCHER
        final int uriMatcherCode = URI_MATCHER.match(uri);
        Cursor cursor = null;
        String itemId = null;
        StringBuilder whereClause = null;
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        switch (uriMatcherCode) {
            case HORO_ITEM_INDICATOR:
                itemId = uri.getPathSegments().get(1);
                whereClause = new StringBuilder(UghoDB.HoroVote._ID).append(" = ").append(itemId);
                if (selection != null) {
                    whereClause.append(" AND (").append(selection).append(" ) ");
                }
                cursor = db.query(UghoDB.HoroVote.TABLE_NAME, null, whereClause.toString(), selectionArgs,
                        null, null, null);
                break;
            case HORO_DIR_INDICATOR:
                cursor = db.query(UghoDB.HoroVote.TABLE_NAME, null, selection, selectionArgs, null, null, null);
                break;
        }
        // In this case the notify the cursor listener of the reading. It's useful to notify the Adapter
        // that can update their data
        if (cursor != null) {
            cursor.setNotificationUri(getContext().getContentResolver(), UghoDB.HoroVote.CONTENT_URI);
        }
        return cursor;
    }

    @Override
    public String getType(final Uri uri) {
        switch (URI_MATCHER.match(uri)) {
            case HORO_DIR_INDICATOR:
                return UghoDB.HoroVote.MIME_TYPE_DIR;
            case HORO_ITEM_INDICATOR:
                return UghoDB.HoroVote.MIME_TYPE_ITEM;
            default:
                throw new IllegalArgumentException("The Uri " + uri + " is unknown for this ContentProvider");
        }
    }

    @Override
    public Uri insert(Uri uri, ContentValues contentValues) {
        if (URI_MATCHER.match(uri) == HORO_DIR_INDICATOR) {
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            long newTeamId = db.insert(UghoDB.HoroVote.TABLE_NAME, UghoDB.HoroVote.LOCATION, contentValues);
            if (newTeamId > 0) {
                Uri newTeamUri = ContentUris.withAppendedId(UghoDB.HoroVote.CONTENT_URI, newTeamId);
                getContext().getContentResolver().notifyChange(newTeamUri, null);
                return newTeamUri;
            }
        } else {
            throw new IllegalArgumentException("The Uri " + uri + " is unknown for this ContentProvider");
        }
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        String itemId = null;
        StringBuilder whereClause = null;
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        int deleteNumber = 0;
        switch (URI_MATCHER.match(uri)) {
            case HORO_ITEM_INDICATOR:
                itemId = uri.getPathSegments().get(1);
                whereClause = new StringBuilder(UghoDB.HoroVote._ID).append(" = ").append(itemId);
                if (selection != null) {
                    whereClause.append(" AND (").append(selection).append(" ) ");
                }
                deleteNumber = db.delete(UghoDB.HoroVote.TABLE_NAME, whereClause.toString(), selectionArgs);
                break;
            case HORO_DIR_INDICATOR:
                deleteNumber = db.delete(UghoDB.HoroVote.TABLE_NAME, selection, selectionArgs);
                break;
        }
        // In this case the notify the cursor listener of the reading. It's useful to notify the Adapter
        // that can update their data
        if (deleteNumber > 0) {
            getContext().getContentResolver().notifyChange(uri, null);
        }
        return deleteNumber;
    }

    @Override
    public int update(Uri uri, ContentValues contentValues, String selection, String[] selectionArgs) {
        String itemId = null;
        StringBuilder whereClause = null;
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        int updateNumber = 0;
        switch (URI_MATCHER.match(uri)) {
            case HORO_ITEM_INDICATOR:
                itemId = uri.getPathSegments().get(1);
                whereClause = new StringBuilder(UghoDB.HoroVote._ID).append(" = ").append(itemId);
                if (selection != null) {
                    whereClause.append(" AND (").append(selection).append(" ) ");
                }
                updateNumber = db.update(UghoDB.HoroVote.TABLE_NAME, contentValues, whereClause.toString(), selectionArgs);
                break;
            case HORO_DIR_INDICATOR:
                updateNumber = db.update(UghoDB.HoroVote.TABLE_NAME, contentValues, selection, selectionArgs);
                break;
        }
        // In this case the notify the cursor listener of the reading. It's useful to notify the Adapter
        // that can update their data
        if (updateNumber > 0) {
            getContext().getContentResolver().notifyChange(uri, null);
        }
        return updateNumber;
    }
}
