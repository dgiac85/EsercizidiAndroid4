package uk.co.massimocarli.android.ugho.service.impl;

import android.content.Intent;
import uk.co.massimocarli.android.ugho.conf.Const;
import uk.co.massimocarli.android.ugho.model.LocalDataModel;

/**
 * Created by Massimo Carli on 12/07/13.
 */
public final class ServiceUtil {

    /**
     * The Category of all the action of this service
     */
    private static final String HOROSCOPE_CATEGORY = Const.PKG + ".category.HOROSCOPE_CATEGORY";

    /**
     * The action we use to send information about horoscope
     */
    private static final String SEND_DATA_ACTION = Const.PKG + ".action.SEND_DATA_ACTION";


    public static final Intent SYNC_INTENT = new Intent(SEND_DATA_ACTION);

    static {
        SYNC_INTENT.addCategory(HOROSCOPE_CATEGORY);
    }

    /**
     * The private constructor
     */
    private ServiceUtil() {
        throw new AssertionError("Never instantiate me! I'm an utility class!!");
    }

}
