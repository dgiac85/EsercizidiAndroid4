package uk.co.massimocarli.android.ugho.net;

import uk.co.massimocarli.android.ugho.model.LocalDataModel;

import java.io.IOException;

/**
 * Created by Massimo Carli on 12/07/13.
 */
public final class RestManager {

    /**
     * The private constructor
     */
    private RestManager() {
        throw new AssertionError("Never instantiate me! I'm an utility class!!");
    }

    /**
     * This method send the localData to the server
     *
     * @param localData The localData to send
     */
    public static void sendLocalData(final LocalDataModel localData) throws IOException {
        // TODO So far we just simulate waiting some time
        try {
            Thread.sleep(300L);
        } catch (InterruptedException ie) {
        }
    }


}
