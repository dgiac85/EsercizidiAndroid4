package uk.co.massimocarli.android.ugho.service.impl;

import android.app.IntentService;
import android.content.Intent;
import uk.co.massimocarli.android.ugho.service.Synchronizer;

/**
 * Created by Massimo Carli on 12/07/13.
 */
public class IntentSyncService extends IntentService {


    /**
     * Default Constructor
     */
    public IntentSyncService() {
        super("IntentSyncService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        // Here we execute the operation related to the sync
        Synchronizer.syncLocalData(this);
    }
}
