package uk.co.massimocarli.android.dialogfragmenttest.fragment;

import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;
import uk.co.massimocarli.android.dialogfragmenttest.R;

/**
 * This is a Dialog that uses a specific style and theme with a custom data inside
 *
 * @author Massimo Carli - Apr 4, 2013
 */
public class StyledDialogFragment extends DialogFragment {

    /*
     * The Key for the MenuItem in the arguments
     */
    private static final String MENU_ITEM_KEY = "uk.co.massimocarli.android.dialogfragmenttest.fragments.MENU_ITEM_KEY";

    /**
     * Create a StyledDialogFragment with the given
     *
     * @param menuItem The item selected
     * @return The StyledDialogFragment instance
     */
    public static StyledDialogFragment getStyledDialogFragment(MenuFragment.MenuItem menuItem) {
        StyledDialogFragment fragment = new StyledDialogFragment();
        // We create the arguments
        Bundle args = new Bundle();
        args.putSerializable(MENU_ITEM_KEY, menuItem);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // We set the style and theme
        MenuFragment.MenuItem menuItem = (MenuFragment.MenuItem) getArguments().getSerializable(MENU_ITEM_KEY);
        setStyle(menuItem.style, menuItem.theme);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // We use the same layout of the row in the list
        View dialogLayout = inflater.inflate(R.layout.layout_dialog, container, false);
        // We show the related values
        TextView styleView = (TextView) dialogLayout.findViewById(R.id.style_name);
        TextView themeView = (TextView) dialogLayout.findViewById(R.id.theme_name);
        // Set the values
        MenuFragment.MenuItem menuItem = (MenuFragment.MenuItem) getArguments().getSerializable(MENU_ITEM_KEY);
        styleView.setText(menuItem.styleName);
        themeView.setText(menuItem.themeName);
        // Manage the Button
        dialogLayout.findViewById(R.id.close_button).setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // We have to dismiss the Dialog
                dismiss();
            }
        });
        // Return the created layout
        return dialogLayout;
    }

}
