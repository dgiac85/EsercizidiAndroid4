/** Automatically generated file. DO NOT MODIFY */
package com.example.batchactionmodetest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}