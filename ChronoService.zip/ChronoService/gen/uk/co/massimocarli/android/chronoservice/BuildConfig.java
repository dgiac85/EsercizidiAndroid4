/** Automatically generated file. DO NOT MODIFY */
package uk.co.massimocarli.android.chronoservice;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}