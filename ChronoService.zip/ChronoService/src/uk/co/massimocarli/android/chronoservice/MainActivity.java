package uk.co.massimocarli.android.chronoservice;

import java.lang.ref.WeakReference;

import uk.co.massimocarli.android.chronoservice.receiver.TimeBroadcastReceiver;
import uk.co.massimocarli.android.chronoservice.service.ChronoBoundService;
import uk.co.massimocarli.android.chronoservice.service.ChronoCallback;
import uk.co.massimocarli.android.chronoservice.service.ChronoService;
import uk.co.massimocarli.android.chronoservice.service.ServiceUtil;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 
 * @author massimocarli
 *
 */
public class MainActivity extends Activity {
	
	/**
	 * Our implementation of ServiceConnection to get Bound service reference
	 */
	private ServiceConnection mServiceConnection = new ServiceConnection(){

		@Override
		public void onServiceConnected(ComponentName name, IBinder service) {
			// We get the reference to the Service ChronoService using the proper method 
			mChronoService = ChronoService.Stub.asInterface(service);
			Log.i(Conf.TAG_LOG, "We got reference to the bound service: " + mChronoService);
			// We register the callback to the service
			try {
				mChronoService.registerCallback(mChronoCallback);
			} catch (RemoteException e) {
				e.printStackTrace();
			}
		}

		@Override
		public void onServiceDisconnected(ComponentName name) {
			// We unregister the callback to the service
			try {
				mChronoService.unregisterCallback(mChronoCallback);
			} catch (RemoteException e) {
				e.printStackTrace();
			}			
			// We release the reference
			mChronoService = null;
			Log.i(Conf.TAG_LOG, "Reference to the bound service released");
		}
		
	};
	
	/**
	 * The Handler to manage UI update
	 */
	private static class UpdateTimeHandler extends Handler {
		
		/**
		 * The Ref to the Activity
		 */
		private WeakReference<MainActivity> mActivityRef;
		
		public UpdateTimeHandler(final MainActivity activity){
			this.mActivityRef = new WeakReference<MainActivity>(activity);
		}
		
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			// Show the time in textView
			final MainActivity activity = mActivityRef.get();
			if (activity != null) {
				activity.updateTime(msg.obj.toString());				
			}
		}
	}
	
	/**
	 * The Handler for update
	 */
	private UpdateTimeHandler mUpdateTimeHandler;
	
	/**
	 * The TextView for the output
	 */
	private TextView mOutput;
	
	/**
	 * We create the implementation of 
	 */
	private ChronoCallback mChronoCallback = new ChronoCallback.Stub() {
		
		@Override
		public void currentTime(String currentTime) throws RemoteException {
			// This is called from a different Thread so we need to use a Handler to interact
			// with the UI thread
			final Message timeMessage = mUpdateTimeHandler.obtainMessage(0, currentTime);
			mUpdateTimeHandler.sendMessage(timeMessage);
		}
	};
	
	/**
	 * The Broadcast receiver for our broadcast Intent
	 */
	private BroadcastReceiver mTimeReceiver = new BroadcastReceiver(){

		@Override
		public void onReceive(Context context, Intent intent) {
			// We receive the time form the Intent
			final String timeInfo = intent.getStringExtra(ServiceUtil.TIME_EXTRA); 
			// Show into a Toast
			Toast.makeText(getApplicationContext(), timeInfo, Toast.LENGTH_SHORT).show();
		}
		
	};
	
	/**
	 * The reference to the service implementation
	 */
	private ChronoService mChronoService;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		// The reference 
		mOutput = (TextView) findViewById(R.id.time_output);
		// We create the Handler
		mUpdateTimeHandler = new UpdateTimeHandler(this);
	}
	
	@Override
	protected void onStart() {
		super.onStart();
		Log.i(Conf.TAG_LOG, "Activity started");
		final IntentFilter broadcastIntentFilter = new IntentFilter(ServiceUtil.UPDATE_TIME_BROACAST_ACTION);
		registerReceiver(mTimeReceiver, broadcastIntentFilter);
		// We disable the static BroadcastReceiver
		ComponentName component=new ComponentName(this, TimeBroadcastReceiver.class);
		getPackageManager().setComponentEnabledSetting(component, 
				PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
				PackageManager.DONT_KILL_APP);		
		// We bind the service
		bindService(new Intent(this, ChronoBoundService.class), mServiceConnection, Context.BIND_AUTO_CREATE);
	}
	
	@Override
	protected void onStop() {
		super.onStop();
		// We enable the static BroadcastReceiver
		ComponentName component=new ComponentName(this, TimeBroadcastReceiver.class);
		getPackageManager().setComponentEnabledSetting(component, 
				PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
				PackageManager.DONT_KILL_APP);		
		unregisterReceiver(mTimeReceiver);
		Log.i(Conf.TAG_LOG, "Activity stopped");
		unbindService(mServiceConnection);
	}
	
	private void updateTime(final String time) {
		Log.d(Conf.TAG_LOG, "TIME:" + time);
		mOutput.setText(time);
	}

	public void buttonPressed(final View button) {
		final Intent serviceIntent = new Intent(this, ChronoBoundService.class);
		switch (button.getId()) {
		case R.id.start_button:
			serviceIntent.setAction(ServiceUtil.START_CHRONO_ACTION);
			startService(serviceIntent);
			break;
		case R.id.stop_button:
			serviceIntent.setAction(ServiceUtil.STOP_CHRONO_ACTION);
			startService(serviceIntent);
			break;
		case R.id.reset_button:
			serviceIntent.setAction(ServiceUtil.RESET_CHRONO_ACTION);
			startService(serviceIntent);
			break;	
		case R.id.kill_button:
			serviceIntent.setAction(ServiceUtil.KILL_CHRONO_ACTION);
			stopService(serviceIntent);
			break;			
		default:
			break;
		}
	}

}
