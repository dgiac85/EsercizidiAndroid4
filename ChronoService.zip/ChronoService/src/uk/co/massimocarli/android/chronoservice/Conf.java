package uk.co.massimocarli.android.chronoservice;

/**
 * @author Massimo Carli
 *
 */
public final class Conf {
	
	/**
	 * The Tag for the log
	 */
	public static final String TAG_LOG = "ChronoBoundService";
	
	/**
	 * Private constructor
	 */
	private Conf() {
		throw new AssertionError("Never instantiate me!!");
	}

}
