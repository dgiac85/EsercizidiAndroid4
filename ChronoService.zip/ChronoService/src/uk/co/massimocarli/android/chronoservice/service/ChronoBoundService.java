package uk.co.massimocarli.android.chronoservice.service;

import uk.co.massimocarli.android.chronoservice.Conf;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

/**
 * This is the Service Bound implementation for the Chrono
 * 
 * @author Massimo Carli
 *
 */
public class ChronoBoundService extends Service {
	
	/**
	 * THe reference to the Stub implementation
	 */
	private ChronoServiceImpl mChronoImpl;
	
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		Log.i(Conf.TAG_LOG, "ChornoBound onStartCommand");
		// We execute the operation based on the type of action
		if (intent ==  null) {
			return Service.START_NOT_STICKY;
		}
		final String requestedAction = intent.getAction();
		if (ServiceUtil.START_CHRONO_ACTION.equals(requestedAction)) {
			try {
				mChronoImpl.start();
			} catch (RemoteException e) {
				e.printStackTrace();
			}
		} else if (ServiceUtil.STOP_CHRONO_ACTION.equals(requestedAction)) {
			try {
				mChronoImpl.stop();
			} catch (RemoteException e) {
				e.printStackTrace();
			}			
		} else if (ServiceUtil.RESET_CHRONO_ACTION.equals(requestedAction)) {
			try {
				mChronoImpl.reset();
			} catch (RemoteException e) {
				e.printStackTrace();
			}			
		}
		return super.onStartCommand(intent, flags, startId);
	}
	
	@Override
	public void onCreate() {
		super.onCreate();
		Log.i(Conf.TAG_LOG, "ChornoBound onCreate");
		// We create the instance of the Stub for the service
		mChronoImpl = new ChronoServiceImpl(this);
	}

	/* (non-Javadoc)
	 * @see android.app.Service#onBind(android.content.Intent)
	 */
	@Override
	public IBinder onBind(Intent intent) {
		Log.i(Conf.TAG_LOG, "ChornoBound onBind");
		// We return our Service implementation
		return mChronoImpl;
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		Log.i(Conf.TAG_LOG, "ChornoBound onDestroy");
		try {
			mChronoImpl.stop();
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		mChronoImpl = null;
	}

}
