package uk.co.massimocarli.android.chronoservice.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicLong;

import uk.co.massimocarli.android.chronoservice.Conf;
import android.content.Context;
import android.content.Intent;
import android.os.RemoteException;
import android.os.SystemClock;
import android.util.Log;

/**
 * This is the implementation of the ChronoService.Stub interface
 * 
 * @author Massimo Carli
 *
 */
public class ChronoServiceImpl extends ChronoService.Stub {
	
	/**
	 * The Runnable that implements the Chrono feature
	 */
	private static class Chrono implements Runnable {
		
		/**
		 * The notification timeout (10 seconds)
		 */
		private static final long NOTIFICATION_TIMEOUT = 10*1000;
		
		/**
		 * If true the broadcast intent is alreadt fired
		 */
		private boolean mNotificationFired;
		
		/**
		 * The DateFormat for the time
		 */
		private static final DateFormat DATE_FORMAT = new SimpleDateFormat("mm:ss", Locale.ENGLISH);		
		
		/*
		 * The precision is 100 milliseconds
		 */
		private static final long INTERVAL = 100L; 
		
		/**
		 * Tells if the Chrono is running or not
		 */
		private volatile boolean mRunning;
		
		/**
		 * The current Thread
		 */
		private Thread mThread;
		
		/**
		 * The Chrono time
		 */
		private final AtomicLong mCurrentChronoTime;
		
		/**
		 * The time we measure the last time
		 */
		private long mLastMeasuredTime;
		
		/**
		 * The currentTime as String
		 */
		private String mCurrentAsString;
		
		/**
		 * THe reference to the Callbackl
		 */
		private ChronoCallback mCallback;	
		
		/**
		 * The Calendar for the millis to Date conversion
		 */
		private final Calendar mCalendar;
		
		/**
		 * The Context
		 */
		private Context mContext;		
		
		/**
		 * The Chrono constructor
		 */
		public Chrono(final Context context){
			mCurrentChronoTime = new AtomicLong();
			mCalendar = Calendar.getInstance();
			this.mContext = context;
		}
		
		/**
		 * Set the new time for this chrono
		 * 
		 * @param newTime The time in milliseconds
		 */
		public void setTime(final long newTime) {
			mCurrentChronoTime.set(newTime);
			mCalendar.setTimeInMillis(mCurrentChronoTime.get());
			final String timeAsString = DATE_FORMAT.format(mCalendar.getTime());
			if (mCallback != null && !timeAsString.equals(mCurrentAsString)) {
				mCurrentAsString = timeAsString;
				try {
					mCallback.currentTime(mCurrentAsString);
				} catch (RemoteException e) {
					e.printStackTrace();
				}
			}			
		}
		
		/**
		 * We set the callback fro notification
		 * @param callback The callback
		 */
		public void setCallback(final ChronoCallback callback) {
			this.mCallback = callback;
		}
		
		/**
		 * This method starts the Chrono
		 */
		public void start() {
			if (!mRunning) {
				mLastMeasuredTime = SystemClock.uptimeMillis();
				// we start the Thread
				mRunning = true;
				mThread = new Thread(this);
				mThread.start();
			}
		}
		
		/**
		 * This method stops the chrono
		 */
		public void stop() {
			if (mRunning) {
				mRunning = false;
				mThread = null;
			}
		}

		@Override
		public void run() {
			while(mRunning){
				try{Thread.sleep(INTERVAL);}catch(InterruptedException ie){}
				// We add to the time of the Chrono the elapsed time from the last measure
				final long now = SystemClock.uptimeMillis();
				mCurrentChronoTime.addAndGet(now - mLastMeasuredTime);
				mLastMeasuredTime = now;		
				Log.i(Conf.TAG_LOG, "CHRONO STEP! " + mCurrentChronoTime);
				// We send notification if possible
				mCalendar.setTimeInMillis(mCurrentChronoTime.get());
				final String timeAsString = DATE_FORMAT.format(mCalendar.getTime());
				if (mCallback != null && !timeAsString.equals(mCurrentAsString)) {
					mCurrentAsString = timeAsString;
					try {
						mCallback.currentTime(mCurrentAsString);
					} catch (RemoteException e) {
						e.printStackTrace();
					}
				}
				// We check for the notification time
				if (!mNotificationFired && mCurrentChronoTime.get() > NOTIFICATION_TIMEOUT) {
					final Intent broadcastIntent = new Intent(ServiceUtil.UPDATE_TIME_BROACAST_ACTION);
					broadcastIntent.putExtra(ServiceUtil.TIME_EXTRA, timeAsString);
					mContext.sendBroadcast(broadcastIntent);
					mNotificationFired = true;
				}
			} 
		}
		
		/**
		 * @return The current time
		 */
		public long getTime() {
			return mCurrentChronoTime.get();
		}
		
	}
	
	/**
	 * The Chrono instance
	 */
	private Chrono mChrono;
	
	/**
	 * We create the Chrono instance
	 */
	public ChronoServiceImpl(final Context context) {
		mChrono = new Chrono(context);
	}
	

	@Override
	public void start() throws RemoteException {
		Log.i(Conf.TAG_LOG, "CHRONO START INVOKED");
		mChrono.start();
	}

	@Override
	public void stop() throws RemoteException {
		Log.i(Conf.TAG_LOG, "CHRONO STOP INVOKED");		
		mChrono.stop();
	}

	@Override
	public void reset() throws RemoteException {
		Log.i(Conf.TAG_LOG, "CHRONO RESET INVOKED");	
		setTime(0L);
	}

	@Override
	public void setTime(long time) throws RemoteException {
		Log.i(Conf.TAG_LOG, "CHRONO SET_TIME INVOKED");	
		mChrono.setTime(time);
	}

	@Override
	public long getTime() throws RemoteException {
		Log.i(Conf.TAG_LOG, "CHRONO GET_TIME INVOKED");	
		return mChrono.getTime();
	}

	@Override
	public void registerCallback(final ChronoCallback callback)
			throws RemoteException {
		// Register callback to the Thread
		mChrono.setCallback(callback);
	}

	@Override
	public void unregisterCallback(final ChronoCallback callback)
			throws RemoteException {
		mChrono.setCallback(null);
	}

}
