package uk.co.massimocarli.android.chronoservice.receiver;

import uk.co.massimocarli.android.chronoservice.R;
import uk.co.massimocarli.android.chronoservice.service.ServiceUtil;
import android.app.Notification;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;

/**
 * @author Massimo Carli
 *
 */
public class TimeBroadcastReceiver extends BroadcastReceiver {
	
	/**
	 * The notification id
	 */
	private static final int TIME_NOTIFICATION_ID = 1000;

	/* (non-Javadoc)
	 * @see android.content.BroadcastReceiver#onReceive(android.content.Context, android.content.Intent)
	 */
	@Override
	public void onReceive(Context context, Intent intent) {
		// We receive the time form the Intent
		final String timeInfo = intent.getStringExtra(ServiceUtil.TIME_EXTRA); 
		// Create Notification
	    final String contentText = context.getResources().getString(R.string.notification_label, timeInfo);
	    final String contentTitle = context.getResources().getString(R.string.notification_title);
	    Notification notification = new NotificationCompat.Builder(context)
	        .setSmallIcon(R.drawable.ic_launcher).setContentText(contentText)
	        .setAutoCancel(true)
	        .setContentTitle(contentTitle).build();
	    // The NotificationManager
	    final NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
	    notificationManager.notify(TIME_NOTIFICATION_ID, notification);
	}

}
