package uk.co.massimocarli.android.chronoservice.service;

/**
 * This is a class for the contants about ChronoService
 * 
 * @author Massimo Carli
 * 
 */
public final class ServiceUtil {
	
	
	/**
	 * Action for the broadcast update intent
	 */
	public static final String UPDATE_TIME_BROACAST_ACTION = "chronoservice.service.action.UPDATE_TIME_BROACAST_ACTION";
	
	/**
	 * Action for start Chrono
	 */
	public static final String START_CHRONO_ACTION = "chronoservice.service.action.START_CHRONO_ACTION";
	
	/**
	 * Action for stop Chrono
	 */	
	public static final String STOP_CHRONO_ACTION = "chronoservice.service.action.STOP_CHRONO_ACTION";
	
	/**
	 * Action for reset Chrono
	 */	
	public static final String RESET_CHRONO_ACTION = "chronoservice.service.action.RESET_CHRONO_ACTION";
	
	/**
	 * THe key for the extra for the time
	 */
	public static final String TIME_EXTRA = "chronoservice.service.extra.TIME_EXTRA";
	
	/**
	 * Action for killing Service
	 */	
	public static final String KILL_CHRONO_ACTION = "chronoservice.service.action.KILL_CHRONO_ACTION";	

	/**
	 * Private constructor
	 */
	private ServiceUtil() {
		throw new AssertionError("Never instantiate me!");
	}

}
