package uk.co.massimocarli.android.ugho.content;

import android.content.ContentProvider;
import android.content.ContentResolver;
import android.net.Uri;
import android.provider.BaseColumns;

/**
 * This is a class that stores all the metadata about the DB
 * <p/>
 * Created by Massimo Carli on 06/07/13.
 */
public final class UghoDB {

    /**
     * The name of the UghoDB
     */
    public static final String DB_NAME = "UghoDB";

    /**
     * The current version of the DB
     */
    public static final int DB_VERSION = 2;

    /**
     * The Authority for the ContentProvider
     */
    public static final String AUTHORITY = "uk.co.massimocarli.android.ugho";

    /**
     * Private constructor
     */
    private UghoDB() {
    }

    /**
     * Metadata for the HoroVote table
     */
    public static class HoroVote implements BaseColumns {

        /**
         * The name of the table for the data
         */
        public static final String TABLE_NAME = "HORO_VOTE";

        /**
         * The Path for this kind of resource
         */
        public static final String PATH = "horovote";

        /**
         * The Uri for this resources
         */
        public static final Uri CONTENT_URI = Uri.parse(ContentResolver.SCHEME_CONTENT + "://"
                + AUTHORITY + "/" + PATH);

        /**
         * The mime type for the dir
         */
        public static final String MIME_TYPE_DIR = ContentResolver.CURSOR_DIR_BASE_TYPE + "/vnd.horovote";

        /**
         * The mime type for the single item
         */
        public static final String MIME_TYPE_ITEM = ContentResolver.CURSOR_ITEM_BASE_TYPE + "/vnd.horovote";

        /**
         * The column for the date of this entry (long)
         */
        public static final String ENTRY_DATE = "entry_date";

        /**
         * The column for the vote in love (int)
         */
        public static final String LOVE_VOTE = "love_vote";

        /**
         * The column for the vote in health (int)
         */
        public static final String HEALTH_VOTE = "health_vote";

        /**
         * The column for the vote in work (int)
         */
        public static final String WORK_VOTE = "work_vote";

        /**
         * The column for the vote in luck (int)
         */
        public static final String LUCK_VOTE = "luck_vote";

        /**
         * The column for the sign (text)
         */
        public static final String HORO_SIGN = "horo_sign";

        /**
         * The column for the location (text)
         */
        public static final String LOCATION = "location";

        /**
         * The column for sync (text)
         */
        public static final String SYNC = "sync";

    }

}
