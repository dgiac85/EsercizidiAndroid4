package uk.co.massimocarli.android.ugho.activity;

import android.os.Bundle;
import android.preference.Preference;
import android.text.TextUtils;
import com.actionbarsherlock.app.SherlockPreferenceActivity;
import uk.co.massimocarli.android.ugho.R;
import uk.co.massimocarli.android.ugho.model.UserModel;
import uk.co.massimocarli.android.ugho.settings.DatePreference;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * This is the Activity we use to manage settings
 * <p/>
 * Created by Massimo Carli on 31/05/2013.
 */
public class SettingsActivity extends SherlockPreferenceActivity {

    /**
     * The Tag of the Log for this class
     */
    private static final String TAG_LOG = SettingsActivity.class.getName();

    /**
     * The DateFormatter for the birthdate label
     */
    private static final DateFormat BIRTH_DATE_FORMAT = new SimpleDateFormat("dd MMMM yyyy");

    /**
     * The Model about the user
     */
    private UserModel mUserModel;

    /**
     * The listener about the changes in preferences
     */
    private Preference.OnPreferenceChangeListener mListener = new Preference.OnPreferenceChangeListener() {
        @Override
        public boolean onPreferenceChange(Preference preference, Object o) {
            if (preference == mBirthDatePreference) {
                // We update the value of the model
                mUserModel.setBirthDate(mBirthDatePreference.getSelectedDate().getTime());
                mUserModel.save(getApplicationContext());
            }
            // We update info
            updateInfo();
            // we return true so the data are updated
            return true;
        }
    };

    /**
     * The Category about credentials
     */
    private Preference mCredentialCategory;

    /**
     * The Preference for the birthDate
     */
    private DatePreference mBirthDatePreference;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.settings);
        // We read the model
        mUserModel = UserModel.load(this);
        // The reference to the Preference for the email
        mBirthDatePreference = (DatePreference) findPreference("birth_date");
        mBirthDatePreference.setSelectedDate(mUserModel.getBirthDate());
        mBirthDatePreference.setOnPreferenceChangeListener(mListener);
        // We register events on changes
        mCredentialCategory = findPreference("credential_category");
        mCredentialCategory.setOnPreferenceChangeListener(mListener);

    }


    @Override
    protected void onResume() {
        super.onResume();
        // We update the data in the preferences UI
        updateInfo();
    }

    /**
     * Utility method that updates info about the profile
     */
    private void updateInfo() {
        // We read out object
        final UserModel userModel = UserModel.load(this);
        if (TextUtils.isEmpty(userModel.getUsername())) {
            // We disable the related preference
            findPreference("credential_category").setEnabled(false);
        } else {
            // We enable the related preference
            findPreference("credential_category").setEnabled(true);
            // We update the information about the summaries
            findPreference("uk.co.massimocarli.android.ugho.key.USERNAME_KEY")
                    .setSummary(userModel.getUsername());
            findPreference("uk.co.massimocarli.android.ugho.key.EMAIL_KEY")
                    .setSummary(userModel.getEmail());
            findPreference("uk.co.massimocarli.android.ugho.key.LOCATION_KEY")
                    .setSummary(userModel.getLocation());
        }
        // We have to update the label for the birthDate
        final Date birthDate = new Date();
        birthDate.setTime(mUserModel.getBirthDate());
        mBirthDatePreference.setSummary(BIRTH_DATE_FORMAT.format(birthDate));
    }

}