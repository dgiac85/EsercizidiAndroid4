package uk.co.massimocarli.android.ugho.model;

import android.content.ContentValues;
import android.database.Cursor;
import uk.co.massimocarli.android.ugho.content.UghoDB;
import uk.co.massimocarli.android.ugho.util.Zodiac;

/**
 * This object encapsulate the information related to a specific user and managed locally.
 * <p/>
 * <p/>
 * Created by Massimo Carli on 27/06/13.
 */
public final class LocalDataModel {

    /**
     * The id for this entry
     */
    public final long id;

    /**
     * The date of the entry as long.
     */
    public final long entryDate;

    /**
     * The vote for the love category
     */
    public final int loveVote;

    /**
     * The vote for the health category
     */
    public final int healthVote;

    /**
     * The vote for the work category
     */
    public final int workVote;

    /**
     * The vote for the luck category
     */
    public final int luckVote;


    /**
     * This is a private constructor that creates and initializes an LocalDataModel.
     *
     * @param id         The id for this item
     * @param entryDate  The date this entry is related to
     * @param loveVote   The vote related to love
     * @param healthVote The vote for health
     * @param workVote   The vote for work
     * @param luckVote   The vote for luck
     */
    private LocalDataModel(final long id, final long entryDate, final int loveVote,
                           final int healthVote, final int workVote, final int luckVote) {
        this.id = id;
        this.entryDate = entryDate;
        this.loveVote = loveVote;
        this.healthVote = healthVote;
        this.workVote = workVote;
        this.luckVote = luckVote;
    }

    /**
     * Creates a LocalDataModel with all the needed information.
     *
     * @param id         The id for this item
     * @param entryDate  The date this entry is related to
     * @param loveVote   The vote related to love
     * @param healthVote The vote for health
     * @param workVote   The vote for work
     * @param luckVote   The vote for luck
     */
    public static LocalDataModel create(final long id, final long entryDate, final int loveVote,
                                        final int healthVote, final int workVote, final int luckVote) {
        return new LocalDataModel(id, entryDate, loveVote, healthVote, workVote, luckVote);
    }


    /**
     * @return The information of the LocalDataModel as a ContentValues
     */
    public ContentValues asValues() {
        final ContentValues values = new ContentValues();
        values.put(UghoDB.HoroVote.ENTRY_DATE, entryDate);
        values.put(UghoDB.HoroVote.LOVE_VOTE, loveVote);
        values.put(UghoDB.HoroVote.HEALTH_VOTE, healthVote);
        values.put(UghoDB.HoroVote.WORK_VOTE, workVote);
        values.put(UghoDB.HoroVote.LUCK_VOTE, luckVote);
        return values;
    }

    /**
     * This method creates a LocalDataModel from the Cursor
     *
     * @param cursor The Cursor for reading data from
     * @return The LocalDataModel created with the information from the given Cursor
     */
    public static LocalDataModel fromCursor(final Cursor cursor) {
        long id = cursor.getLong(cursor.getColumnIndex(UghoDB.HoroVote._ID));
        long entryDate = cursor.getLong(cursor.getColumnIndex(UghoDB.HoroVote.ENTRY_DATE));
        int loveVote = cursor.getInt(cursor.getColumnIndex(UghoDB.HoroVote.LOVE_VOTE));
        int healthVote = cursor.getInt(cursor.getColumnIndex(UghoDB.HoroVote.HEALTH_VOTE));
        int workVote = cursor.getInt(cursor.getColumnIndex(UghoDB.HoroVote.WORK_VOTE));
        int luckVote = cursor.getInt(cursor.getColumnIndex(UghoDB.HoroVote.LUCK_VOTE));
        LocalDataModel item = LocalDataModel.create(id, entryDate, loveVote, healthVote, workVote, luckVote);
        return item;
    }

}
