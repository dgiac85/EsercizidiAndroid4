package uk.co.massimocarli.android.ugho.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 * This is an implementation of the SectionViewFactory that creates the View to show from a layout. The
 * association between the layout and the data is done into the setValue() method implementation.
 */
public abstract class LayoutSectionViewFactory implements SectionViewFactory {

    /*
     * The id of the layout to manage.
     */
    private final int mLayoutId;

    /**
     * Creates a LayoutSectionViewFactory given the layoutId.
     *
     * @param layoutId The id of the layout to manage
     */
    public LayoutSectionViewFactory(int layoutId) {
        this.mLayoutId = layoutId;
    }

    @Override
    public View createSectionView(Context ctx, int position, View convertView, ViewGroup parent) {
        View sectionView = null;
        // In this case we use a default implementation of gray TextView
        if (convertView == null) {
            sectionView = LayoutInflater.from(ctx).inflate(mLayoutId, null);
        } else {
            sectionView = (TextView) convertView;
        }
        return sectionView;
    }

    @Override
    public abstract void setValue(View sectionView, String value);

}
