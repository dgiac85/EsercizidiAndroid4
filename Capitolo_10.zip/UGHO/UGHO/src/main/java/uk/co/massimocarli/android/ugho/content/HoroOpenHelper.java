package uk.co.massimocarli.android.ugho.content;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import uk.co.massimocarli.android.ugho.R;
import uk.co.massimocarli.android.ugho.util.ResourceUtils;

/**
 * Created by massimocarli on 07/07/13.
 */
public class HoroOpenHelper extends SQLiteOpenHelper {

    /**
     * The Context
     */
    private Context mContext;

    /**
     * Creates a HoroOpenHelper to manage Horo database
     *
     * @param context The Context
     */
    public HoroOpenHelper(Context context) {
        super(context, UghoDB.DB_NAME, null, UghoDB.DB_VERSION);
        this.mContext = context;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        try {
            sqLiteDatabase.beginTransaction();
            final String createSql = ResourceUtils.getRawAsString(mContext, R.raw.create_schema);
            sqLiteDatabase.execSQL(createSql);
            sqLiteDatabase.setTransactionSuccessful();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            sqLiteDatabase.endTransaction();
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i2) {
        try {
            sqLiteDatabase.beginTransaction();
            final String dropSql = ResourceUtils.getRawAsString(mContext, R.raw.drop_schema);
            sqLiteDatabase.execSQL(dropSql);
            sqLiteDatabase.setTransactionSuccessful();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            sqLiteDatabase.endTransaction();
        }
        onCreate(sqLiteDatabase);
    }
}
