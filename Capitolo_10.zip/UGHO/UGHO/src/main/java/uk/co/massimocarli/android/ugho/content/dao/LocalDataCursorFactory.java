package uk.co.massimocarli.android.ugho.content.dao;

import android.database.Cursor;
import android.database.sqlite.SQLiteCursor;
import android.database.sqlite.SQLiteCursorDriver;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQuery;
import uk.co.massimocarli.android.ugho.content.UghoDB;
import uk.co.massimocarli.android.ugho.model.LocalDataModel;

/**
 * Created by massimocarli on 07/07/13.
 */
@SuppressWarnings("deprecation")
public class LocalDataCursorFactory implements SQLiteDatabase.CursorFactory {

    /**
     * This is the implementation of the Cursor for our scenario
     */
    public static class LocalDataCursor extends SQLiteCursor {

        /**
         * Creates a LocalDataCursor from the information needed
         *
         * @param sqLiteDatabase     The current DB instance
         * @param sqLiteCursorDriver The Driver of the current Db
         * @param editTable          The table used but this cursor
         * @param sqLiteQuery        The current query executed
         */
        public LocalDataCursor(SQLiteDatabase sqLiteDatabase, SQLiteCursorDriver sqLiteCursorDriver,
                               String editTable, SQLiteQuery sqLiteQuery) {
            super(sqLiteDatabase, sqLiteCursorDriver, editTable, sqLiteQuery);
        }

        /**
         * @return The id for the given entity
         */
        public long getId() {
            return getLong(getColumnIndex(UghoDB.HoroVote._ID));
        }

        /**
         * @return The entry date for the given entity
         */
        public long getEntryDate() {
            return getLong(getColumnIndex(UghoDB.HoroVote.ENTRY_DATE));
        }

        /**
         * @return The vote for the love
         */
        public int getLoveVote() {
            return getInt(getColumnIndex(UghoDB.HoroVote.LOVE_VOTE));
        }

        /**
         * @return The vote for the health
         */
        public int getHealthVote() {
            return getInt(getColumnIndex(UghoDB.HoroVote.HEALTH_VOTE));
        }

        /**
         * @return The vote for the work
         */
        public int getWorkVote() {
            return getInt(getColumnIndex(UghoDB.HoroVote.WORK_VOTE));
        }

        /**
         * @return The vote for the luck
         */
        public int getLuckVote() {
            return getInt(getColumnIndex(UghoDB.HoroVote.LUCK_VOTE));
        }

        /**
         * @return The current element as a LocalDataModel object
         */
        public LocalDataModel asLocalDataModel() {
            return LocalDataModel.create(getId(), getEntryDate(), getLoveVote(), getHealthVote(),
                    getWorkVote(), getLuckVote());
        }

    }


    @Override
    public Cursor newCursor(SQLiteDatabase sqLiteDatabase, SQLiteCursorDriver sqLiteCursorDriver,
                            String editTable, SQLiteQuery sqLiteQuery) {
        // Here we return an instance of the SQLIteCursor when we add the information about
        return new LocalDataCursor(sqLiteDatabase, sqLiteCursorDriver, UghoDB.HoroVote.TABLE_NAME, sqLiteQuery);
    }
}
