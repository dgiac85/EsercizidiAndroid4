package uk.co.massimocarli.android.ugho.adapters;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.DataSetObserver;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.TextView;

/**
 * This class describes a Decorator that permits to add some headers for every sectionable
 * item in the Adapter.  The header are defined by the items themselves if they implement
 * the Sectionable interface or by an external Sectionator object.
 * IMPORTANT: The objects must be ordered using the same criteria used for the Sections
 *
 * @author Massimo Carli
 */
public class SectionAdapterDecorator<E> extends BaseAdapter {

    /**
     * The Tag for the log.
     */
    private static final String TAG_LOG = SectionAdapterDecorator.class.getName();

    /**
     * The Context.
     */
    private Context mContext;

    /**
     * The Adapter to decorate.
     */
    private BaseAdapter mAdaptee;

    /**
     * The Sectionator to use to get the Section from each object.
     */
    private Sectionator<? super E> mSectionator;

    /**
     * The ordered Set of the Sections.
     */
    protected Set<String> mSectionSet = new LinkedHashSet<String>();

    /**
     * The Sections as array to be faster.
     */
    protected String[] mSectionArray;

    /**
     * Map between the position of an item in the Adapter and the original position in the
     * adaptee.
     */
    protected Map<Integer, Integer> mPositionMap;

    /**
     * Position of the headers in the adapter.
     */
    protected Map<Integer, Integer> mSectionPositionMap;

    /**
     * List of the ordered position headers for the section.
     */
    protected LinkedHashSet<Integer> mSectionPositionList;

    /**
     * The Factory for the Section View.
     */
    protected SectionViewFactory mSectionViewFactory;

    /**
     * Creates a SectionAdapterDecorator that decorate the BaseAdapter with the section feature. In this
     * case the elements on the BaseAdapter must be Sectionable
     *
     * @param context The Context
     * @param adaptee The BaseAdapter to decorate
     */
    public SectionAdapterDecorator(Context context, BaseAdapter adaptee) {
        this.mContext = context.getApplicationContext();
        if (adaptee == null) {
            throw new IllegalArgumentException("Adaptee cannot be null!");
        }
        this.mAdaptee = adaptee;
        // Manage updates
        manageObservations();
        // Let's elaborate the data
        prepareData();
    }

    /**
     * Creates a SectionAdapterDecorator that decorate the BaseAdapter with the section feature using
     * a given Sectionator.
     *
     * @param context     The Context
     * @param adaptee     The BaseAdapter to decodate
     * @param sectionator The Sectionator responsable to define the sections
     */
    public SectionAdapterDecorator(Context context, BaseAdapter adaptee,
                                   Sectionator<? super E> sectionator) {
        this.mContext = context.getApplicationContext();
        if (adaptee == null) {
            throw new IllegalArgumentException("Adaptee cannot be null!");
        }
        this.mAdaptee = adaptee;
        // Manage updates
        manageObservations();
        // Se the Sectionator
        this.mSectionator = sectionator;
        // Let's elaborate the data
        prepareData();
    }

    /**
     * Se the SectionViewFactory responsible for the creation of the View for the Section
     *
     * @param sectionViewFactory The Factory responsible for the creation of the Section View
     */
    public void setSectionViewFactory(SectionViewFactory sectionViewFactory) {
        this.mSectionViewFactory = sectionViewFactory;
    }

    /*
     * (non-Javadoc)
     *
     * @see android.widget.ListAdapter#areAllItemsEnabled()
     */
    @Override
    public boolean areAllItemsEnabled() {
        // Not all items are enabled because the headers are not!
        return false;
    }

    /*
     * (non-Javadoc)
     *
     * @see android.widget.ListAdapter#isEnabled(int)
     */
    @Override
    public boolean isEnabled(int position) {
        // The item is enabled if not a section item
        if (mSectionPositionList.contains(position)) {
            // It's an header so it's disabled
            return false;
        } else {
            // We get the position in the original adapter
            int newPosition = mPositionMap.get(position);
            // We delegate to it the enabled state
            return mAdaptee.isEnabled(newPosition);
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see android.widget.Adapter#getCount()
     */
    @Override
    public int getCount() {
        // The number of element is given by the element of the
        // adaptee + the number of headers
        return mAdaptee.getCount() + mSectionSet.size();
    }

    /*
     * (non-Javadoc)
     *
     * @see android.widget.Adapter#getItem(int)
     */
    @Override
    public Object getItem(int position) {
        // We test if the position is in the headers
        if (mSectionPositionList.contains(position)) {
            // We return the header in the related position
            int sectionIndex = mSectionPositionMap.get(position);
            return mSectionArray[sectionIndex];
        } else {
            // In this case we delegate to the original Adapter
            int newPosition = mPositionMap.get(position);
            return mAdaptee.getItem(newPosition);
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see android.widget.Adapter#getItemId(int)
     */
    @Override
    public long getItemId(int position) {
        // We test if it's a header or not
        if (mSectionPositionList.contains(position)) {
            // We suppose the position of the header is negative. We'll never use this value!!
            return -1 * position;
        } else {
            // We delegate to the Adaptee the Id
            Integer newPosition = mPositionMap.get(position);
            if (newPosition != null) {
                return mAdaptee.getItemId(newPosition);
            } else {
                return -1;
            }

        }
    }

    /*
     * (non-Javadoc)
     *
     * @see android.widget.Adapter#getViewTypeCount()
     */
    @Override
    public int getViewTypeCount() {
        // The number of viewTypeCount is the one of the adaptee + 1
        return mAdaptee.getViewTypeCount() + 1;
    }

    /*
     * (non-Javadoc)
     *
     * @see android.widget.Adapter#getItemViewType(int)
     */
    @Override
    public int getItemViewType(int position) {
        // The type of view in the adapter is the same of the adaptee + 1 (the header one)
        if (mSectionPositionList.contains(position)) {
            // We return the number + 1
            return mAdaptee.getViewTypeCount();
        } else {
            // We return the value of the adaptee
            Integer newPosition = mPositionMap.get(position);
            if (newPosition == null) {
                return getViewTypeCount();
            } else {
                return mAdaptee.getItemViewType(newPosition);
            }
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see android.widget.Adapter#getView(int, android.view.View,
     * android.view.ViewGroup)
     */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // We check if the view is relative to the header or not
        if (mSectionPositionList.contains(position)) {
            // It's the header so we return the header View
            return getSectionView(position, convertView, parent);
        } else {
            // It's not an header so we return the View of the Adaptee
            int newPosition = mPositionMap.get(position);
            return mAdaptee.getView(newPosition, convertView, parent);
        }
    }

    /**
     * This is the method responsible to create the View for the Section.
     *
     * @param position    Position of the section
     * @param convertView The reusable View
     * @param parent      The parent view
     * @return The View to use for the sections
     */
    @SuppressWarnings("unchecked")
    public View getSectionView(int position, View convertView, ViewGroup parent) {
        View returnView = null;
        if (mSectionViewFactory != null) {
            // We  delegate to the mSectionViewBuilder
            returnView = mSectionViewFactory.createSectionView(mContext, position, convertView, parent);
            // We get the section value
            mSectionViewFactory.setValue(returnView, (String) getItem(position));
        } else {
            // In this case we use a default implementation of gray TextView
            if (convertView == null) {
                AbsListView.LayoutParams lp = new AbsListView.LayoutParams(
                        AbsListView.LayoutParams.MATCH_PARENT,
                        AbsListView.LayoutParams.WRAP_CONTENT);
                returnView = new TextView(getContext());
                returnView.setLayoutParams(lp);
            } else {
                returnView = (TextView) convertView;
            }
            ((TextView) returnView).setText((String) getItem(position));
        }
        return returnView;
    }

    /*
     * (non-Javadoc)
     *
     * @see android.widget.Adapter#hasStableIds()
     */
    @Override
    public boolean hasStableIds() {
        // Deleghiamo all'adaptee the stability of the ids
        return mAdaptee.hasStableIds();
    }

    /*
     * (non-Javadoc)
     *
     * @see android.widget.Adapter#isEmpty()
     */
    @Override
    public boolean isEmpty() {
        // Our adapter is empty if is empty the adaptee
        return mAdaptee.isEmpty();
    }

    /*
     * (non-Javadoc)
     *
     * @seeandroid.widget.Adapter#registerDataSetObserver(android.database.
     * DataSetObserver)
     */
    @Override
    public void registerDataSetObserver(DataSetObserver observer) {
        // We register the observer to the adaptee
        mAdaptee.registerDataSetObserver(observer);
    }

    /*
     * (non-Javadoc)
     *
     * @seeandroid.widget.Adapter#unregisterDataSetObserver(android.database.
     * DataSetObserver)
     */
    @Override
    public void unregisterDataSetObserver(DataSetObserver observer) {
        // We deregister the observer
        mAdaptee.unregisterDataSetObserver(observer);
    }

    /**
     * @return Riferimento al Context
     */
    public Context getContext() {
        return mContext;
    }


    /**
     * This method is necessary to return the real position clicked instead of the selected one.
     *
     * @param position Position into the decorator
     * @return Related position in the adaptee
     */
    public int getOriginalPosition(int position) {
        // If it's a position of the header we return -1. This should never happen
        if (mSectionSet.contains(position)) {
            return -1;
        } else {
            // We return the mapped id
            Integer originalPosition = mPositionMap.get(position);
            if (originalPosition != null) {
                return originalPosition;
            } else {
                return -1;
            }
        }
    }

    /*
     * This method will elaborate the information into the Adapter given and create the information
     * about the Sections
     */
    @SuppressWarnings("unchecked")
    private void prepareData() {
        mPositionMap = new HashMap<Integer, Integer>();
        mSectionPositionMap = new HashMap<Integer, Integer>();
        mSectionPositionList = new LinkedHashSet<Integer>();
        mSectionSet = new LinkedHashSet<String>();
        // The number of the section
        for (int i = 0; i < mAdaptee.getCount(); i++) {
            // Get the item
            E item = (E) mAdaptee.getItem(i);
            // We get the section
            String section = getSection(item);
            if (!Sectionable.NOT_SECTIONABLE_ITEM.equals(section)) {
                // If we have the section we can add ot the set
                mSectionSet.add(section);
                Log.d(TAG_LOG, "Section Set is " + mSectionSet);
            }
        }
        mSectionArray = mSectionSet.toArray(new String[0]);
        // We calculate the mapping between the position in the adaptee and in the decorated adapter
        int currentPosition = 0;
        String currentSection = null;
        for (int i = 0; i < mAdaptee.getCount(); i++) {
            E item = (E) mAdaptee.getItem(i);
            String section = getSection(item);
            if (!Sectionable.NOT_SECTIONABLE_ITEM.equals(section) && section.equals(currentSection)) {
                // Associate the current position to the index i
                mPositionMap.put(currentPosition, i);
                currentPosition++;
            } else {
                // We have to add the section element
                mSectionPositionList.add(currentPosition);
                currentPosition++;
                // We set the position in the map
                mPositionMap.put(currentPosition, i);
                currentPosition++;
                // Update the currentSection which is changed
                currentSection = section;
            }
        }
        // We manage the mapping between the different positions
        int sectionPosIndex = 0;
        for (Integer sectionPos : mSectionPositionList) {
            mSectionPositionMap.put(sectionPos, sectionPosIndex++);
        }
        Log.d(TAG_LOG, "Managing Adaptee ended!");
    }

    /*
     * Utility method to get the current Section given the item
     */
    @SuppressWarnings("unchecked")
    private String getSection(E item) {
        String section = null;
        if (mSectionator != null) {
            // In this case we use the Sectionator
            section = mSectionator.getSection(item);
        } else {
            if (item instanceof Sectionable) {
                // In this case we use the Sectionable instance
                Sectionable<? extends E> sectionable = (Sectionable<? extends E>) item;
                section = sectionable.getSection();
            } else {
                // In this case the item is not good because must be Sectionable
                throw new ClassCastException("Cannot create section for non Sectionable Objects");
            }
        }
        return section;
    }


    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
        mAdaptee.notifyDataSetChanged();
        // Elaborate the adapter after the changes
        prepareData();

    }

    @Override
    public void notifyDataSetInvalidated() {
        super.notifyDataSetInvalidated();
        mAdaptee.notifyDataSetInvalidated();
        // Elaborate the adapter after the changes
        prepareData();
    }


    private void manageObservations() {
        mAdaptee.registerDataSetObserver(new DataSetObserver() {
            @Override
            public void onChanged() {
                super.onChanged();
                // Elaborate the adapter after the changes
                prepareData();
            }

            @Override
            public void onInvalidated() {
                super.onInvalidated();
                // Elaborate the adapter after the changes
                prepareData();
            }
        });
    }

}
