package uk.co.massimocarli.android.ugho.service;

import android.content.Context;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.json.JSONException;
import org.json.JSONObject;
import uk.co.massimocarli.android.ugho.R;
import uk.co.massimocarli.android.ugho.UghoApplication;
import uk.co.massimocarli.android.ugho.model.UserModel;
import uk.co.massimocarli.android.ugho.util.MD5Utility;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * This is a class that implements the logic related to the RegistrationManagement
 * <p/>
 * Created by Massimo Carli on 05/06/13.
 */
public final class RegistrationService {

    /**
     * The Tag for the log
     */
    private static final String TAG_LOG = RegistrationService.class.getName();

    /**
     * The value for error result
     */
    private static final String KO_RESULT = "KO";

    /**
     * The Singleton instance
     */
    private static RegistrationService instance;

    /**
     * @return The singleton instance of the LoginService
     */
    public synchronized static RegistrationService get() {
        if (instance == null) {
            instance = new RegistrationService();
        }
        return instance;
    }

    /**
     * This is the ResponseHandler which knows how to read a UserModel from the HTTP response
     */
    private ResponseHandler<UserModel> mUserModelResponseHandler = new ResponseHandler<UserModel>() {
        @Override
        public UserModel handleResponse(HttpResponse httpResponse) throws ClientProtocolException, IOException {
            // The UserModel to return
            UserModel userModel = null;
            // Here we have to read the UserModel from the httpResponse
            InputStream content = httpResponse.getEntity().getContent();
            byte[] buffer = new byte[1024];
            int numRead = 0;
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            while ((numRead = content.read(buffer)) != -1) {
                baos.write(buffer, 0, numRead);
            }
            content.close();
            // We create the JSONObject
            try {
                JSONObject resultAsJson = new JSONObject(new String(baos.toByteArray()));
                // We check if the result is ok or not
                final String result = resultAsJson.optString("result", KO_RESULT);
                if (KO_RESULT.equals(result)) {
                    // In this case we had an error
                    userModel = UserModel.fromError(resultAsJson.optString("message"));
                } else {
                    // Here the user is logged so we create the UserModel in the right way
                    final long birthDate = resultAsJson.optLong("birthDate", 0);
                    if (birthDate > 0) {
                        userModel = UserModel.create(birthDate)
                                .withEmail(resultAsJson.optString("email"))
                                .withUsername(resultAsJson.optString("username"))
                                .withLocation(resultAsJson.optString("location"));
                    } else {
                        userModel = UserModel.fromError("Error in birthDate data!");
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
                userModel = UserModel.fromError("JSON error: " + e.getMessage());
            }
            return userModel;
        }
    };

    /**
     * This registration implementation that creates the UserModel data.
     *
     * @param username  The username
     * @param password  The password
     * @param email     The email address
     * @param birthDate The birthDate as long
     * @param location  The location as long
     * @return The UserModel with user data if logged and null if not
     */
    public UserModel register(final Context context, final String username, final String password, final String email,
                              final long birthDate, final String location) {
        // The result
        UserModel userModel = null;
        // Here we create the document to send to the DB
        JSONObject json = new JSONObject();
        try {
            json.put("username", username);
            json.put("password", MD5Utility.md5(password));
            json.put("email", email);
            json.put("birthDate", birthDate);
            json.put("location", location);
            // We calculate the url for registration
            final String registrationUrl = context.getResources().getString(R.string.register_url);
            // We create the HttpClient as a Command executor
            final HttpClient httpClient = UghoApplication.getThreadSafeHttpClient();
            // We create the POST request
            final HttpPost request = new HttpPost(registrationUrl);
            // We set the input document
            request.setEntity(new StringEntity(json.toString()));
            // We set the content type for json
            request.addHeader("Content-Type", "application/json");
            request.addHeader("Accept", "application/json");
            // We execute the command
            userModel = httpClient.execute(request, mUserModelResponseHandler);
        } catch (JSONException e) {
            e.printStackTrace();
            return UserModel.fromError("Error:" + e.getMessage());
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return UserModel.fromError("Error:" + e.getMessage());
        } catch (ClientProtocolException e) {
            e.printStackTrace();
            return UserModel.fromError("Error:" + e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
            return UserModel.fromError("Error:" + e.getMessage());
        }
        // We return the model if any
        return userModel;
    }

}
