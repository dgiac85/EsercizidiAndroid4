package uk.co.massimocarli.android.ugho.model;

import uk.co.massimocarli.android.ugho.util.Zodiac;

/**
 * This object encapsulate the information related to a specific user and managed locally.
 * <p/>
 * <p/>
 * Created by Massimo Carli on 27/06/13.
 */
public final class LocalDataModel {

    /**
     * The id for this entry
     */
    public final long id;

    /**
     * The date of the entry as long.
     */
    public final long entryDate;

    /**
     * The vote for the love category
     */
    public final int loveVote;

    /**
     * The vote for the health category
     */
    public final int healthVote;

    /**
     * The vote for the work category
     */
    public final int workVote;

    /**
     * The vote for the luck category
     */
    public final int luckVote;


    /**
     * This is a private constructor that creates and initializes an LocalDataModel.
     *
     * @param id         The id for this item
     * @param entryDate  The date this entry is related to
     * @param loveVote   The vote related to love
     * @param healthVote The vote for health
     * @param workVote   The vote for work
     * @param luckVote   The vote for luck
     */
    private LocalDataModel(final long id, final long entryDate, final int loveVote,
                           final int healthVote, final int workVote, final int luckVote) {
        this.id = id;
        this.entryDate = entryDate;
        this.loveVote = loveVote;
        this.healthVote = healthVote;
        this.workVote = workVote;
        this.luckVote = luckVote;
    }

    /**
     * Creates a LocalDataModel with all the needed information.
     *
     * @param id         The id for this item
     * @param entryDate  The date this entry is related to
     * @param loveVote   The vote related to love
     * @param healthVote The vote for health
     * @param workVote   The vote for work
     * @param luckVote   The vote for luck
     */
    public static LocalDataModel create(final long id, final long entryDate, final int loveVote,
                                        final int healthVote, final int workVote, final int luckVote) {
        return new LocalDataModel(id, entryDate, loveVote, healthVote, workVote, luckVote);
    }

}
