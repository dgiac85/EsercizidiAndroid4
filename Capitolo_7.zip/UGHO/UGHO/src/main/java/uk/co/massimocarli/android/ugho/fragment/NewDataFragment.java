package uk.co.massimocarli.android.ugho.fragment;


import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import uk.co.massimocarli.android.ugho.R;
import uk.co.massimocarli.android.ugho.util.FontUtility;

/**
 * Created by Massimo Carli on 15/06/13.
 */
public class NewDataFragment extends Fragment {

    /**
     * The tag for the log
     */
    private static final String TAG_LOG = NewDataFragment.class.getName();

    /**
     * Interface that should be implemented by the activity that uses this Fragment
     */
    public interface NewDataFragmentListener {

        /**
         * This is invoked to notify the choice on this menu.
         *
         * @param category The category choosen
         */
        void newDataForCategory(String category);

    }

    /**
     * The reference to the listener of this Fragment
     */
    private NewDataFragmentListener mListener;


    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        if (activity instanceof NewDataFragmentListener) {
            mListener = (NewDataFragmentListener) activity;
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // We create the layout for this fragment
        final View menuView = inflater.inflate(R.layout.fragment_new_data, null);
        // We note that we don't care about the Button type because the onClick is an event
        // of all the View
        final Button newLoveDataButton = (Button) menuView.findViewById(R.id.new_love_data);
        FontUtility.applyFont(newLoveDataButton);
        newLoveDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mListener != null) {
                    Log.d(TAG_LOG, "Data for Love!");
                    mListener.newDataForCategory(getResources().getString(R.string.love_label));
                }
            }
        });
        // Health
        final Button newHealthDataButton = (Button) menuView.findViewById(R.id.new_health_data);
        FontUtility.applyFont(newHealthDataButton);
        newHealthDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mListener != null) {
                    Log.d(TAG_LOG, "Data for Health!");
                    mListener.newDataForCategory(getResources().getString(R.string.health_label));
                }
            }
        });
        // Work
        final Button newWorkDataButton = (Button) menuView.findViewById(R.id.new_work_data);
        FontUtility.applyFont(newWorkDataButton);
        newWorkDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mListener != null) {
                    Log.d(TAG_LOG, "Data for Work!");
                    mListener.newDataForCategory(getResources().getString(R.string.work_label));
                }
            }
        });
        // Luck
        final Button newLuckDataButton = (Button) menuView.findViewById(R.id.new_luck_data);
        FontUtility.applyFont(newLuckDataButton);
        newLuckDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mListener != null) {
                    Log.d(TAG_LOG, "Data for Luck!");
                    mListener.newDataForCategory(getResources().getString(R.string.luck_label));
                }
            }
        });
        // We return the View for the fragment
        return menuView;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        this.mListener = null;
    }
}
