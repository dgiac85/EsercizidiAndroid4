package uk.co.massimocarli.android.ugho.adapters;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.Button;
import uk.co.massimocarli.android.ugho.R;

/**
 * This class describes a specific MoreViewFactory that creates a Button
 */
public class ButtonMoreViewFactory extends MoreViewFactory {


    /**
     * This method returns the View for a given Section.
     *
     * @param ctx         The Context
     * @param position    The position of the Section
     * @param convertView The cell for reuse
     * @param parent      The container of the header
     * @return The view to add to the header
     */
    public View createMoreView(Context ctx, int position, View convertView, ViewGroup parent) {
        // In this case the View is simply a Button
        Button nextButton = new Button(ctx);
        AbsListView.LayoutParams lp = new AbsListView.LayoutParams(
                AbsListView.LayoutParams.MATCH_PARENT,
                AbsListView.LayoutParams.WRAP_CONTENT);
        nextButton.setLayoutParams(lp);
        nextButton.setGravity(Gravity.CENTER);
        nextButton.setText(R.string.more_button_label);
        // We register the events
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadNext();
            }
        });
        return nextButton;
    }

}
