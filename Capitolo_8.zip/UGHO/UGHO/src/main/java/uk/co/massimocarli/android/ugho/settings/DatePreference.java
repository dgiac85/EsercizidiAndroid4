package uk.co.massimocarli.android.ugho.settings;

import android.content.Context;
import android.preference.DialogPreference;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import uk.co.massimocarli.android.ugho.R;
import uk.co.massimocarli.android.ugho.util.Zodiac;
import uk.co.massimocarli.android.ugho.widget.CalendarChooser;

import java.util.Date;

/**
 * Created by Massimo Carli on 04/07/13.
 */
public class DatePreference extends DialogPreference {

    /**
     * The selected Date
     */
    private Date mSelectedDate;

    /**
     * The ImageView for the sign
     */
    private ImageView mSignImageView;

    /**
     * The TextView for the label
     */
    private TextView mSignTextView;

    /**
     * The CalendarChooser
     */
    private CalendarChooser mCalendarChooser;

    public DatePreference(Context context, AttributeSet attrs) {
        super(context, attrs);
        mSelectedDate = new Date();
    }

    public DatePreference(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        mSelectedDate = new Date();
    }

    @Override
    protected View onCreateDialogView() {
        // As a Dialog we create use our calendar
        mCalendarChooser = new CalendarChooser(getContext());
        mCalendarChooser.setCurrentDate(mSelectedDate);
        // We return the Layout for the dialog
        return mCalendarChooser;
    }

    @Override
    protected View onCreateView(ViewGroup parent) {
        View settingsView = super.onCreateView(parent);
        // We get the reference to the ImageView sign
        mSignImageView = (ImageView) settingsView.findViewById(R.id.settings_horo_sign_image);
        mSignTextView = (TextView) settingsView.findViewById(R.id.settings_horo_sign_label);
        if (mSignImageView != null) {
            final Zodiac zodiac = Zodiac.fromDate(mSelectedDate);
            mSignImageView.setImageResource(zodiac.getImageId());
            mSignTextView.setText(zodiac.toString());
        }
        return settingsView;
    }

    /**
     * This method select the current date
     *
     * @param date The current Date
     */
    public void setSelectedDate(final Date date) {
        setSelectedDate(date.getTime());
    }

    /**
     * This method select the current date as long
     *
     * @param date The current Date
     */
    public void setSelectedDate(final long date) {
        final Date selectedDate = new Date();
        selectedDate.setTime(date);
        this.mSelectedDate = selectedDate;
        if (mCalendarChooser != null) {
            mCalendarChooser.setCurrentDate(selectedDate);
        }
        // We change the image
        if (mSignImageView != null) {
            final Zodiac zodiac = Zodiac.fromDate(mSelectedDate);
            mSignImageView.setImageResource(zodiac.getImageId());
            mSignTextView.setText(zodiac.toString());
        }
    }

    /**
     * @return The current date
     */
    public Date getSelectedDate() {
        return mSelectedDate;
    }

    @Override
    protected void onDialogClosed(boolean positiveResult) {
        // If the user select the positive button we get the new date
        if (positiveResult) {
            mSelectedDate = mCalendarChooser.getCurrentDate().getTime();
            // We change the image
            if (mSignImageView != null) {
                final Zodiac zodiac = Zodiac.fromDate(mSelectedDate);
                mSignImageView.setImageResource(zodiac.getImageId());
                mSignTextView.setText(zodiac.toString());
            }
            callChangeListener(mSelectedDate);
        }
        super.onDialogClosed(positiveResult);
    }
}
