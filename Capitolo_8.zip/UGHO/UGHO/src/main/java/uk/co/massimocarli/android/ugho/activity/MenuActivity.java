package uk.co.massimocarli.android.ugho.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.View;
import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuItem;
import uk.co.massimocarli.android.ugho.R;
import uk.co.massimocarli.android.ugho.activity.list.*;
import uk.co.massimocarli.android.ugho.conf.Const;
import uk.co.massimocarli.android.ugho.fragment.*;
import uk.co.massimocarli.android.ugho.model.UserModel;

/**
 * This is the Activity we use to show the different options of our application
 * after authentication
 * <p/>
 * Created by Massimo Carli on 31/05/2013.
 */
public class MenuActivity extends SherlockFragmentActivity implements MenuFragment.MenuFragmentListener {

    /**
     * The Tag of the Log for this class
     */
    private static final String TAG_LOG = MenuActivity.class.getName();

    /**
     * The Tag for the MenuFragment
     */
    private static final String MENU_FRAGMENT_TAG = Const.PKG + ".tag.MENU_FRAGMENT_TAG";

    /**
     * The current UserModel
     */
    private UserModel mUserModel;


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_fragment);
        // We get the UserModel
        this.mUserModel = UserModel.load(this);
        if (mUserModel == null) {
            Log.w(TAG_LOG, " You must be logged!");
            final Intent backToLoginIntent = new Intent(this, FirstAccessActivity.class);
            backToLoginIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(backToLoginIntent);
            finish();
        }
        if (savedInstanceState == null) {
            final MenuFragment fragment = new MenuFragment();
            getSupportFragmentManager().beginTransaction().add(R.id.anchor_point, fragment, MENU_FRAGMENT_TAG).commit();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getSupportMenuInflater().inflate(R.menu.main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_logout:
                // We make the logout deleting the userData
                mUserModel.logout(this);
                // and go back to the FirstAccessActivity
                final Intent firstAccessIntent = new Intent(this, FirstAccessActivity.class);
                startActivity(firstAccessIntent);
                finish();
                break;
            case R.id.action_settings:
                // We show the Activity to manage Settings
                final Intent settingsIntent = new Intent(this, SettingsActivity.class);
                startActivity(settingsIntent);
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * This is invoked when we press the newDataButton
     */
    @Override
    public void insertNewData() {
        Log.d(TAG_LOG, "We choose to insert new data");
        final Intent newDataIntent = new Intent(this, NewDataActivity.class);
        startActivity(newDataIntent);
    }

    /**
     * This is invoked when we press the oldDataButton
     */
    @Override
    public void viewOldData() {
        Log.d(TAG_LOG, "We choose to view our old data");
        final Intent localDataIntent = new Intent(this, LocalDataActivity.class);
        //final Intent localDataIntent = new Intent(this, SimpleLocalDataActivity.class);
        //final Intent localDataIntent = new Intent(this, SimpleCustomLocalDataActivity.class);
        //final Intent localDataIntent = new Intent(this, CustomLocalDataActivity.class);
        //final Intent localDataIntent = new Intent(this, HolderCustomLocalDataActivity.class);
        //final Intent localDataIntent = new Intent(this, SimpleAdapterLocalDataActivity.class);
        //final Intent localDataIntent = new Intent(this, SimpleAdapterLocalDataListActivity.class);
        //final Intent localDataIntent = new Intent(this, LocalCompleteListActivity.class);
        //final Intent localDataIntent = new Intent(this, AlternateLocalDataActivity.class);
        startActivity(localDataIntent);
    }

    /**
     * This is invoked when we press the remoteDataButton
     */
    @Override
    public void viewRemoteData() {
        Log.d(TAG_LOG, "We choose to view remote data");
        final Intent remoteDataIntent = new Intent(this, RemoteDataActivity.class);
        startActivity(remoteDataIntent);
    }

}