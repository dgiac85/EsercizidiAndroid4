package uk.co.massimocarli.android.ugho.content.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.support.v4.database.DatabaseUtilsCompat;
import android.util.Log;
import uk.co.massimocarli.android.ugho.R;
import uk.co.massimocarli.android.ugho.content.UghoDB;
import uk.co.massimocarli.android.ugho.model.LocalDataModel;
import uk.co.massimocarli.android.ugho.util.ResourceUtils;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Iterator;

/**
 * Created by Massimo Carli on 05/07/13.
 */
public final class DAO {

    /**
     * The Tag for the Log
     */
    private static final String TAG_LOG = DAO.class.getName();


    /**
     * The current UghoDB Version
     */
    private static final int DB_VERSION = 1;

    /**
     * The Context used for this DAO. We retain the ApplicationContext
     */
    private Context mContext;

    /**
     * The Reference to the UghoDB
     */
    private SQLiteDatabase mDb;

    /**
     * Private constructor
     *
     * @param context The Context
     */
    private DAO(Context context) {
        this.mContext = context;
    }

    /**
     * Static Factory Method for the DAO
     *
     * @param context The Context
     * @return The DAO instance
     */
    public static synchronized DAO get(final Context context) {
        return new DAO(context.getApplicationContext());
    }

    /**
     * This method open the UghoDB
     */
    public void open() {
        if (mDb == null || !mDb.isOpen()) {
            // We check if the UghoDB is present
            final File dbFile = mContext.getDatabasePath(UghoDB.DB_NAME);
            final boolean wasExisting = dbFile.exists();
            if (!wasExisting) {
                // We read the sql to create the UghoDB
                final String createDbStatement;
                try {
                    createDbStatement = ResourceUtils.getRawAsString(mContext, R.raw.create_schema);
                    // If it's not present we create it
                    DatabaseUtils.createDbFromSqlStatements(mContext, UghoDB.DB_NAME, DB_VERSION, createDbStatement);
                } catch (IOException e) {
                    e.printStackTrace();
                    Log.e(TAG_LOG, "Error creating DB", e);
                    return;
                }
            }
            // The Factory for the Cursor
            final SQLiteDatabase.CursorFactory cursorFactory = new LocalDataCursorFactory();
            // Now the UghoDB exists so we can check the version
            mDb = mContext.openOrCreateDatabase(UghoDB.DB_NAME, Context.MODE_PRIVATE, cursorFactory);
            // We check the version
            int oldVersion = mDb.getVersion();
            if (oldVersion != DB_VERSION) {
                // In this case we should manage the different version of the UghoDB
                try {
                    // We get the drop sql
                    final String dropSchemaSql = ResourceUtils.getRawAsString(mContext, R.raw.drop_schema);
                    // We execute it
                    mDb.execSQL(dropSchemaSql);
                    // We create the DB again
                    final String createDbStatement = ResourceUtils.getRawAsString(mContext, R.raw.create_schema);
                    mDb.execSQL(createDbStatement);
                } catch (IOException e) {
                    e.printStackTrace();
                    Log.e(TAG_LOG, "Error updating DB", e);
                }
            }
        }
    }

    /**
     * This method deletes the HoroVote with the given id
     *
     * @param id The id of the HoroVote to delete
     * @return The number of HoroVote deleted (should be 1) or -1 in case of problems
     */
    public int deleteById(final long id) {
        int deleteResult = -1;
        if (mDb.isOpen()) {
            final String where = UghoDB.HoroVote._ID + " = ?";
            final String[] whereArgs = new String[]{String.valueOf(id)};
            deleteResult = mDb.delete(UghoDB.HoroVote.TABLE_NAME, where, whereArgs);
        }
        return deleteResult;
    }

    /**
     * This method insert the data about a LocalDataModel into the DB
     *
     * @param data The LocalDataModel to insert
     * @return The id of the new inserted data
     */
    public long insert(final LocalDataModel data) {
        long newId = -1;
        if (mDb.isOpen()) {
            // We create the Values
            final ContentValues values = data.asValues();
            // We insert the values into the DB
            newId = mDb.insert(UghoDB.HoroVote.TABLE_NAME, UghoDB.HoroVote.LOCATION, values);
        }
        return newId;
    }

    /**
     * The sign is mandatory so we added this method
     *
     * @param data     The data to insert
     * @param signName The related sign name
     * @return The id of the new inserted data
     */
    public long insertWithSign(final LocalDataModel data, final String signName) {
        long newId = -1;
        if (mDb.isOpen()) {
            // We create the Values
            final ContentValues values = data.asValues();
            // We add the sign name
            values.put(UghoDB.HoroVote.HORO_SIGN, signName);
            // We insert the values into the DB
            newId = mDb.insert(UghoDB.HoroVote.TABLE_NAME, UghoDB.HoroVote.LOCATION, values);
        }
        return newId;
    }

    /**
     * This method update the given LocalDataModel which must have an id
     *
     * @param data The LocaLDataModel to update
     * @return The number of updated data (0, 1 ore -1)
     */
    public int update(final LocalDataModel data) {
        int updated = -1;
        if (mDb.isOpen()) {
            // We create the Values
            final ContentValues values = data.asValues();
            final String where = UghoDB.HoroVote._ID + " = ?";
            final String[] whereArgs = new String[]{String.valueOf(data.id)};
            // We update the values into the DB
            updated = mDb.update(UghoDB.HoroVote.TABLE_NAME, values, where, whereArgs);
        }
        return updated;
    }


    /**
     * Bad implementation for the query method. We load everything in memory. What about if we have
     * many records?
     *
     * @param where     The where for the query
     * @param whereArgs The arguments for the where
     * @return The array of the results
     */
    public LocalDataModel[] worseQuery(final String where, final String[] whereArgs) {
        // We create the LocalDataModel
        LocalDataModel[] result = null;
        // We execute the query
        if (mDb.isOpen()) {
            final Cursor cursor = mDb.query(UghoDB.HoroVote.TABLE_NAME, null, where, whereArgs, null, null, null);
            result = new LocalDataModel[cursor.getCount()];
            int index = 0;
            while (cursor.moveToNext()) {
                long id = cursor.getLong(cursor.getColumnIndex(UghoDB.HoroVote._ID));
                long entryDate = cursor.getLong(cursor.getColumnIndex(UghoDB.HoroVote.ENTRY_DATE));
                int loveVote = cursor.getInt(cursor.getColumnIndex(UghoDB.HoroVote.LOVE_VOTE));
                int healthVote = cursor.getInt(cursor.getColumnIndex(UghoDB.HoroVote.HEALTH_VOTE));
                int workVote = cursor.getInt(cursor.getColumnIndex(UghoDB.HoroVote.WORK_VOTE));
                int luckVote = cursor.getInt(cursor.getColumnIndex(UghoDB.HoroVote.LUCK_VOTE));
                LocalDataModel item = LocalDataModel.create(id, entryDate, loveVote, healthVote, workVote, luckVote);
                result[index++] = item;
            }
            cursor.close();
        }
        // We return the result
        return result;
    }

    /**
     * This method execute a query and return the result as an Iterator of LocalDataModel
     *
     * @param where     The where clause
     * @param whereArgs The arguments for the where clause
     * @return The Iterator over the result objects
     */
    public Iterator<LocalDataModel> queryIterator(final String where, final String[] whereArgs) {
        Iterator<LocalDataModel> resultIterator = null;
        // We execute the query
        if (mDb.isOpen()) {
            final Cursor cursor = mDb.query(UghoDB.HoroVote.TABLE_NAME, null, where, whereArgs, null, null, null);
            resultIterator = new Iterator<LocalDataModel>() {
                @Override
                public boolean hasNext() {
                    boolean moreData = cursor.moveToNext();
                    if (!moreData) {
                        // We close the cursor if there are no data
                        cursor.close();
                    }
                    return moreData;
                }

                @Override
                public LocalDataModel next() {
                    return LocalDataModel.fromCursor(cursor);
                }

                @Override
                public void remove() {
                }
            };
        } else {
            // We create an empty iterator
            resultIterator = new Iterator<LocalDataModel>() {
                @Override
                public boolean hasNext() {
                    return false;
                }

                @Override
                public LocalDataModel next() {
                    return null;
                }

                @Override
                public void remove() {
                }
            };
        }
        // We return the Iterator
        return resultIterator;
    }

    /**
     * The standard version of query method. It returns the Cursor that should be managed by the caller object
     *
     * @param where     The where clause
     * @param whereArgs The arguments for the where clause
     * @return The Cursor implementations with the result
     */
    public Cursor simpleQuery(final String where, final String[] whereArgs) {
        Cursor cursor = null;
        // We execute the query
        if (mDb.isOpen()) {
            cursor = mDb.query(UghoDB.HoroVote.TABLE_NAME, null, where, whereArgs, null, null, null);
        }
        return cursor;
    }

    /**
     * The simpler version of query method. It returns the Cursor that should be managed by the caller object
     *
     * @param where     The where clause
     * @param whereArgs The arguments for the where clause
     * @return The Cursor implementations with the result
     */
    public LocalDataCursorFactory.LocalDataCursor customQuery(final String where, final String[] whereArgs) {
        LocalDataCursorFactory.LocalDataCursor cursor = null;
        // We execute the query
        if (mDb.isOpen()) {
            cursor = (LocalDataCursorFactory.LocalDataCursor) mDb.query(UghoDB.HoroVote.TABLE_NAME, null,
                    where, whereArgs, null, null, null);
        }
        return cursor;
    }

    /**
     * This method checks if the data is already present or not
     *
     * @param date The date to check
     * @return True if already present and false otherwise
     */
    public boolean dateExists(final Date date) {
        boolean isPresent = false;
        // We execute the query
        if (mDb.isOpen()) {
            final String where = UghoDB.HoroVote.ENTRY_DATE + " = ?";
            final String[] whereArgs = new String[]{String.valueOf(date.getTime())};
            // We update the values into the DB
            Cursor cursor = mDb.query(UghoDB.HoroVote.TABLE_NAME, null, where, whereArgs, null, null, null);
            isPresent = cursor.moveToNext();
            cursor.close();
        }
        return isPresent;
    }

    /**
     * This method closes the UghoDB. It's safe so if already closed it does nothing
     */
    public void close() {
        if (mDb != null && mDb.isOpen()) {
            mDb.close();
        }
    }

}
