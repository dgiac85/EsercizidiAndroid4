CREATE TABLE HORO_VOTE (
	_id integer PRIMARY KEY AUTOINCREMENT UNIQUE,
	entry_date date NOT NULL UNIQUE,
	love_vote integer NOT NULL,
	health_vote integer NOT NULL,
	work_vote integer NOT NULL,
	luck_vote integer NOT NULL,
	horo_sign text NOT NULL,
	location text);
CREATE INDEX UNIQUE_ENTRY_DATE ON HORO_VOTE (_id,entry_date);