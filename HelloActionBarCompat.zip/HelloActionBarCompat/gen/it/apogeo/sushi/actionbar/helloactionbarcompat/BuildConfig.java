/** Automatically generated file. DO NOT MODIFY */
package it.apogeo.sushi.actionbar.helloactionbarcompat;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}