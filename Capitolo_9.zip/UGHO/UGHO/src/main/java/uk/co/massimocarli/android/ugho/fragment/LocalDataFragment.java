package uk.co.massimocarli.android.ugho.fragment;


import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.ListFragment;
import android.util.Log;
import android.view.*;
import android.widget.*;
import uk.co.massimocarli.android.ugho.R;
import uk.co.massimocarli.android.ugho.conf.Const;
import uk.co.massimocarli.android.ugho.model.LocalDataModel;
import uk.co.massimocarli.android.ugho.service.LocalVoteService;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * Created by Massimo Carli on 15/06/13.
 */
public class LocalDataFragment extends ListFragment {

    /**
     * The tag for the log
     */
    private static final String TAG_LOG = LocalDataFragment.class.getName();

    /**
     * The DateFormatter for the date of the votes
     */
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("E dd MMMM yyyy");

    /**
     * The number of different type of layouts
     */
    private static final int VIEW_TYPE_NUMBER = 2;

    /**
     * The Adapter to use
     */
    private BaseAdapter mAdapter;

    /**
     * The local list we use for the adapters
     */
    private List<LocalDataModel> mModel = new LinkedList<LocalDataModel>();


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // We have some option menu
        setHasOptionsMenu(true);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // We inflate our custom layout
        View customLayout = inflater.inflate(R.layout.activity_list_layout, null);
        return customLayout;
    }

    @Override
    public void onStart() {
        super.onStart();
        // We create the adapters to assign to the listView
        mAdapter = new BaseAdapter() {
            @Override
            public int getCount() {
                return mModel.size();
            }

            @Override
            public Object getItem(int position) {
                return mModel.get(position);
            }

            @Override
            public long getItemId(int position) {
                // Get the item at the given position
                LocalDataModel model = (LocalDataModel) getItem(position);
                return model.id;
            }

            @Override
            public int getViewTypeCount() {
                return VIEW_TYPE_NUMBER;
            }

            @Override
            public int getItemViewType(int position) {
                return position % 2;
            }

            @Override
            public View getView(int position, View view, ViewGroup viewGroup) {
                LayoutInflater inflater = LayoutInflater.from(getActivity());
                // Here we test if the given View is null. If not we can reuse it otherwise
                // we have to create a new one inflating it
                if (view == null) {
                    // We have to inflate the layout for the current type
                    if (getItemViewType(position) == 0) {
                        view = inflater.inflate(R.layout.custom_list_item, null);
                    } else {
                        view = inflater.inflate(R.layout.custom_list_item_2, null);
                    }
                }
                // We get the reference to the elements in the UI
                final TextView dateTextView = (TextView) view.findViewById(R.id.list_item_date);
                final TextView loveVoteTextView = (TextView) view.findViewById(R.id.list_item_love_vote);
                final TextView healthVoteTextView = (TextView) view.findViewById(R.id.list_item_health_vote);
                final TextView workVoteTextView = (TextView) view.findViewById(R.id.list_item_work_vote);
                final TextView luckVoteTextView = (TextView) view.findViewById(R.id.list_item_luck_vote);
                // We get the current value from the Model
                final LocalDataModel itemModel = (LocalDataModel) getItem(position);
                // Set the values to the UI elements
                dateTextView.setText(DATE_FORMAT.format(itemModel.entryDate));
                loveVoteTextView.setText(getResources().getString(R.string.love_value_pattern, itemModel.loveVote));
                healthVoteTextView.setText(getResources().getString(R.string.health_value_pattern, itemModel.healthVote));
                workVoteTextView.setText(getResources().getString(R.string.work_value_pattern, itemModel.workVote));
                luckVoteTextView.setText(getResources().getString(R.string.luck_value_pattern, itemModel.luckVote));
                // We return the View
                return view;
            }
        };
        // We assign the adapters to the ListView
        setListAdapter(mAdapter);
    }


    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        Toast.makeText(getActivity(), "Selected position: " + position, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.activity_list, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.action_update_list) {
            // We get the model
            final LocalVoteService.VoteTransferObject result = LocalVoteService.sLocalVoteService.loadVotes(0, 100);
            // We update the adapters
            mModel.clear();
            mModel.addAll(result.mData);
            mAdapter.notifyDataSetChanged();
        }
        return super.onOptionsItemSelected(menuItem);
    }
}
