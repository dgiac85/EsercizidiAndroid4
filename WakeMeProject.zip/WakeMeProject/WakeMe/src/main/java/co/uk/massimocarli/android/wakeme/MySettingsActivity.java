package co.uk.massimocarli.android.wakeme;

import android.os.Bundle;
import android.preference.PreferenceActivity;

/**
 * A {@link PreferenceActivity} for our application.
 */
public class MySettingsActivity extends PreferenceActivity {


    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        // We configure the Settings from the configuration file
        addPreferencesFromResource(R.xml.settings);
    }


}
