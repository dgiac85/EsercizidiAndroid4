package co.uk.massimocarli.android.wakeme.fragment;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;

/**
 * This is an extension of the SupportMapFragment that notify the activity that the map
 * is ready. This prevent the NullPointerException that often happens in these cases.
 * <p/>
 * <p/>
 * Created by Massimo Carli on 20/06/2013.
 */
public class CallbackMapFragment extends SupportMapFragment {


    /**
     * Interface that notifies the GoogleMap ready to be used.
     */
    public interface OnGoogleMapReadyListener {

        /**
         * This is invoked to notify that the map is ready to be used
         *
         * @param googleMap The GoogleMap
         */
        void mapIsReady(GoogleMap googleMap);

    }

    /**
     * The listener of the GoogleMap ready
     */
    private OnGoogleMapReadyListener mOnGoogleMapReadyListener;


    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        // If the Activity implements the OnGoogleMapReadyListener we save the reference
        // so we can notify that the GoogleMap is ready
        if (activity instanceof OnGoogleMapReadyListener) {
            mOnGoogleMapReadyListener = (OnGoogleMapReadyListener) activity;
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View superView = super.onCreateView(inflater, container, savedInstanceState);
        // The view is ready so we notify if needed
        if (mOnGoogleMapReadyListener != null) {
            mOnGoogleMapReadyListener.mapIsReady(getMap());
        }
        // Return the previous created View
        return superView;
    }
}
