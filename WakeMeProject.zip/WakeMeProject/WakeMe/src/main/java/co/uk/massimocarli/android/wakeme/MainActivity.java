package co.uk.massimocarli.android.wakeme;

import android.app.Activity;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import co.uk.massimocarli.android.wakeme.fragment.CallbackMapFragment;
import co.uk.massimocarli.android.wakeme.service.ActivityRecognitionService;
import co.uk.massimocarli.android.wakeme.service.GeofenceService;
import co.uk.massimocarli.android.wakeme.util.WakeMeUtility;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.location.*;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.*;

import java.io.IOException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class MainActivity extends FragmentActivity implements CallbackMapFragment.OnGoogleMapReadyListener {

    /**
     * The Tag for the Log
     */
    private static final String TAG_LOG = MainActivity.class.getName();

    /**
     * The requestId we use for the Activity that should solve our connection
     * problem if any.
     */
    private static final int CONNECTION_FAILURE_RESOLUTION_REQUEST = 999;

    /**
     * Our update interval is 1 second
     */
    private static final long UPDATE_INTERVAL = 1000;

    /**
     * Our update interval is at least 800 milliseconds
     */
    private static final long FASTEST_UPDATE_INTERVAL = 800;

    /**
     * THe default radius for Geofence
     */
    private static final float DEFAULT_RADIUS = 300.0F;

    /**
     * The request Id for our fence
     */
    private static final String GEOFENCE_REQUEST_ID = "WakeMeFence";

    /**
     * This is the Tag we use for the MapFragment
     */
    private static final String MAP_FRAGMENT_TAG = Conf.PKG + ".tag.MAP_FRAGMENT_TAG";

    /**
     * Activity Recognition - The interval between detection events
     */
    public static final long DETECTION_INTERVAL_MILLISECONDS = 20 * 1000L;

    /**
     * The PendingIntent we use for Activity Recognition
     */
    private PendingIntent mActivityRecognitionPendingIntent;

    /**
     * The reference to the ActivityRecognitionClient object
     */
    private ActivityRecognitionClient mActivityRecognitionClient;

    /**
     * The Reference to the ErrorDialog
     */
    private Dialog mErrorDialog;

    /**
     * If present, it contains the currentLocation
     */
    private Location mCurrentLocation;

    /**
     * The object we use to interact with the Map
     */
    private GoogleMap mGoogleMap;

    /**
     * The MapPreferences
     */
    private SharedPreferences mMapPref;

    /**
     * The current Marker for this position
     */
    private Marker mHereMarker;

    /**
     * Our listener for the Location update
     */
    private LocationListener mLocationListener = new LocationListener() {

        @Override
        public void onLocationChanged(Location location) {
            Log.d(TAG_LOG, "Updated Location: " + location);
            showMapFragment();
        }
    };

    /**
     * Create a custom Info Window in the container and the content
     */
    private GoogleMap.InfoWindowAdapter mCompleteInfoWindowAdapter = new GoogleMap.InfoWindowAdapter() {

        /**
         * The content for the Info Window
         */
        private View mViewContent;

        /**
         * The Holder for the ContentView
         */
        class ContentHolder {

            private TextView titleView;

            private TextView snippetView;
        }

        @Override
        public View getInfoWindow(Marker marker) {
            /*
            ContentHolder holder = null;
            if (mViewContent == null) {
                mViewContent = getLayoutInflater().inflate(R.layout.info_window_container, null);
                holder = new ContentHolder();
                holder.titleView = (TextView) mViewContent.findViewById(R.id.info_window_title);
                holder.snippetView = (TextView) mViewContent.findViewById(R.id.info_window_snippet);
                mViewContent.setTag(holder);
            } else {
                holder = (ContentHolder) mViewContent.getTag();
            }
            // We show the data
            holder.titleView.setText(marker.getTitle());
            holder.snippetView.setText(marker.getSnippet());
            */
            return null;
        }

        @Override
        public View getInfoContents(Marker marker) {
            ContentHolder holder = null;
            if (mViewContent == null) {
                mViewContent = getLayoutInflater().inflate(R.layout.info_window_content, null);
                holder = new ContentHolder();
                holder.titleView = (TextView) mViewContent.findViewById(R.id.info_window_title);
                holder.snippetView = (TextView) mViewContent.findViewById(R.id.info_window_snippet);
                mViewContent.setTag(holder);
            } else {
                holder = (ContentHolder) mViewContent.getTag();
            }
            // We show the data
            holder.titleView.setText(marker.getTitle());
            holder.snippetView.setText(marker.getSnippet());
            // We return the View
            return mViewContent;
        }
    };

    /**
     * We manage the selection of the Info Window for a Marker
     */
    private GoogleMap.OnInfoWindowClickListener mInfoWindowListener = new GoogleMap.OnInfoWindowClickListener() {
        @Override
        public void onInfoWindowClick(Marker marker) {
            // We execute the AsyncTask passing the coordinates of the location
            final LatLng markerPosition = marker.getPosition();
            final GeocoderAsyncTask geoCoderAsync = new GeocoderAsyncTask();
            geoCoderAsync.execute(markerPosition.latitude, markerPosition.longitude);
        }
    };

    /**
     * The AsyncTask to get the current Address
     */
    private class GeocoderAsyncTask extends AsyncTask<Double, Void, Address> {

        @Override
        protected void onPostExecute(Address address) {
            super.onPostExecute(address);
            // Here we need to show the address
            if (address != null) {
                final String addressStr = address.getLocality() + " " + address.getPostalCode();
                Toast.makeText(getApplicationContext(), addressStr, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getApplicationContext(), "Service not available or error!", Toast.LENGTH_SHORT).show();
            }

        }

        @Override
        protected Address doInBackground(Double... coordinates) {
            // We test the presence of the Geocoder
            final boolean geoExists = Geocoder.isPresent();
            Address candidateAddress = null;
            if (geoExists) {
                final Geocoder geocoder = new Geocoder(getApplicationContext());
                try {
                    final List<Address> addresses = geocoder.getFromLocation(coordinates[0], coordinates[1], 1);
                    if (addresses != null && addresses.size() != 0) {
                        candidateAddress = addresses.get(0);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return candidateAddress;
        }
    }

    /**
     * The current Circle to define
     */
    private Circle mCurrentCircle;

    /**
     * The current Geofence instances
     */
    private List<Geofence> mCurrentGeofences = new LinkedList<Geofence>();

    /**
     * Interface to implement to manage Geofence
     */
    private LocationClient.OnAddGeofencesResultListener mOnAddGeofencesResultListener = new LocationClient.OnAddGeofencesResultListener() {

        @Override
        public void onAddGeofencesResult(int statusCode, String[] geofenceRequestIds) {
            if (LocationStatusCodes.SUCCESS == statusCode) {
                // The Geofence service is started successfully
            } else {
                // Error managing Geofence
            }
        }
    };

    /**
     * Implementation of the long click to define the current circle region
     */
    private GoogleMap.OnMapLongClickListener mOnMapLongClickListener = new GoogleMap.OnMapLongClickListener() {
        @Override
        public void onMapLongClick(LatLng latLng) {
            // If another Circle exists we remove it
            if (mCurrentCircle != null) {
                mCurrentCircle.remove();
                mCurrentGeofences.clear();
                // We remove the Geofence monitoring
                final String[] geoFenceToRemove = new String[]{GEOFENCE_REQUEST_ID};
                mLocationClient.removeGeofences(Arrays.asList(geoFenceToRemove), mOnRemoveGeofencesResultListener);
            }
            // We create the new Circle
            final CircleOptions circleOptions = new CircleOptions()
                    .center(latLng)
                    .radius(DEFAULT_RADIUS)
                    .strokeColor(Color.BLUE)
                    .strokeWidth(2.0f)
                    .fillColor(Color.parseColor("#66FF0000"));
            mCurrentCircle = mGoogleMap.addCircle(circleOptions);
            // We create the Geofence
            Geofence.Builder fenceBuilder = new Geofence.Builder()
                    .setCircularRegion(latLng.latitude, latLng.longitude, DEFAULT_RADIUS)
                    .setExpirationDuration(Geofence.NEVER_EXPIRE)
                    .setRequestId(GEOFENCE_REQUEST_ID)
                    .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER | Geofence.GEOFENCE_TRANSITION_EXIT);
            // We create the PendingIntent to launch when the event happens
            final Intent fenceIntent = new Intent(getApplicationContext(), GeofenceService.class);
            final PendingIntent fencePendingIntent = PendingIntent.getService(getApplicationContext(), 0, fenceIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT);
            mCurrentGeofences.add(fenceBuilder.build());
            // We add the Geofence to the LocationManager
            mLocationClient.addGeofences(mCurrentGeofences, fencePendingIntent, mOnAddGeofencesResultListener);
        }
    };

    /**
     * This interface manages the result of the deletion Geofence
     */
    private LocationClient.OnRemoveGeofencesResultListener mOnRemoveGeofencesResultListener =
            new LocationClient.OnRemoveGeofencesResultListener() {
                @Override
                public void onRemoveGeofencesByRequestIdsResult(int i, String[] strings) {

                }

                @Override
                public void onRemoveGeofencesByPendingIntentResult(int i, PendingIntent pendingIntent) {

                }
            };

    /**
     * Implementation of the OnMapClickListener to manage simple click
     */
    private GoogleMap.OnMapClickListener mOnMapClickListener = new GoogleMap.OnMapClickListener() {
        @Override
        public void onMapClick(LatLng latLng) {
            if (mCurrentCircle != null) {
                // We have to calculate the distance using the LatLng object
                final LatLng centerPoint = mCurrentCircle.getCenter();
                final LatLng clickedPoint = latLng;
                final double distance = Math.abs(WakeMeUtility.getDistance(centerPoint, clickedPoint));
                if (distance < mCurrentCircle.getRadius()) {
                    // We remove it
                    mCurrentCircle.remove();
                    mCurrentCircle = null;
                    // We remove the Geofence monitoring
                    final String[] geoFenceToRemove = new String[]{GEOFENCE_REQUEST_ID};
                    mLocationClient.removeGeofences(Arrays.asList(geoFenceToRemove), mOnRemoveGeofencesResultListener);
                }
            }
        }
    };

    /**
     * This is the implementation of the ConnectionCallbacks interface that manages
     * the callback about the connection with the Google Play Services
     */
    private GooglePlayServicesClient.ConnectionCallbacks mConnectionCallbacks
            = new GooglePlayServicesClient.ConnectionCallbacks() {

        @Override
        public void onConnected(Bundle bundle) {
            Log.d(TAG_LOG, "Connected with Google Play Services");
            //Toast.makeText(MainActivity.this, "Connected", Toast.LENGTH_SHORT).show();
            // We show the currentLocation
            mCurrentLocation = mLocationClient.getLastLocation();
            if (mCurrentLocation != null) {
                //Toast.makeText(MainActivity.this, "Last Location: " + mCurrentLocation, Toast.LENGTH_SHORT).show();
                showMapFragment();
            } else {
                //Toast.makeText(MainActivity.this, "Location not yet available", Toast.LENGTH_SHORT).show();
            }
            // In all the cases we start the LocationUpdate with the given LocationRequest
            final LocationRequest locationRequest = new LocationRequest();
            locationRequest.setInterval(UPDATE_INTERVAL);
            locationRequest.setFastestInterval(FASTEST_UPDATE_INTERVAL);
            locationRequest.setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);
            mLocationClient.requestLocationUpdates(locationRequest, mLocationListener);
            // We request updates fot ActivityRecognition
            mActivityRecognitionClient.requestActivityUpdates(DETECTION_INTERVAL_MILLISECONDS,
                    mActivityRecognitionPendingIntent);
            mActivityRecognitionClient.disconnect();
        }

        @Override
        public void onDisconnected() {
            Log.d(TAG_LOG, "Disconnected with Google Play Services");
            Toast.makeText(MainActivity.this, "Disconnected", Toast.LENGTH_SHORT).show();
        }
    };

    /**
     * This is the implementation of the OnConnectionFailedListener interface to manage
     * the errors if any from the connection to the Google Play Services
     */
    private GooglePlayServicesClient.OnConnectionFailedListener mOnConnectionFailedListener =
            new GooglePlayServicesClient.OnConnectionFailedListener() {
                @Override
                public void onConnectionFailed(ConnectionResult connectionResult) {
                    // Here we check if the connectionResult has a resolution for the
                    // happened problem
                    if (connectionResult.hasResolution()) {
                        // Here we have a resolution so we start the related Activity
                        try {
                            // Start an Activity that tries to resolve the error
                            connectionResult.startResolutionForResult(
                                    MainActivity.this,
                                    CONNECTION_FAILURE_RESOLUTION_REQUEST);
                            // The previous method should throws an exception if
                            // the services cancelled the intent.
                        } catch (IntentSender.SendIntentException e) {
                            // We have to manage this error. We show a toast
                            Toast.makeText(MainActivity.this, "Resolution Intent deleted!",
                                    Toast.LENGTH_SHORT).show();
                            e.printStackTrace();
                        }
                    } else {
                        // In this case there's no resolution so we just show a message
                        Toast.makeText(MainActivity.this, "Error with code " +
                                connectionResult.getErrorCode(), Toast.LENGTH_SHORT).show();
                    }
                }
            };

    /**
     * The requestId for the Play download management.
     */
    private static final int PLAY_DOWNLOAD_REQUEST_ID = 1;


    /**
     * The LocationClient
     */
    private LocationClient mLocationClient;

    @Override
    protected void onStart() {
        super.onStart();
        // We connect the LocationClient
        mLocationClient.connect();
        // We start the Activity Recognition Client
        mActivityRecognitionClient.connect();
    }

    @Override
    protected void onStop() {
        if (mLocationClient.isConnected()) {
            mLocationClient.removeLocationUpdates(mLocationListener);
        }
        // We disconnect the LocationClient
        mLocationClient.disconnect();
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Here we check if the PLay Services APK is installed on the device and
        // for which version
        final int checkPlayStatus = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
        if (checkPlayStatus == ConnectionResult.SUCCESS) {
            // In this case everything is ok so we go on
            Log.d(TAG_LOG, "Everything is ok!");
        } else {
            // Here there's some problems so we get the dialog to manage it
            // with the user and ask him what to do.
            mErrorDialog = GooglePlayServicesUtil.getErrorDialog(checkPlayStatus,
                    this, PLAY_DOWNLOAD_REQUEST_ID, new DialogInterface.OnCancelListener() {
                @Override
                public void onCancel(DialogInterface dialog) {
                    // The SDK is mandatory
                    finish();
                }
            });
            mErrorDialog.show();
        }
        // Set the map type
        if (mGoogleMap != null) {
            synchMapType();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PLAY_DOWNLOAD_REQUEST_ID) {
            if (resultCode == Activity.RESULT_OK) {
                Log.d(TAG_LOG, "Result OK!");
            } else if (resultCode == Activity.RESULT_CANCELED) {
                Log.d(TAG_LOG, "Cancelled!");
                finish();
            } else {
                Log.d(TAG_LOG, "Dunno!!");
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_settings:
                Intent settingsIntent = new Intent(this, MySettingsActivity.class);
                startActivity(settingsIntent);
                break;
            case R.id.action_center_map:
                // We get the information about animations enabled or not enabled
                //final boolean animationEnabled = mMapPref.getBoolean(Conf.SettingKeys.MAP_ANIMATION_KEY, true);
                //centerHere(mCurrentLocation, animationEnabled);
                // Use this method to test the bounds
                showItaly();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * Utility method that shows the SupportMapFragment for the given location if present
     */
    private void showMapFragment() {
        Fragment existingMapFragment = getSupportFragmentManager().findFragmentByTag(MAP_FRAGMENT_TAG);
        if (existingMapFragment == null && mCurrentLocation != null) {
            // We create the MapFragment to show the location into Map
            SupportMapFragment mapFragment = new CallbackMapFragment();
            FragmentTransaction fragmentTransaction =
                    getSupportFragmentManager().beginTransaction();
            fragmentTransaction.add(R.id.anchor_point, mapFragment, MAP_FRAGMENT_TAG);
            fragmentTransaction.commit();
        } else {
            // We get the mGoogleMap from the existing object
            mGoogleMap = ((SupportMapFragment) existingMapFragment).getMap();
            mGoogleMap.setMyLocationEnabled(true);
            mGoogleMap.setOnInfoWindowClickListener(mInfoWindowListener);
            // Set the map type
            synchMapType();
            // We create the marker and we add it
            final LatLng newLatLng = new LatLng(mCurrentLocation.getLatitude(), mCurrentLocation.getLongitude());
            if (mHereMarker == null) {
                mGoogleMap.setInfoWindowAdapter(mCompleteInfoWindowAdapter);
                final MarkerOptions markerOptions = new MarkerOptions();
                markerOptions.position(newLatLng).anchor(0.5f, 1.0f)
                        .title("My Position 2")
                        .snippet("[" + newLatLng.latitude + ", " + newLatLng.longitude + "]");
                //.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE))
                //.icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_launcher));
                mHereMarker = mGoogleMap.addMarker(markerOptions);
                // Example of Polyline
                //drawPolyline();
                // Example of Polygon
                //drawPolygon();
                // Example of Circle
                //drawCircle();
                // We manage the current Circle to add
                mGoogleMap.setOnMapLongClickListener(mOnMapLongClickListener);
                mGoogleMap.setOnMapClickListener(mOnMapClickListener);
                /*
                // These are lines of code we used to test the different values for hue
                final LatLng newLatLng2 = new LatLng(mCurrentLocation.getLatitude(), mCurrentLocation.getLongitude() - .002f);
                final MarkerOptions markerOptions2 = new MarkerOptions();
                markerOptions2.position(newLatLng2)
                        .title("My Position 1")
                        .draggable(true)
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE - 15.0f));
                mGoogleMap.addMarker(markerOptions2);
                final LatLng newLatLng3 = new LatLng(mCurrentLocation.getLatitude(), mCurrentLocation.getLongitude() + .002f);
                final MarkerOptions markerOptions3 = new MarkerOptions();
                markerOptions3.position(newLatLng3)
                        .title("My Position 3")
                        .draggable(true)
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE + 15.0f));
                mGoogleMap.addMarker(markerOptions3);
                */

            } else {
                mHereMarker.setPosition(newLatLng);
            }
        }
    }

    @Override
    public void mapIsReady(final GoogleMap googleMap) {
        // Save the GoogleMap reference
        mGoogleMap = googleMap;
        // Set the map type
        synchMapType();
        // We center the map to the current location
        centerHere(mCurrentLocation, true);
    }


    /**
     * Utility method that synchronise the map type with what into the preferences
     */
    private void synchMapType() {
        // We read the type of map into the preferences and put it for the Map
        String mapTypePrefs = PreferenceManager.getDefaultSharedPreferences(this).getString(Conf.SettingKeys.MAP_TYPE_KEY, null);
        int mapType = WakeMeUtility.getGoogleMapTypeFromResourceValue(this, mapTypePrefs);
        mGoogleMap.setMapType(mapType);
    }


    /**
     * Utility method that center the map into the given position
     *
     * @param animated        If true we use animation
     * @param currentLocation The location for centering the map
     */
    private void centerHere(final Location currentLocation, final boolean animated) {
        if (currentLocation == null) {
            // Location at the moment not available
            return;
        }
        // We get the LatLng object from the Location object
        final LatLng currentLatLng = new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude());
        // We get the CameraUpdate for the given position
        //CameraUpdate positionUpdate = CameraUpdateFactory.newLatLng(currentLatLng);
        // We use the version with the zoom value
        CameraUpdate positionUpdate = CameraUpdateFactory.newLatLngZoom(currentLatLng, Conf.START_ZOOM_LEVEL);
        if (animated) {
            // With the animation
            mGoogleMap.animateCamera(positionUpdate, Conf.MAP_ANIMATION_DURATION, new GoogleMap.CancelableCallback() {
                @Override
                public void onFinish() {
                    Log.d(TAG_LOG, "Map Animation Finished");
                }

                @Override
                public void onCancel() {
                    Log.d(TAG_LOG, "Map Animation Canceled");
                }
            });
        } else {
            // We use the CameraUpdate to center the map
            mGoogleMap.moveCamera(positionUpdate);
        }

    }


    /**
     * Test method that shows a bounds for the main italian cities
     */
    private void showItaly() {
        // Defines location for italian cities
        final LatLng trieste = new LatLng(45.649535, 13.777972);
        final LatLng palermo = new LatLng(38.115688, 13.361267);
        // We create the LatLngBounds
        LatLngBounds latLngBounds = new LatLngBounds(palermo, trieste);
        // We get the CameraUpdate to show that bounds
        CameraUpdate boundsCameraUpdate = CameraUpdateFactory.newLatLngBounds(latLngBounds, Conf.BOUNDS_PADDING);
        // We move there
        mGoogleMap.moveCamera(boundsCameraUpdate);
    }

    /**
     * Example of a Polyline
     */
    private void drawPolyline() {
        // We create the PolylineOptions relative to the current position
        final double step = 0.005;
        final double startLat = mCurrentLocation.getLatitude();
        final double startLon = mCurrentLocation.getLongitude();
        final PolylineOptions polylineOptions = new PolylineOptions()
                .add(new LatLng(startLat, startLon))
                .add(new LatLng(startLat + step, startLon))
                .add(new LatLng(startLat + step, startLon + step))
                .add(new LatLng(startLat, startLon + step))
                .add(new LatLng(startLat, startLon))
                .color(Color.RED);
        final Polyline newPolyline = mGoogleMap.addPolyline(polylineOptions);
    }

    /**
     * Example of a Polygon
     */
    private void drawPolygon() {
        // We create the PolygonOptions relative to the current position
        final double step = 0.005;
        final double startLat = mCurrentLocation.getLatitude();
        final double startLon = mCurrentLocation.getLongitude();
        final PolygonOptions polygonOptions = new PolygonOptions()
                .add(new LatLng(startLat, startLon))
                .add(new LatLng(startLat + step, startLon))
                .add(new LatLng(startLat + step, startLon + step))
                .add(new LatLng(startLat, startLon + step))
                .strokeColor(Color.BLUE)
                .strokeWidth(2.0f)
                .fillColor(Color.RED);
        final Polygon newPolygon = mGoogleMap.addPolygon(polygonOptions);
    }

    /**
     * Example of a Circle
     */
    private void drawCircle() {
        // We create the CircleOptions relative to the current position
        final double centerLat = mCurrentLocation.getLatitude();
        final double centerLon = mCurrentLocation.getLongitude();
        final CircleOptions circleOptions = new CircleOptions()
                .center(new LatLng(centerLat, centerLon))
                .radius(250)
                .strokeColor(Color.BLUE)
                .strokeWidth(2.0f)
                .fillColor(Color.YELLOW);
        final Circle newCircle = mGoogleMap.addCircle(circleOptions);
    }
}
