package co.uk.massimocarli.android.wakeme.service;

import android.app.IntentService;
import android.content.Intent;
import android.util.Log;
import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.LocationClient;

import java.util.List;

/**
 * Created by Massimo Carli on 28/07/13.
 */
public class GeofenceService extends IntentService {

    /**
     * The tag for the log
     */
    private static final String TAG_LOG = GeofenceService.class.getName();

    /**
     * Default constructor
     */
    public GeofenceService() {
        super("GeofenceService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        // Initially we check for the error. IN that case we show an error Log message
        if (LocationClient.hasError(intent)) {
            // We get the error code
            final int errorCode = LocationClient.getErrorCode(intent);
            // Show the Log error
            Log.e(TAG_LOG, "Geofence Service got an error with code:" + Integer.toString(errorCode));
        } else {
            // If everything is ok we get the information about the transacitonId of the event
            final int transactionId = LocationClient.getGeofenceTransition(intent);
            if (transactionId == Geofence.GEOFENCE_TRANSITION_ENTER || transactionId == Geofence.GEOFENCE_TRANSITION_EXIT) {
                // In this case the transactionId of for us
                List<Geofence> receivedGeofences = LocationClient.getTriggeringGeofences(intent);
                // Here ww can do what we want
                for (Geofence geofence : receivedGeofences) {
                    Log.d(TAG_LOG, "Geofence triggeredwith id " + geofence.getRequestId());
                }
                // Further elaborations
            } else {
                Log.e(TAG_LOG, "Check your code!! No transactionId into the received Intent");
            }
        }

    }
}
