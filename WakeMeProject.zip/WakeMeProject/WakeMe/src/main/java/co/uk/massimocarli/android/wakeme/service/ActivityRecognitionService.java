package co.uk.massimocarli.android.wakeme.service;

import android.app.IntentService;
import android.content.Intent;
import android.util.Log;
import com.google.android.gms.location.ActivityRecognitionResult;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.LocationClient;

import java.util.List;

/**
 * Created by Massimo Carli on 28/07/13.
 */
public class ActivityRecognitionService extends IntentService {

    /**
     * The tag for the log
     */
    private static final String TAG_LOG = ActivityRecognitionService.class.getName();

    /**
     * Default constructor
     */
    public ActivityRecognitionService() {
        super("ActivityRecognitionService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        // Initially we check that the ActivityRecognition has good results
        if (ActivityRecognitionResult.hasResult(intent)) {
            // We get the information into the received Intent
            ActivityRecognitionResult result = ActivityRecognitionResult.extractResult(intent);
            // We also have information on the accuracy of the data
            DetectedActivity mostProbableActivity = result.getMostProbableActivity();
            int confidence = mostProbableActivity.getConfidence();
            int activityType = mostProbableActivity.getType();
            String activityName = getNameFromType(activityType);
            // Others things to do
            Log.i(TAG_LOG, "NEW ACTIVITY RECOGNISED: " + activityName);
        }

    }

    /**
     * Utility method that returns the name of the activity from the type constants
     *
     * @param activityType The type constants
     * @return THe Name fo the Activity name
     */
    private String getNameFromType(int activityType) {
        switch (activityType) {
            case DetectedActivity.IN_VEHICLE:
                return "in_vehicle";
            case DetectedActivity.ON_BICYCLE:
                return "on_bicycle";
            case DetectedActivity.ON_FOOT:
                return "on_foot";
            case DetectedActivity.STILL:
                return "still";
            case DetectedActivity.UNKNOWN:
                return "unknown";
            case DetectedActivity.TILTING:
                return "tilting";
        }
        return "unknown";
    }
}
