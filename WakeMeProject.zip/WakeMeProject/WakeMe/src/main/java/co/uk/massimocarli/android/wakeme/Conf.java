package co.uk.massimocarli.android.wakeme;

import com.google.android.gms.maps.GoogleMap;

/**
 * This is a final class that contains constants and utility method
 * <p/>
 * Created by Massimo Carli on 20/06/2013.
 */
public final class Conf {

    /**
     * This is the name of this package
     */
    public static final String PKG = Conf.class.getPackage().toString();

    /**
     * The duration for the Map animation
     */
    public static final int MAP_ANIMATION_DURATION = 400;

    /**
     * The starting zoom value
     */
    public static final int START_ZOOM_LEVEL = 14;

    /**
     * The padding in pixel for the bounds
     */
    public static final int BOUNDS_PADDING = 100;

    /**
     * This is a class with the constants for Settings
     */
    public static class SettingKeys {

        /**
         * The key for the type of the Map into the settings
         */
        public static final String MAP_TYPE_KEY = "map_type";

        /**
         * The key for the type of the Map into the settings
         */
        public static final int DEFAULT_MAP_TYPE_ID = GoogleMap.MAP_TYPE_NORMAL;

        /**
         * The key for the map animation
         */
        public static final String MAP_ANIMATION_KEY = "map_animation";

    }


}
