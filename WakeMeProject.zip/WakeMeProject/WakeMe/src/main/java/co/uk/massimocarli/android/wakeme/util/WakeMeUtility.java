package co.uk.massimocarli.android.wakeme.util;

import android.content.Context;
import android.content.res.Resources;

import android.location.Location;
import com.google.android.gms.maps.GoogleMap;

import co.uk.massimocarli.android.wakeme.R;
import com.google.android.gms.maps.model.LatLng;

/**
 * This is a utility class for the application
 * <p/>
 * Created by Massimo Carli on 20/06/2013.
 */
public final class WakeMeUtility {

    /**
     * Private constructor
     */
    private WakeMeUtility() {
        throw new AssertionError("Never instantiate me! I'm an utility class!!!");
    }

    /**
     * This method returns the type of the map constants as defined by GoogleMap from the
     * one we defined as resources
     *
     * @param context       The Context
     * @param resourceValue The name of the mapType used in preferences
     * @return The GoogleMap map type constants. The default if not valid
     */
    public static int getGoogleMapTypeFromResourceValue(final Context context,
                                                        final String resourceValue) {
        final Resources resources = context.getResources();
        String currentValue = resources.getString(R.string.pref_map_type_normal);
        if (currentValue.equals(resourceValue)) {
            return GoogleMap.MAP_TYPE_NORMAL;
        }
        currentValue = resources.getString(R.string.pref_map_type_hybrid);
        if (currentValue.equals(resourceValue)) {
            return GoogleMap.MAP_TYPE_HYBRID;
        }
        currentValue = resources.getString(R.string.pref_map_type_satellite);
        if (currentValue.equals(resourceValue)) {
            return GoogleMap.MAP_TYPE_SATELLITE;
        }
        currentValue = resources.getString(R.string.pref_map_type_terrain);
        if (currentValue.equals(resourceValue)) {
            return GoogleMap.MAP_TYPE_TERRAIN;
        }
        currentValue = resources.getString(R.string.pref_map_type_none);
        if (currentValue.equals(resourceValue)) {
            return GoogleMap.MAP_TYPE_NONE;
        }
        // In this case we return the normal
        return GoogleMap.MAP_TYPE_NORMAL;
    }

    /**
     * Calculate distance between two location as LatLng
     *
     * @param first  The first LatLng
     * @param second The second LatLng
     * @return THe distance between the two points
     */
    public static double getDistance(final LatLng first, final LatLng second) {
        double dLat = Math.toRadians(second.latitude-first.latitude);
        double dLon = Math.toRadians(second.longitude - first.longitude);
        double a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(Math.toRadians(first.latitude)) * Math.cos(Math.toRadians(second.latitude)) *
                        Math.sin(dLon/2) * Math.sin(dLon/2);
        double c = 2 * Math.asin(Math.sqrt(a));
        return 6366000 * c;
    }


}
