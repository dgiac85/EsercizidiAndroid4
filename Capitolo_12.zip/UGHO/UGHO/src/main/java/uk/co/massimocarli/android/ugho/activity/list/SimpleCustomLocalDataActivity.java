package uk.co.massimocarli.android.ugho.activity.list;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import uk.co.massimocarli.android.ugho.R;
import uk.co.massimocarli.android.ugho.model.LocalDataModel;
import uk.co.massimocarli.android.ugho.service.LocalVoteService;

import java.util.LinkedList;
import java.util.List;

/**
 * This is the Activity we use to show local data using a very simple custom template for the row
 * <p/>
 * Created by Massimo Carli on 31/05/2013.
 */
public class SimpleCustomLocalDataActivity extends FragmentActivity {

    /**
     * The Tag of the Log for this class
     */
    private static final String TAG_LOG = SimpleCustomLocalDataActivity.class.getName();

    /**
     * The reference to the ListView for the LocalData
     */
    private ListView mListView;

    /**
     * The Adapter to use
     */
    private ArrayAdapter<LocalDataModel> mAdapter;

    /**
     * The local list we use for the adapters
     */
    private List<LocalDataModel> mModel = new LinkedList<LocalDataModel>();

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // We assign the layout
        setContentView(R.layout.simple_list_local_data);
        // We get the reference to the
        mListView = (ListView) findViewById(R.id.listView);
        // We create the adapters to assign to the listView
        mAdapter = new ArrayAdapter<LocalDataModel>(this, R.layout.simple_custom_list_item, R.id.list_item_value, mModel);
        // We assign the adapters to the ListView
        mListView.setAdapter(mAdapter);
    }

    @Override
    protected void onStart() {
        super.onStart();
        // We get the model
        final LocalVoteService.VoteTransferObject result = LocalVoteService.sLocalVoteService.loadVotes(0, 100);
        // We update the adapters
        mModel.clear();
        mModel.addAll(result.mData);
        mAdapter.notifyDataSetChanged();
    }
}