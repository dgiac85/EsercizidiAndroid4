package uk.co.massimocarli.android.ugho;

import android.app.Application;
import org.apache.http.HttpVersion;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.protocol.HTTP;
import uk.co.massimocarli.android.ugho.net.ThreadSafeHttpClientFactory;

/**
 * Created by Massimo Carli on 15/07/13.
 */
public class UghoApplication extends Application {


    /**
     * Static Factory Method for a Thread Sage HttpClient instance
     *
     * @return The ThreadSafe HttpClient instance
     */
    public static HttpClient getThreadSafeHttpClient() {
        return ThreadSafeHttpClientFactory.INSTANCE.getThreadSafeHttpClient();
    }

    /**
     * Static Factory Method for a default HttpClient instance
     *
     * @return The default HttpClient instance
     */
    public static HttpClient getHttpClient() {
        return new DefaultHttpClient();
    }

    /**
     * Releases the ThreadSafe HttpClient
     */
    public static void releaseThreadSafeHttpClient() {
        ThreadSafeHttpClientFactory.INSTANCE.release();
    }


}
