package uk.co.massimocarli.android.ugho.fragment;


import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import com.actionbarsherlock.app.SherlockFragment;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;
import uk.co.massimocarli.android.ugho.R;
import uk.co.massimocarli.android.ugho.appwidget.UghoAppWidgetProvider;
import uk.co.massimocarli.android.ugho.content.UghoDB;
import uk.co.massimocarli.android.ugho.content.dao.DAO;
import uk.co.massimocarli.android.ugho.content.dao.LocalDataCursorFactory;
import uk.co.massimocarli.android.ugho.model.LocalDataModel;
import uk.co.massimocarli.android.ugho.model.UserModel;
import uk.co.massimocarli.android.ugho.service.impl.ServiceUtil;
import uk.co.massimocarli.android.ugho.util.FontUtility;
import uk.co.massimocarli.android.ugho.util.Zodiac;
import uk.co.massimocarli.android.ugho.widget.CalendarChooser;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by Massimo Carli on 15/06/13.
 */
public class NewDataFragment extends SherlockFragment {

    /**
     * The tag for the log
     */
    private static final String TAG_LOG = NewDataFragment.class.getName();

    /**
     * The DateFormatter for the date of the votes
     */
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("E dd MMMM yyyy");

    /**
     * Milliseconds in a day
     */
    private static final long MILLIS_IN_DAY = 1000L * 3600 * 24;

    /**
     * Interface that should be implemented by the activity that uses this Fragment
     */
    public interface NewDataFragmentListener {

        /**
         * This is invoked to notify the choice on this menu.
         *
         * @param category The category choosen
         */
        void newDataForCategory(String category);

        /**
         * The WidgetId to update when inserting
         */
        int getAppWidgetId();

    }

    /**
     * The reference to the listener of this Fragment
     */
    private NewDataFragmentListener mListener;

    /**
     * The DAO for the UghoDB Access
     */
    private DAO mDao;

    /**
     * The current dat
     */
    private Calendar mCurrentDate;

    /**
     * RatingBar for the love
     */
    private RatingBar mLoveRatingBar;

    /**
     * RatingBar for the health
     */
    private RatingBar mHealthRatingBar;

    /**
     * RatingBar for the work
     */
    private RatingBar mWorkRatingBar;

    /**
     * RatingBar for the luck
     */
    private RatingBar mLuckRatingBar;

    /**
     * If true the data is already present
     */
    private boolean mDataExisting;

    /**
     * Information about user sign
     */
    private Zodiac mUserZodiac;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        mDao = DAO.get(getActivity());
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        if (activity instanceof NewDataFragmentListener) {
            mListener = (NewDataFragmentListener) activity;
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // We create the layout for this fragment
        final View voteView = inflater.inflate(R.layout.fragment_new_data, null);
        // Here we get the reference of all the item into the layout
        // The current date resetting the hours, minutes and milliseconds
        mCurrentDate = Calendar.getInstance();
        long currentTime = mCurrentDate.getTimeInMillis();
        currentTime = currentTime - (currentTime % MILLIS_IN_DAY);
        mCurrentDate.setTimeInMillis(currentTime);
        final String dateAsString = DATE_FORMAT.format(mCurrentDate.getTime());
        final TextView dateTextView = (TextView) voteView.findViewById(R.id.input_date);
        dateTextView.setText(dateAsString);
        // We get the information for the current user and show his/her sign
        final UserModel userModel = UserModel.load(getActivity());
        mUserZodiac = Zodiac.fromDate(userModel.getBirthDate());
        final ImageView signImageView = (ImageView) voteView.findViewById(R.id.input_sign_image);
        signImageView.setImageResource(mUserZodiac.getImageId());
        final TextView signTextView = (TextView) voteView.findViewById(R.id.input_sign_name);
        signTextView.setText(mUserZodiac.name());
        // We get the reference to the RatingBar
        mLoveRatingBar = (RatingBar) voteView.findViewById(R.id.love_rating_bar);
        mHealthRatingBar = (RatingBar) voteView.findViewById(R.id.health_rating_bar);
        mWorkRatingBar = (RatingBar) voteView.findViewById(R.id.work_rating_bar);
        mLuckRatingBar = (RatingBar) voteView.findViewById(R.id.luck_rating_bar);
        // We return the View for the fragment
        return voteView;
    }

    @Override
    public void onStart() {
        super.onStart();
        mDao.open();
        // We check if the current date is already present. If so we show them
        // and disable the RatingBar
        final String where = UghoDB.HoroVote.ENTRY_DATE + " = ?";
        final String[] whereArgs = new String[]{String.valueOf(mCurrentDate.getTimeInMillis())};
        LocalDataCursorFactory.LocalDataCursor localDataCursor = mDao.customQuery(where, whereArgs);
        mDataExisting = localDataCursor.moveToNext();
        if (mDataExisting) {
            final LocalDataModel currentModel = localDataCursor.asLocalDataModel();
            // The data is already present so we disable the RatingBar after the value injection
            mLoveRatingBar.setRating(currentModel.loveVote);
            mLoveRatingBar.setEnabled(false);
            mHealthRatingBar.setRating(currentModel.healthVote);
            mHealthRatingBar.setEnabled(false);
            mWorkRatingBar.setRating(currentModel.workVote);
            mWorkRatingBar.setEnabled(false);
            mLuckRatingBar.setRating(currentModel.luckVote);
            mLuckRatingBar.setEnabled(false);
        } else {
            // The data are not present
        }
    }


    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.sherlock_new_item, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        // We show  the option only if the data is not present
        menu.findItem(R.id.action_new_item).setEnabled(!mDataExisting);
        super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_new_item) {
            addItem();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onStop() {
        mDao.close();
        super.onStop();
    }

    @Override
    public void onDetach() {
        super.onDetach();
        this.mListener = null;
    }

    /**
     * Utility method for adding new item to the DB
     */
    private void addItem() {
        Log.d(TAG_LOG, "Inserting new data into DB");
        LocalDataModel newData = LocalDataModel.create(0, mCurrentDate.getTimeInMillis(), (int) mLoveRatingBar.getRating(),
                (int) mHealthRatingBar.getRating(), (int) mWorkRatingBar.getRating(), (int) mLuckRatingBar.getRating());
        long newId = mDao.insertWithSign(newData, mUserZodiac.name());
        if (newId > 0) {
            // We launch the Service for the sync with the server
            getActivity().startService(ServiceUtil.SYNC_INTENT);
            // We update the widget
            if (mListener != null) {
                // We get the AppWidgetManager
                final AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(getActivity());
                final int widgetToUpdate = mListener.getAppWidgetId();
                if (widgetToUpdate >= 0) {
                    Intent updateWidgetIntent = new Intent();
                    updateWidgetIntent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
                    updateWidgetIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, new int[]{widgetToUpdate});
                    Uri updateUri = Uri.withAppendedPath(Uri.parse("customappwidget://widget/id/"),
                            String.valueOf(widgetToUpdate));
                    updateWidgetIntent.setData(updateUri);
                    getActivity().sendBroadcast(updateWidgetIntent);
                } else {
                    // Notify the update to all
                }
            }
        }
        // We finish the Activity
        getActivity().finish();
    }
}
