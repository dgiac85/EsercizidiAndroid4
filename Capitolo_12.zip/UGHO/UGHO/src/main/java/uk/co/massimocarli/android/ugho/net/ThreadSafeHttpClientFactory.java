package uk.co.massimocarli.android.ugho.net;

import org.apache.http.HttpVersion;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.CoreProtocolPNames;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.protocol.HTTP;

import android.util.Log;

/**
 * Factory for a Thread safe HttpClient instance.
 *
 * @author Massimo Carli - 15 July 2013
 */
public enum ThreadSafeHttpClientFactory {

    INSTANCE;

    /*
     * The Tag for the log
     */
    private static final String LOG_TAG = ThreadSafeHttpClientFactory.class.getName();

    /*
     * Default value for timeout.
     */
    private static final int TIMEOUT = 60000;

    /*
     * Default port for HTTP.
     */
    private static final int HTTP_PORT = 80;

    /*
     * Default port for HTTPS.
     */
    private static final int HTTPS_PORT = 443;

    /*
     * HTTP Schema
     */
    private static final String HTTP_SCHEMA = "http";

    /*
     * HTTPS Schema
     */
    private static final String HTTPS_SCHEMA = "https";

    /*
     * The HttpClient instance to share between Thread
     */
    private HttpClient httpClient;

    /*
     * Private Singleton constructor
     */
    private ThreadSafeHttpClientFactory() {
        httpClient = createHttpClient();
    }

    /**
     * @return The reference to the Thread safe HttpClient instance
     */
    public HttpClient getThreadSafeHttpClient() {
		if (httpClient == null) {
			httpClient = createHttpClient();
		}
        return httpClient;
    }

    /**
     * Releases the httpClient instance
     */
    public void release() {
        httpClient = null;
    }

    /*
     * Here we encapsulate the logic of HttpClient creation
     */
    private HttpClient createHttpClient() {
        // Define HttpClient factory parameters
        HttpParams httpParams = new BasicHttpParams();
        HttpProtocolParams.setVersion(httpParams, HttpVersion.HTTP_1_1);
        HttpProtocolParams.setContentCharset(httpParams, HTTP.DEFAULT_CONTENT_CHARSET);
        // Registering protocol Schema
        SchemeRegistry schemeRegistry = new SchemeRegistry();
        Scheme httpScheme = new Scheme(HTTP_SCHEMA, PlainSocketFactory.getSocketFactory(), HTTP_PORT);
        schemeRegistry.register(httpScheme);
        Scheme httpsScheme = new Scheme(HTTPS_SCHEMA, SSLSocketFactory.getSocketFactory(), HTTPS_PORT);
        schemeRegistry.register(httpsScheme);
        // Initialize ClientConnectionManager
        ClientConnectionManager tsConnManager = new ThreadSafeClientConnManager(httpParams, schemeRegistry);
        HttpClient tmpClient = new DefaultHttpClient(tsConnManager, httpParams);
        HttpConnectionParams.setSoTimeout(tmpClient.getParams(), TIMEOUT);
        HttpConnectionParams.setConnectionTimeout(tmpClient.getParams(), TIMEOUT);
        // User Agent
        addUserAgent(tmpClient);
        return tmpClient;
    }

    private void addUserAgent(HttpClient client) {
        // User Agent
        String userAgent = System.getProperty("http.agent");
        Log.d(LOG_TAG, "Created HttpClient with UserAgent " + userAgent);
        client.getParams().setParameter(CoreProtocolPNames.USER_AGENT, userAgent);
    }

}
