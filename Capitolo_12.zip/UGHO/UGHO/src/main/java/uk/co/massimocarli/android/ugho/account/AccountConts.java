package uk.co.massimocarli.android.ugho.account;

/**
 * Created by Massimo Carli on 19/07/13.
 */
public final class AccountConts {

    /**
     * The type of the account for UGHO
     */
    public static final String UGHO_ACCOUNT_TYPE = "uk.co.massimocarli.android.ugho.account";

    /**
     * Private constructor
     */
    private AccountConts() {
        throw new AssertionError("Never instantiate me!");
    }

}
