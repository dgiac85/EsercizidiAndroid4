package uk.co.massimocarli.android.ugho.fragment;


import android.app.Activity;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import com.actionbarsherlock.app.SherlockFragment;
import uk.co.massimocarli.android.ugho.R;
import uk.co.massimocarli.android.ugho.util.FontUtility;

/**
 * Created by Massimo Carli on 15/06/13.
 */
public class FirstAccessFragment extends SherlockFragment {

    /**
     * The tag for the log
     */
    private static final String TAG_LOG = FirstAccessFragment.class.getName();

    /**
     * Interface that should be implemented by the activity that uses this Fragment
     */
    public interface FirstAccessListener {

        /**
         * Invoked to notify the choice of the user to enter as anonymous
         */
        void enterAsAnonymous();

        /**
         * Invoked to notify the choice of the user to login
         */
        void doLogin();

        /**
         * Invoked to notify the choice of the user to register
         */
        void doRegistration();

    }

    /**
     * The reference to the listener of this Fragment
     */
    private FirstAccessListener mListener;


    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        if (activity instanceof FirstAccessListener) {
            mListener = (FirstAccessListener) activity;
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // We create the layout for this fragment
        final View firstAccessView = inflater.inflate(R.layout.fragment_main, null);
        // We note that we don't care about the Button type because the onClick is an event
        // of all the View
        final Button anonymousButton = (Button) firstAccessView.findViewById(R.id.anonymous_button);
        FontUtility.applyFont(anonymousButton);
        anonymousButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mListener != null) {
                    Log.d(TAG_LOG, "User requests to enter as anonymous!");
                    mListener.enterAsAnonymous();
                }
            }
        });
        // Login
        final Button loginButton = (Button) firstAccessView.findViewById(R.id.login_button);
        FontUtility.applyFont(loginButton);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mListener != null) {
                    Log.d(TAG_LOG, "User requests to login!");
                    mListener.doLogin();
                }
            }
        });
        // Registration
        final Button registrationButton = (Button) firstAccessView.findViewById(R.id.register_button);
        FontUtility.applyFont(registrationButton);
        registrationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mListener != null) {
                    Log.d(TAG_LOG, "User requests to register!");
                    mListener.doRegistration();
                }
            }
        });
        // We return the View for the fragment
        return firstAccessView;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        this.mListener = null;
    }
}
