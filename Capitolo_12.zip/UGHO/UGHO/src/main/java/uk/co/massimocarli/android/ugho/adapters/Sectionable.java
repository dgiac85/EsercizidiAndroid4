package uk.co.massimocarli.android.ugho.adapters;

/**
 * This interface describe the property of an object to be sectionable and so it's element
 * divided into different section in a list or similar object
 *
 * @param <E> The parameter type for this Sectionable object
 */
public interface Sectionable<E> {

    /**
     * This is the values that a Sectionable object returns for its NON Sectionable items. The Decorator
     * will ignore this values
     */
    String NOT_SECTIONABLE_ITEM = "62736947218639";

    /**
     * This returns the classification for the given object
     *
     * @return The identifier of the section or NOT_SECTIONABLE_ITEM if not sectionable
     */
    String getSection();

}
