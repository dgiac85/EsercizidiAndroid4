package uk.co.massimocarli.android.ugho.adapters;

import uk.co.massimocarli.android.ugho.model.LocalDataModel;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * Created by massimocarli on 29/06/13.
 */
public class LocalDataModelSectionator implements Sectionator<LocalDataModel> {

    /**
     * The DateFormatter for the date of the votes
     */
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("MMMM yyyy");

    @Override
    public String getSection(LocalDataModel obj) {
        // Here we have to return the date from the Obj. Here we return the
        // label aggregated by week
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(obj.entryDate);
        // We get the month and year
        return DATE_FORMAT.format(calendar.getTime());
    }

}
