package uk.co.massimocarli.android.ugho.appwidget;

import android.app.PendingIntent;
import android.app.Service;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.widget.RemoteViews;
import uk.co.massimocarli.android.ugho.R;
import uk.co.massimocarli.android.ugho.activity.InputDataActivity;
import uk.co.massimocarli.android.ugho.activity.NewDataActivity;
import uk.co.massimocarli.android.ugho.content.UghoDB;
import uk.co.massimocarli.android.ugho.model.LocalDataModel;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 * Created by Massimo Carli on 17/07/13.
 */
public class UghoAppWidgetProvider extends AppWidgetProvider {
    /**
     * The Tag for the Log
     */
    private final static String TAG_LOG = UghoAppWidgetProvider.class.getName();

    /**
     * Milliseconds in a day
     */
    private static final long MILLIS_IN_DAY = 1000L * 3600 * 24;

    /**
     * The DateFormatter for the date of the votes
     */
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("E dd MMMM yyyy");

    /**
     * Thi sis invoked the first time the Widget is installed and on every time we Widget needs
     * an update. The time is configured into the AppWidget configuration file
     *
     * @param context          The Context
     * @param appWidgetManager The AppWidgetManager we use to interact with the AppWidget
     * @param appWidgetIds     The array of all the widget identifiers
     */
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        // For every id we need to update we start the related Intent to update the data
        for (int i = 0; i < appWidgetIds.length; i++) {
            // We create the Intent to launch the Service for the update
            Intent updateIntent = new Intent(context, UpdateUghoWidgetService.class);
            // We put the current identifier as an extra of the Intent
            updateIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetIds[i]);
            // We launch the service
            context.startService(updateIntent);
        }
    }

    public void onDeleted(Context context, int[] appWidgetIds) {
        SharedPreferences config = context.getSharedPreferences(UghoAppWidgetSettings.APP_WIDGET_PREFS,
                Context.MODE_PRIVATE);
        SharedPreferences.Editor configEditor = config.edit();
        for (int i = 0; i < appWidgetIds.length; i++) {
            final String mColorKey = UghoAppWidgetSettings.CURRENT_COLOR_KEY + appWidgetIds[i];
            configEditor.remove(mColorKey);
        }
        configEditor.commit();
        super.onDeleted(context, appWidgetIds);
    }

    /**
     * This is the Service implementation we use to update the AppWidget
     */
    public static class UpdateUghoWidgetService extends Service {

        public int onStartCommand(Intent intent, int flags, int startId) {
            if (intent == null) {
                return START_NOT_STICKY;
            }
            // Here we receive the Intent that should contains the identifier of the
            // AppWidget instance to update
            Bundle extras = intent.getExtras();
            int mAppWidgetId = 0;
            if (extras != null) {
                mAppWidgetId = extras.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID,
                        AppWidgetManager.INVALID_APPWIDGET_ID);
            }
            // If the identifier is found we create the RemoteViews using our layout
            RemoteViews remoteView = new RemoteViews(getPackageName(),
                    R.layout.widget_layout);
            // We text if there's a data for this user
            final long now = System.currentTimeMillis();
            final long today = now - (now % MILLIS_IN_DAY);
            // We test if the data is present
            final String where = UghoDB.HoroVote.ENTRY_DATE + " = ?";
            final String[] whereArgs = new String[]{String.valueOf(today)};
            Cursor data = getContentResolver().query(UghoDB.HoroVote.CONTENT_URI, null, where, whereArgs, null);
            if (data.moveToNext()) {
                // We have to show the result that we have feed with data
                remoteView.setViewVisibility(R.id.widget_insert_button, View.GONE);
                remoteView.setViewVisibility(R.id.widget_data, View.VISIBLE);
                showData(remoteView, data, mAppWidgetId);
            } else {
                // We have to show the button to enter new data
                remoteView.setViewVisibility(R.id.widget_insert_button, View.VISIBLE);
                remoteView.setViewVisibility(R.id.widget_data, View.GONE);
            }
            data.close();
            // We set the OnClick on the Button
            final Intent newDataIntent = new Intent(this, NewDataActivity.class);
            newDataIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, mAppWidgetId);
            final PendingIntent newDataPendingIntent = PendingIntent.getActivity(this, 0, newDataIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT);
            remoteView.setOnClickPendingIntent(R.id.widget_insert_button, newDataPendingIntent);
            // We set the OnClick on the list items. We go to the list
            final Intent listDataIntent = new Intent(this, InputDataActivity.class);
            final PendingIntent listDataPendingIntent = PendingIntent.getActivity(this, 0, listDataIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT);
            remoteView.setOnClickPendingIntent(R.id.widget_data, listDataPendingIntent);
            // We get the AppWidgetManager reference and update the RemoteViews
            AppWidgetManager manager = AppWidgetManager.getInstance(this);
            manager.updateAppWidget(mAppWidgetId, remoteView);
            return Service.START_STICKY;
        }

        public IBinder onBind(Intent intent) {
            return null;
        }

        /**
         * Utility to copy data into the RemoteViews
         *
         * @param remoteViews The RemoteViews
         * @param dataCursor  The Cursor with the data
         */
        private void showData(final RemoteViews remoteViews, final Cursor dataCursor, int widgetId) {
            // We set the color from the settings
            final SharedPreferences widgetPrefs = getSharedPreferences(UghoAppWidgetSettings.APP_WIDGET_PREFS, Context.MODE_PRIVATE);
            final String colorKey = UghoAppWidgetSettings.CURRENT_COLOR_KEY  + widgetId;
            final int textColor = widgetPrefs.getInt(colorKey, Color.BLACK);
            remoteViews.setTextColor(R.id.list_item_date, textColor);
            remoteViews.setTextColor(R.id.list_item_love_vote, textColor);
            remoteViews.setTextColor(R.id.list_item_health_vote, textColor);
            remoteViews.setTextColor(R.id.list_item_work_vote, textColor);
            remoteViews.setTextColor(R.id.list_item_luck_vote, textColor);
            final LocalDataModel localData = LocalDataModel.fromCursor(dataCursor);
            remoteViews.setTextViewText(R.id.list_item_date, DATE_FORMAT.format(localData.entryDate));
            remoteViews.setTextViewText(R.id.list_item_love_vote,
                    getResources().getString(R.string.love_value_pattern, localData.loveVote));
            remoteViews.setTextViewText(R.id.list_item_health_vote,
                    getResources().getString(R.string.health_value_pattern, localData.healthVote));
            remoteViews.setTextViewText(R.id.list_item_work_vote,
                    getResources().getString(R.string.work_value_pattern, localData.workVote));
            remoteViews.setTextViewText(R.id.list_item_luck_vote,
                    getResources().getString(R.string.luck_value_pattern, localData.luckVote));
        }
    }

}
