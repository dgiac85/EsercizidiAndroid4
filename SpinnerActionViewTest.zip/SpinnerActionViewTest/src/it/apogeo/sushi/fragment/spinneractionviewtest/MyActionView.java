/**
 * 
 */
package it.apogeo.sushi.fragment.spinneractionviewtest;

import android.content.Context;
import android.view.ActionProvider;
import android.view.View;

/**
 * @author Massimo Carli - 11/apr/2013
 *
 */
public class MyActionView extends ActionProvider {

	public MyActionView(Context context) {
		super(context);
	}

	@Override
	@Deprecated
	public View onCreateActionView() {
		// TODO Auto-generated method stub
		return null;
	}



}
