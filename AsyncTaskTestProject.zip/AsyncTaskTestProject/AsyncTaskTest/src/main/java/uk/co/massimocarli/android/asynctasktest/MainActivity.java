package uk.co.massimocarli.android.asynctasktest;

import android.graphics.drawable.ClipDrawable;
import android.os.*;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.lang.ref.WeakReference;

public class MainActivity extends Activity {

    /**
     * The Tag for the log
     */
    private static final String TAG_LOG = MainActivity.class.getName();

    /**
     * The What for the update of the clip value
     */
    private static final int CLIP_UPDATE_WHAT = 1;

    /**
     * The max counter value
     */
    private static final int MAX_COUNTER_VALUE = 10000;

    /**
     * The time to wait between values
     */
    private static final long INTERVAL_TIME = 25;

    /**
     * The reference to the ClipDrawable
     */
    private ClipDrawable mClipDrawable;

    /**
     * The Reference to the ProgressBar
     */
    private ProgressBar mProgressBar;

    /**
     * THe current AsyncTask
     */
    private CounterAsyncTask mCurrentAsyncTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // We get the reference to the ProgressView
        final View progressView = findViewById(R.id.progress_view);
        // We get the reference to the ClipDrawable
        mClipDrawable = (ClipDrawable) progressView.getBackground();
        // The ProgressBar reference
        mProgressBar = (ProgressBar) findViewById(R.id.progress_bar);
        mProgressBar.setVisibility(View.GONE);
    }

    /**
     * We use this method to update the ClipDrawable level
     *
     * @param progressValue The new value for the level
     */
    public void directUpdateClipDrawable(final int progressValue) {
        mClipDrawable.setLevel(progressValue);
    }

    /**
     * Invoked when we press some button
     *
     * @param pressedButton The button pressed
     */
    public void buttonPressed(final View pressedButton) {
        switch (pressedButton.getId()) {
            case R.id.start_button:
                if (mCurrentAsyncTask == null) {
                    mCurrentAsyncTask = new CounterAsyncTask();
                    mCurrentAsyncTask.execute(100);
                }
                break;
            case R.id.stop_button:
                // We use the visibility of the progress bar to understand
                if (mCurrentAsyncTask != null && mProgressBar.getVisibility() == View.VISIBLE) {
                    mCurrentAsyncTask.cancel(true);
                    mCurrentAsyncTask = null;
                }
                break;
        }

    }

    /**
     * This is the AsyncTask that counts for the first number
     */
    private class CounterAsyncTask extends AsyncTask<Integer, Integer, Long> {

        /**
         * The sum
         */
        private long mSum;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Here we show the ProgressBar
            mProgressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(Long aLong) {
            super.onPostExecute(aLong);
            // Here we hide the ProgressBar
            mProgressBar.setVisibility(View.GONE);
            Toast.makeText(MainActivity.this, "TASK COMPLETED!!! Sum:" + mSum, Toast.LENGTH_SHORT).show();
        }

        @Override
        protected void onCancelled() {
            super.onCancelled();
            // Here we hide the ProgressBar
            mProgressBar.setVisibility(View.GONE);
            Toast.makeText(MainActivity.this, "TASK CANCELLED!!! Sum:" + mSum, Toast.LENGTH_SHORT).show();
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            // We update the value of the ClipDrawable
            mClipDrawable.setLevel(values[0]);
        }

        @Override
        protected Long doInBackground(Integer... numberToCount) {
            // We get the max number to count
            final int maxNumber = numberToCount[0];
            // We divide the value 10000 for the steps number
            final int step = MAX_COUNTER_VALUE / maxNumber;
            mSum = 0;
            int progressValue = 0;
            for (int counter = 0; counter < maxNumber; counter++) {
                if (isCancelled()) {
                    break;
                }
                try {
                    Thread.sleep(INTERVAL_TIME);
                } catch (InterruptedException ie) {
                }
                if (isCancelled()) {
                    break;
                }
                mSum += counter;
                progressValue += step;
                Log.d(TAG_LOG, "Sum: " + mSum);
                if (isCancelled()) {
                    break;
                }
                // We publish the current value
                publishProgress(progressValue);
            }
            // We return the sum
            return mSum;
        }
    }


}
