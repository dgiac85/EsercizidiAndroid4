package uk.co.massimocarli.android.handlertest;

import android.graphics.drawable.ClipDrawable;
import android.os.*;
import android.app.Activity;
import android.util.Log;
import android.view.View;

import java.lang.ref.WeakReference;


public class MainActivity extends Activity {

    /**
     * The Tag for the log
     */
    private static final String TAG_LOG = MainActivity.class.getName();

    /**
     * The name of the second consumer
     */
    private static final String CONSUMER_NAME = "CONSUMER-2";

    /**
     * The priority for the Consumer
     */
    private static final int CONSUMER_PRIORITY = HandlerThread.NORM_PRIORITY;

    /**
     * The What for the update of the clip value
     */
    private static final int CLIP_UPDATE_WHAT = 1;

    /**
     * The max counter value
     */
    private static final int MAX_COUNTER_VALUE = 10000;

    /**
     * The time to wait between values
     */
    private static final long INTERVAL_TIME = 25;

    /**
     * The incremental step for the counter
     */
    private static final long STEP = 50;

    /**
     * The Thread for the counting
     */
    private CounterThread mCounterThread;

    /**
     * The reference to the ClipDrawable
     */
    private ClipDrawable mClipDrawable;

    /**
     * The reference to the UpdateHandler
     */
    private UpdateHandler mUpdateHandler;

    /**
     * The Handler for the Consumer2
     */
    private Handler mConsumer2Handler;

    /**
     * The Thread to use as a Consumer
     */
    private ConsumerThread mConsumerThread;

    /**
     * This is a Thread that should consume messages from our counter
     */
    private class ConsumerThread extends Thread {

        /**
         * The Handler related to this Thread
         */
        public Handler consumerHandler;

        public void run() {
            Looper.prepare();
            consumerHandler = new Handler() {
                @Override
                public void handleMessage(Message msg) {
                    Log.i(TAG_LOG, "ConsumerThread -> " + msg.obj);
                }
            };
            Looper.loop();
        }

    }

    /**
     * Our Handler implementation to manage updates
     */
    private static class UpdateHandler extends Handler {

        /**
         * The reference to the Activity
         */
        private WeakReference<MainActivity> mActivityRef;

        /**
         * Creates a UpdateHandler with the reference (weak) to the Activity
         *
         * @param activity The Activity for this Handler
         */
        public UpdateHandler(final MainActivity activity) {
            this.mActivityRef = new WeakReference<MainActivity>(activity);
        }

        @Override
        public void handleMessage(Message msg) {
            if (msg.what == CLIP_UPDATE_WHAT) {
                final MainActivity srcActivity = mActivityRef.get();
                if (srcActivity != null) {
                    // We notify the value for the ClipDrawable
                    srcActivity.directUpdateClipDrawable(msg.arg1);
                }
            }
        }
    }

    /**
     * Worker Thread for counting
     */
    public static class CounterThread implements Runnable {

        /**
         * The reference to the Activity
         */
        private WeakReference<MainActivity> mActivityRef;

        /**
         * The Counter value
         */
        private int mCounter;

        /**
         * This is the running to manage the start/stop
         */
        private volatile boolean mRunning;

        /**
         * The Thread for this Runnable
         */
        private Thread mThread;

        /**
         * Creates a CounterThread with the reference (weak) to the Activity
         *
         * @param activity The Activity for this Thread
         */
        public CounterThread(final MainActivity activity) {
            this.mActivityRef = new WeakReference<MainActivity>(activity);
        }

        /**
         * Starts the Thread if not started
         */
        public void start() {
            if (!mRunning) {
                mRunning = true;
                mThread = new Thread(this);
                mThread.start();
            }
        }

        /**
         * Stops the Thread
         */
        public void stop() {
            if (mRunning) {
                mRunning = false;
                mThread = null;
            }
        }

        /**
         * Resets the value of the thread. Only if stopped
         */
        public void reset() {
            if (!mRunning) {
                mCounter = 0;
                updateValue(mCounter);
            }
        }

        @Override
        public void run() {
            do {
                try {
                    Thread.sleep(INTERVAL_TIME);
                } catch (InterruptedException ie) {
                }
                updateValue(mCounter);
                Log.d(TAG_LOG, "Counted: " + mCounter);
                mCounter += STEP;
            } while (mCounter < MAX_COUNTER_VALUE && mRunning);
            // The last value
            updateValue(mCounter);
            Log.d(TAG_LOG, "Counted: " + mCounter);
            // The Thread is finished
            mRunning = false;
        }

        /**
         * Utility method that update the value on the ClipDrawable
         *
         * @param newValue The new Value for the drawable
         */
        private void updateValue(final int newValue) {
            final MainActivity srcActivity = mActivityRef.get();
            if (srcActivity != null) {
                //srcActivity.directUpdateClipDrawable(mCounter);
                srcActivity.updateClipDrawable(mCounter);
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // The Handler
        mUpdateHandler = new UpdateHandler(this);
        // We create the Thread for the counter
        mCounterThread = new CounterThread(this);
        // We create the ConsumerThread
        mConsumerThread = new ConsumerThread();
        mConsumerThread.start();
        // We define a second consumer
        final HandlerThread handlerThread = new HandlerThread(CONSUMER_NAME, CONSUMER_PRIORITY);
        handlerThread.start();
        mConsumer2Handler = new Handler(handlerThread.getLooper()){

            @Override
            public void handleMessage(Message msg) {
                Log.i(TAG_LOG, "CONSUMER2 -> " + msg.obj);
            }
        };
        // We get the reference to the ProgressView
        final View progressView = findViewById(R.id.progress_view);
        // We get the reference to the ClipDrawable
        mClipDrawable = (ClipDrawable) progressView.getBackground();
    }

    /**
     * We use this method to update the ClipDrawable level
     *
     * @param progressValue The new value for the level
     */
    public void directUpdateClipDrawable(final int progressValue) {
        mClipDrawable.setLevel(progressValue);
    }


    /**
     * This is invoked to update the ClipDrawable through the Handler
     *
     * @param progressValue The new value for the level
     */
    public void updateClipDrawable(final int progressValue) {
        // We compose the Message to send for the update
        final Message updateMessage = mUpdateHandler.obtainMessage(CLIP_UPDATE_WHAT);
        updateMessage.arg1 = progressValue;
        mUpdateHandler.sendMessage(updateMessage);
        // We send the message to the Consumer using its Handler
        final Message toConsumerMessage = mConsumerThread.consumerHandler.obtainMessage();
        toConsumerMessage.obj = progressValue;
        mConsumerThread.consumerHandler.sendMessage(toConsumerMessage);
        // We send the message to the second consumer
        final Message toConsumer2Message = mConsumer2Handler.obtainMessage();
        toConsumer2Message.obj = progressValue;
        mConsumer2Handler.sendMessage(toConsumer2Message);
    }


    /**
     * Invoked when we press some button
     *
     * @param pressedButton The button pressed
     */
    public void buttonPressed(final View pressedButton) {
        switch (pressedButton.getId()) {
            case R.id.start_button:
                mCounterThread.start();
                break;
            case R.id.stop_button:
                mCounterThread.stop();
                break;
            case R.id.reset_button:
                mCounterThread.reset();
                break;
        }

    }

}
