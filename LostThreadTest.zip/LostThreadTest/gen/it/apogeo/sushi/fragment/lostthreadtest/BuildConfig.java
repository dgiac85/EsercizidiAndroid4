/** Automatically generated file. DO NOT MODIFY */
package it.apogeo.sushi.fragment.lostthreadtest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}